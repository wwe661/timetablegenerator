<?php
include('../Database/config.php');

if (isset($_REQUEST['table'])) {
    $id = $_REQUEST['id'];
    $table = $_REQUEST['table'];
    
    // Correct the concatenation
    $id_name = $table . "_id";
    
    // Properly build the query with spaces
    $query = "DELETE FROM " . $table . " WHERE " . $id_name . " = '" . $id."'";
    var_dump($query);
    $result = mysqli_query($con, $query);

    if ($result) {
        echo "Deletion successful";
    } else {
        echo "Deletion failed: " . mysqli_error($con);
    }

    // Use '.' for concatenation in the URL too
    header('Location: admindashboard.php?info=' . $table);
}
