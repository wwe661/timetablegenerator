<table id='teacherTable'>
    <!-- <tr class='danger'>
        <th colspan='8'>
            
        </th>
    </tr> -->
    <tr id="table-head">
        <th>Teacher id</th>
	    <th>Teacher Name</th>
        <th>gmail</th>
		<th>Phone</th>
		<th>Action</th>
		<th>Action</th>
    </tr>
    <?php
    $q = mysqli_query($con, "SELECT * FROM teacher order by name DESC");

		while ($row = mysqli_fetch_assoc($q)) {
			echo "<tr>
                <td>{$row['teacher_id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['eid']}</td>
                <td>{$row['mob']}</td>
                <td><a href='javascript:deleteData(\"{$row['teacher_id']}\")' class='btn delBtn'>Delete</a></td>
                <td>
                <a class='updateBtn' role='button' href='admindashboard.php?info=updateteacher&teacher_id={$row['teacher_id']}'>Update</a>
                </td>
                </tr>\n";
		}
    ?>
</table>
<input type="hidden" value ="teacher"id ="pgname">