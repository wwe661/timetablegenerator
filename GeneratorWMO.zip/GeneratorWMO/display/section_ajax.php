<strong>
<option value="" selected="selected" disabled="disabled">Select Section</option>
<?php 
include('../Database/config.php');

$q = mysqli_query($con, "SELECT * FROM section WHERE section_id='".$_GET['id']."'");
while($res = mysqli_fetch_assoc($q)) {
    echo "<option value='".$res['section_id']."'>".$res['section_name']."</option>";
}
?>
</strong>
