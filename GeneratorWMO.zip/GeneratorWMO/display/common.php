<div class="addBtn">
        <a onclick="addnew()">+</a>
</div>
