<div id="tsting">
<form action=""method ="post">
    <p>Enter the room code</p>
    <input type="text" name="rm_code" id="">
    <select name="teacher" id="teacher" class="form-control">
        <option disabled selected>Select Teacher</option>
        <?php
        // Fetch teachers from the database
        $teachers_query = mysqli_query($con, "SELECT * FROM teacher order by name DESC");

        // Check if any teachers are fetched
        if(mysqli_num_rows($teachers_query) > 0) {
            // Loop through each teacher and create an option tag
            while ($teacher = mysqli_fetch_assoc($teachers_query)) {
                echo '<option value="' . $teacher['teacher_id'] . '">' . $teacher['name'] . '</option>';
            }
        } else {
            echo '<option disabled>No teachers found</option>'; // Show a message if no teachers are found
        }
        ?>
    </select>
    <input type="submit" name ="submit"value="Submit">
    <input type="reset" value="Reset">
</form>
<?php
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        if(isset($_POST["submit"])) {
            $rm_code = isset($_POST["rm_code"]) ? $_POST["rm_code"] :null;
            $th_code = isset($_POST["teacher"]) ? $_POST["teacher"] :null;
            
            if(!empty($_POST["rm_code"])) {
                $sql = "select * from teach where rm_code=?";
                $stmt=$conn->prepare($sql);
                $stmt->execute([$rm_code]);
                $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

                echo'<table> <tr> <th>Room</th><th>Period</th><th>Section</th><th>Teacher</th><th>Subject</th><th>Type</th></tr>';
                foreach($result as $row) {
                    echo '<tr><td>'.$row['rm_code'].'</td><td>'.$row['day_P'].'</td><td>'. 
                    $row['section_id'].'</td><td>'. $row['teacher_id'].'</td><td>'. $row['subject_id'].'</td><td>'. $row['alias'].'</td></tr>';
                }
            }
            if(isset($_POST["teacher"])) {
                $sql = "select * from teach where teacher_id=?";
                $stmt=$conn->prepare($sql);
                $stmt->execute([$th_code]);
                $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
                echo'<table> <tr> <th>Teacher</th><th>Period</th><th>Section</th><th>Room</th><th>Subject</th><th>Type</th></tr>';
                foreach($result as $row) {
                    echo '<tr><td>'.$row['teacher_id'].'</td><td>'.$row['day_P'].'</td><td>'. 
                    $row['section_id'].'</td><td>'. $row['rm_code'].'</td><td>'. $row['subject_id'].'</td><td>'. $row['alias'].'</td></tr>';
                }
            }
        }
        
    }
?>
</div>