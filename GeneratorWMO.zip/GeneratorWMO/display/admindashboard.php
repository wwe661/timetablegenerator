<?php 
session_start();
include('../Database/config.php');
include('../Database/configPDO.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Time table Admin Dashboard</title>

    <link rel="stylesheet" href="common.css">
	<link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link href="..\fontawesome-free-6.6.0-web\css\all.min.css" rel="stylesheet" type="text/css">

</head>

<body>

    <div id="wrapper">

		<div class="header">
            	<div> 
                <button onclick="toggleMenu(this)"><i class="fas fa-bars"></i></button>
				<!-- <img src="" alt="" width=50 height=50/> -->
				<a href="admindashboard.php"><span>Hello Admin</span></a>
				</div>
                <p id ="titlefortable">HOME</p>
        </div>
        <!-- Navigation -->
        <nav class="bar"><!-- <div class="collapse navbar-collapse navbar-ex1-collapse" > -->
                <ul>
                    <!-- <li>
                        <a href="admindashboard.php?info=department">
                            <i class="fas fa-building"></i><span>Department</span>
                        </a> 
                    </li>-->
					<li>
                        <a href="admindashboard.php?info=subject">
                            <i class="fas fa-book"></i><span>Subject</span>
                        </a>
                    </li>
                    <li>
                        <a href="admindashboard.php?info=semester">
                            <i class="fas fa-calendar-alt"></i><span>Semester</span>
                        </a>
                    </li>
					<li>
                        <a href="admindashboard.php?info=room">
                            <i class="fas fa-door-open"></i><span>Room</span>
                        </a>
                    </li>
                    <li>
                        <a href="admindashboard.php?info=section">
                            <i class="fas fa-layer-group"></i><span>Section</span>
                        </a>
                    </li>
                    <li>
                        <a href="admindashboard.php?info=teacher">
                            <i class="fas fa-chalkboard-teacher"></i><span>Teacher</span>
                        </a>
                    </li>
					<li>
                        <a href="admindashboard.php?info=th_sub">
                            <i class="fas fa-tasks"></i><span>Allot Teachers,Sections and Subjects</span>
                        </a>
                    </li>
					<!-- <li>
                        <a href="admindashboard.php?info=student">
                            <i class="fas fa-user-graduate"></i><span>Student</span>
                        </a>
                    </li> -->
                    <li>
                        <a href="admindashboard.php?info=timetable">
                            <i class="fas fa-clock"></i><span>Time Table</span>
                        </a>
                    </li>
                    <li>
                        <a href="admindashboard.php?info=test">
                            <i class="fas fa-check"></i><span>Check for room or teacher manual insert</span>
                        </a>
                    </li>
                </ul>
            <!-- </div> -->
            <!-- /.navbar-collapse -->
    	</nav>

        <div id="page_wrapper">
                <?php 
				@$info=$_REQUEST['info'];
				if($info!="")
				{
                
                echo'<div class="addBtn">
                    <a onclick="addnew()">+</a>
                </div>';

				if($info=="department")			include('department.php');//nav
				elseif($info=="subject")		include('subject.php');//nav
				elseif($info=="semester")		include('semester.php');//nav
				elseif($info=="room")			include('room.php');//nav
				elseif($info=="section")		include('section.php');//nav
				elseif($info=="teacher")		include('teacher.php');//nav
				// elseif($info=="student")		include('student.php');//nav
				elseif($info=="th_sub")			include('allot.php');//nav
				elseif($info=="timetable")		include('viewtt.php');//nav
                elseif($info== 'test')          include('test.php');

				//elseif($info=="adddepartment")	include('../CURD/add/add_course.php');
				elseif($info=="addsubject")	    include('../CURD/add/add_subject.php');
				elseif($info=="addsemester")	include('../CURD/add/add_semester.php');
				elseif($info=="addroom")		include('../CURD/add/add_room.php');
				elseif($info=="addsection")	    include('../CURD/add/add_section.php');
				elseif($info=="addteacher")	    include('../CURD/add/add_teacher.php');
				// elseif($info=="addstudent")	    include('../CURD/add/add_student.php');
				elseif($info=="addth_sub")		include('../CURD/add/add_allot.php');

				//elseif($info=="updatedepartment")	include('../CURD/update/updatecourse.php');
				elseif($info=="updatesubject")	include('../CURD/update/updatesubject.php');
				elseif($info=="updatesemester")	include('../CURD/update/updatesemester.php');
				elseif($info=="updateroom")		include('../CURD/update/updateroom.php');
				elseif($info=="updateteacher")	include('../CURD/update/updateteacher.php');
				// elseif($info=="update_student")	include('../CURD/update/update_student.php');
				elseif($info=="update_allot")	include('../CURD/update/update_allot.php');

				}else include 'admin.php';
            ?>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <script src = "common.js"></script>
</body>
</html>
