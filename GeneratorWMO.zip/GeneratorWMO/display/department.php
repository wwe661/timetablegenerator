<table  id='departmentTable'>
        <tr id="table-head">
            <th>Department</th>
            <th>Action</th>
            <th>Action</th>
        </tr>
        <?php
    $q = mysqli_query($con, "SELECT * FROM department ");

            while ($row = mysqli_fetch_assoc($q)) {
                echo "<tr><td>{$row['department_name']}</td>
        <td>
            <button class='delBtn' onclick=deleteData({$row['department_id']})>Delete</button>
        </td>
        <td>
            <a class='updateBtn' role='button' href='admindashboard.php?info=updatedepartment&department_id={$row['department_id']}'>Update</a>
        </td>
        </tr>\n";
            }
        ?>  
    </table>
<input type="hidden" value ="department"id ="pgname">
	

