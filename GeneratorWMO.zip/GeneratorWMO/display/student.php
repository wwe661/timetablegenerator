<table id='studentTable'>
    <!-- <tr class='danger'>
        <th colspan='8'>
            
        </th>
    </tr> -->
    <tr id="table-head">
	    <th>Student ID</th>
        <th>Student Name</th>
		<th>Gmail</th>
		<th>Semester</th>
		<th>Section</th>
		<th>Action</th>
		<th>Action</th>
    </tr>
    <?php
$q = mysqli_query($con, "SELECT * FROM student ");
		while ($row = mysqli_fetch_assoc($q)) {
            // $row['semester_id']=$semester;
			echo "<tr>
                <td>{$row['student_id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['email']}</td>" ?>
                <?php
                    $p = mysqli_query($con, "SELECT * FROM semester WHERE semester_id='" . $row['semester_id'] . "'");
                    while ($a = mysqli_fetch_assoc($p)) {
                        ?>
                        <td><?php echo $a['semester_name']; ?></td>
                    <?php } ?>
                <?php
                    $r = mysqli_query($con, "SELECT * FROM section WHERE section_id='" . $row['section_id'] . "'");
                    while ($b = mysqli_fetch_assoc($r)) {
                        ?>
                        <td><?php echo $b['section_name']; ?></td>
                    <?php }    
                
                    echo "
                        <td>
                        <button class='btn delBtn' data-id='{$row['stu_id']}'>Delete</button></td>
                        <td>
                        <a class='updateBtn' role='button' href='admindashboard.php?info=update_student&stu_id={$row['stu_id']}'>Update</a>
                        </td>
                        </tr>\n";
		}?>
</table>
<input type="hidden" value ="student"id ="pgname">