<table id='SectionTable'>

    <tr id="table-head">
        <th>Semester</th>
        <th>Section</th>
        <th>Action</th>
    </tr>
    <?php
    $semname =[];
    $s = mysqli_query($con,"select * from semester");
    while ($semester = mysqli_fetch_assoc($s)) {
        $semname[$semester["semester_id"]] = $semester["semester_name"];  // Add the current row to the array
    }
    $q = mysqli_query($con, "SELECT * FROM section ");

		while ($row = mysqli_fetch_assoc($q)) {
            
			echo "<tr>
                <td>{$semname[$row['semester_id']]}</td>
                <td>{$row['section_name']}</td>
				<td>
				    <button class='btn delBtn' data-id='{$row['section_id']}'>Delete</button>
                </td>
				</tr>\n";
		}
    ?>
</table>
<input type="hidden" value ="section"id ="pgname">
	

