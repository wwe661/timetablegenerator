<table id='roomTable'>
    <tr id="table-head">
		<th>Room Name</th>
		<th>Type</th>
		<th>Action</th>
		<th>Action</th></tr>
<?php
$matcharr = ["A"=>"Lecture","B"=>"Machine Lab","KS"=>"Klab","CS"=>"Cisco lab",
"HS"=>"Hardware lab","FS"=>"Hitachi lab","PS"=>"Physic lab","ES"=>"English lab"];
    $q = mysqli_query($con,"SELECT * FROM room ORDER BY room.rm_code ASC");
		while ($row = mysqli_fetch_assoc($q)) {
			echo "<tr>
				<td>{$row['rm_code']}</td>
				<td>{$matcharr[$row['rm_type']]}</td>
				<td><a href='javascript:deleteData(\"{$row['room_id']}\")' class='btn delBtn'>Delete</a></td>
				<td><a href='admindashboard.php?info=updateroom&rm_code={$row['rm_code']}' class='btn updateBtn'>Update</a></td>
			</tr>\n";
		}	
?>
	</table>
    <input type="hidden" value ="room"id ="pgname">