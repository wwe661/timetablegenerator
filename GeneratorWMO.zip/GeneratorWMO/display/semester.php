<table id='semTable'>
    <tr id ="table-head">
        <th>Semester Name</th>
        <th>Subject1</th>
        <th>Subject2</th>
        <th>Subject3</th>
        <th>Subject4</th>
        <th>Subject5</th>
        <th>Subject6</th>
        <th>Action</th>
        <th>Action</th>
    </tr>

<?php
    $q = mysqli_query($con,"SELECT * FROM semester ORDER BY semester_name ASC");
    while ($row = mysqli_fetch_assoc($q)) {
        echo "<tr>
        <td>{$row['semester_name']}</td>
        <td>{$row['subject1']}</td>
        <td>{$row['subject2']}</td>
        <td>{$row['subject3']}</td>
        <td>{$row['subject4']}</td>
        <td>{$row['subject5']}</td>
        <td>{$row['subject6']}</td>  
        <td><a href='javascript:deleteData(\"{$row['semester_id']}\")' class='btn delBtn'>Delete</a></td>
        <td><a href='admindashboard.php?info=updatesemester&semester_id={$row['semester_id']}' class='btn updateBtn'>Update</a></td>
    </tr>\n";
    }
?>
</table>
<input type="hidden" value ="semester"id ="pgname">