<table class='table' id='subTable'>
    <tr id="table-head"><th rowspan="2">Subject Id</th><th rowspan="2">Subject Name</th>
    <th rowspan="2">Type</th><th colspan="3">The subject will take</th><th rowspan="2">Action</th>
    <th rowspan="2">Action</th></tr>
    <tr id="table-headbelow"><th>Lecture <br/> Rooms</th><th>Machine <br/> Rooms</th><th>Lab <br/> Rooms</th></tr>
<?php
    $matcharr = ["A"=>"Lecture","B"=>"Machine Lab","KS"=>"Klab","CS"=>"Cisco lab",
        "HS"=>"Hardware lab","FS"=>"Hitachi lab","PS"=>"Physic lab","ES"=>"English lab"];
    $q = mysqli_query($con,"SELECT * FROM subject ORDER BY subject_id ASC");
    while ($row = mysqli_fetch_assoc($q)) {
        echo "<tr>
        <td>{$row['subject_id']}</td>
        <td>{$row['subject_name']}</td>
        <td>{$matcharr[$row['type']]}</td>
        <td>".substr_count($row['need'],'A')."</td>
        <td>".substr_count($row['need'],'B')."</td>
        <td>".substr_count($row['need'],'S')."</td>
        <td><a href='javascript:deleteData(\"{$row['subject_id']}\")' class='btn delBtn'>Delete</a></td>
        <td><a href='admindashboard.php?info=updatesubject&subject_id=$row[subject_id]' class='btn updateBtn'>Update</a></td>
    </tr>\n";
}	?>
</table>
<input type="hidden" value ="subject"id ="pgname">
<style>
    #table-headbelow{
        position: sticky;
        top:42px;
        background: var(--bgcolor);
        z-index: 10;
    }
</style>
