<?php
// Include your config file and establish database connection
include('../Database/config.php');

// Check if semester_id is set in the request
if(isset($_GET['semester_id'])) {
    $semester_id = $_GET['semester_id'];

    // Fetch sections associated with the selected semester
    $sections_query = mysqli_query($con, "SELECT * FROM section WHERE semester_id = $semester_id");
    
    // Check if any sections are fetched
    if(mysqli_num_rows($sections_query) > 0) {
        // Start building options for the dropdown
        $options = '<option disabled selected>Select Section</option>';
        
        // Loop through each section and create an option tag
        while ($section = mysqli_fetch_assoc($sections_query)) {
            $options .= '<option value="' . $section['section_id'] . '">' . $section['section_name'] . '</option>';
        }
        
        // Return the options as the response
        echo $options;
    } else {
        // No sections found for the selected semester
        echo '<option disabled>No sections found</option>';
    }
} else {
    // Semester ID not provided in the request
    echo '<option disabled>Error: Semester ID not provided</option>';
}
