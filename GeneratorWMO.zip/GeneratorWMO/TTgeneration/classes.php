<?php
class materials{
    public $table;
    public $index;
    public $sub;//substr
    public function __construct($table = [],$index=[],$sub=[]){
        $this->table=$table;
        $this->index=$index;
        $this->sub=$sub;
    }
}
class subject {
    public $sub_name;
    public $sub_teacher;
    public $sub_period;
    public $frpdofth;
    public $sub_type;
    public $consecutive=false;
    public $amtime = 2;
    public $pmtime = 2;
    private $pream ;
    private $prepm;
    public function amrec(){
        $this->pream=$this->amtime;
    }
    public function pmrec(){
        $this->prepm=$this->pmtime;
    }
    public function rollback(){
    $this->amtime =$this->pream;
    $this->pmtime =$this->prepm;
    }
}
class overlap{
    public $overlap;
    public $section_id;
    public $subjects;
    public function __construct($overlap= false,$section_id =null, $subjects=[]){
        $this->overlap=$overlap;
        $this->section_id=$section_id;
        $this->subjects=$subjects;
    }
}
// $errors = [];

// function customErrorHandler($errno, $errstr) {
//     global $errors;
//     $errors[] = $errstr;
// }
// set_error_handler('customErrorHandler');
//create subjects teached by different teacher
$box=new materials;
$overlap = new overlap;
$sub1=new subject;
$sub2=new subject;
$sub3=new subject;
$sub4=new subject;
$sub5=new subject;
$sub6=new subject;
$sub_str = [$sub1,$sub2,$sub3,$sub4,$sub5,$sub6];
    