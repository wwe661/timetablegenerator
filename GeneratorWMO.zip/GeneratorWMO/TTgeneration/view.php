<?php
    function getInd($conn,$sem,$sec){
        $arr =[];
        try{
            $sql = "SELECT timetable_code FROM section where section_id =? and semester_id =?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$sec,$sem]);
            $code =$stmt->fetchColumn();
            }catch(PDOException $e){
                echo "Error: " .$e->getMessage();
            }
            for($i=0;$i<=strlen($code)-1;$i++){
                $j= intval($i/6!=5 ? $i/6 : null);
            if(isset($j))$arr[$j][]=$code[$i];
            }
        return $arr;
    }
    function codetotable($sub_str,$conn,$sem,$sec){
        $arr =[];
        try{
        $sql = "SELECT timetable_code FROM section where section_id =? and semester_id =?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$sec,$sem]);
        $tcode =$stmt->fetchColumn();
        }catch(PDOException $e){
            echo "Error: " .$e->getMessage();
        }
        if(!empty($tcode)){
        for($i=0;$i<=strlen($tcode)-1;$i++){
            $j= intval($i/6!=5 ? $i/6 : null);
        if(isset($j))$arr[$j][]=$tcode[$i];
        }
        for($i=0;$i<=5;$i++){
            $sub_instance[$i]=$sub_str[$i]->sub_name;
        }
        $sub_instance[6]=" ";
        $ind=$arr;
        for($i=0;$i<count($arr);$i++){
            for($j=0;$j<count($arr[$i]);$j++){
                foreach($sub_instance as $key=>$sname){
                if($key==$arr[$i][$j]){
                    $arr[$i][$j]=$sname;
                    break;
                }
                }
            }
        }}
        return $arr;
    }
    function gthtable($arr,$conn,$sub_str){
            $temparr=[];
                $sql="SELECT name FROM teacher where teacher_id=?";
                $stmt=$conn->prepare($sql);
            for($i=0;$i<=5;$i++){
                $temp=$sub_str[$i]->sub_teacher;
                $stmt->execute([$temp]);
                $res = $stmt->fetchColumn();
                $temparr[$sub_str[$i]->sub_name]=$res;
            }
            for($i=0;$i<count($arr);$i++){
                for($j=0;$j<count($arr[$i]);$j++){
                    foreach($temparr as $sub=>$teacher){
                        if($sub==$arr[$i][$j]){
                        $arr[$i][$j]=$teacher;
                        break;
                        }
                    }
                }
            }
            return $arr;
        }
    function addthname($arr,$conn,$sub_str){
            $sql="SELECT * FROM teacher where teacher_id=?";
            $stmt=$conn->prepare($sql);
            foreach($sub_str as $value){
            $stmt->execute([$value->sub_teacher]); 
            $result=$stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach($result as $row){
                $temparr[$row['th_code']]=$row['name'];
            }
            }
            for($i=0;$i<count($arr);$i++){
                for($j=0;$j<count($arr[$i]);$j++){
                    foreach($temparr as $thid => $thname){
                        if($thid==$arr[$i][$j]) $arr[$i][$j].="</br>$thname";
                    }
                }
            }
            return $arr;
        }
function get_Ltda($table,$rind,$conn,$am,$pm){   
    $temp=[];  
    $sql="SELECT rm_code FROM room where rm_type =?";
    $stmt=$conn->prepare($sql);
    $stmt->execute(['A']); 
    $Arcode = $stmt->fetchAll(PDO::FETCH_COLUMN);
    for($date=0;$date<count($table);$date++){
        for($period=0;$period<count($table[$date]);$period++){
            if($table[$date][$period]==" ")continue;

            switch($rind["$date$period"]){
                case 351:$temp["$date$period"]="(Klab)"; break;
                case 352:$temp["$date$period"]="(Cisco lab)"; break;
                case 353:$temp["$date$period"]="(Hardware lab)"; break;
                case 342:$temp["$date$period"]="(Hitachi lab)"; break;
                case 254:$temp["$date$period"]="(English lab)"; break;
                case 255:$temp["$date$period"]="(Physic lab)"; break;
                default:
                    if(!in_array($rind["$date$period"],$Arcode))
                        $temp["$date$period"]="(lab)";
                    elseif($period<(count($table[$date])/2))
                        $temp["$date$period"]="($am)";
                    else 
                        $temp["$date$period"]="($pm)";break;
            }
        }
    }
    return $temp;
}
function get_Ltdaed($sec,$conn){
    $sql = "select * from teach where section_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$sec]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $arr=[];
    foreach($result as $row){
        $arr[$row["day_P"]]=$row["alias"];
    }
    return $arr;
}
function getrind($conn,$sec,$sem){
    $temp=[];
    $sql="SELECT * FROM teach where day_P=? and section_id=? and semester_id=?";
    $stmt=$conn->prepare($sql);
    for($i=0;$i<5;$i++){
        for($j=0;$j<6;$j++){
            $key="$i$j";
            $stmt->execute([$key,$sec,$sem]);
            $result=$stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach($result as $row){
                $temp[$row['day_P']]=$row['rm_code'];
            }
        }
    }
    return $temp;
}
function add_aliases($table,$rind,$ltdas){
    for($i=0;$i<5;$i++){
        for($j=0;$j<6;$j++){
            if(!empty($rind["$i$j"]))
            $table[$i][$j].=$ltdas["$i$j"]."  </br> Room ( ".$rind["$i$j"]." )";
        }
    }
    return $table;
}
    function out_layout($table){
        $dates = ["Monday","Tueday","Wednesday","Thursday","Friday"];
        $periods = ["8:30am - 9:30am","9:40am - 10:40am","10:50am - 11:50am","11:50am - 12:40pm","12:40pm - 1:40pm","1:50pm - 2:50pm","3:00pm - 4:00pm"];
        $table[0][0] = "DAYS\PERIODS";
        for($p=1;$p<=7;$p++) {
            $table[0][$p] = $periods[$p-1];
        }
        for($d=1;$d<=5;$d++) {
            $table[$d][0] = $dates[$d-1];
            $table[$d][4] = "Lunch";
        }

        return $table;
        }
    function add_sub($table,$subject){
        for($date=1;$date<count($table);$date++){
            for($period=1;$period<8;$period++){
                if($period==4)continue;//skip lunch
                if(isset($table[$date][$period]))continue;//skip filled cells
                if($period<4)$table[$date][$period]=$subject[$date-1][$period-1];
                else $table[$date][$period]=$subject[$date-1][$period-2];
        }
        }
        return $table;
    }
    function disp_table($table){
        // echo count($table);
        // echo count($table[3]);
        echo '<table id="result_table" style="margin-top:20px;">';
        for($date=0;$date<=count($table)-1;$date++){
        echo "<tr>";
        for($period=0;$period<=count($table[$date])-1;$period++){
            if(!isset($table[$date][$period]))$table[$date][$period]="";
            if($date==0||$period==0){echo "<th> ".$table[$date][$period]."</th>";   continue;}    
            echo "<td>".$table[$date][$period]." </td>";
        }
        echo"</tr>";
    }
        echo"</table>";
    }
    function timetablefooter($sub_str,$conn){
        ?>
        <div class="footer" style="margin:30px;";>
        <ul class="list"id="sub_code" >
            <li><b>Subject Code</b></li>
            <?php foreach($sub_str as $value){
            echo"<li style='text-align:left;'>". $value->sub_name."</li>";
            } ?>
        </ul>

        <ul class="list"id="sub_des">
            <li><b>Subject Description</b></li>
            <?php $sql="SELECT subject_name FROM subject where subject_id=?";
            $stmt=$conn->prepare($sql);
            foreach($sub_str as $value){
            $stmt->execute([$value->sub_name]);
            $result[]=$stmt->fetchColumn();
            }
            foreach($result as $value){
            echo"<li style='text-align:left;'>". $value."</li>";
            }
            ?>
        </ul>

        <ul class="list"id="teacher">
            <li><b>Lecturer</b></li>
            <?php $sql="SELECT name FROM teacher where teacher_id=?";
            $stmt=$conn->prepare($sql);
            foreach($sub_str as $value){
            $stmt->execute([$value->sub_teacher]);
            $th[]=$stmt->fetchColumn();
            }
            foreach($th as $value){
                echo"<li style='text-align:left;'>". $value."</li>";
            }
        ?>
        </ul>
        </div>

        <?php
    }
    function view_thtable($th_code,$conn){
        try{
            $sql="SELECT name FROM teacher where teacher_id=?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$th_code]);
            $th_name= $stmt->fetchColumn();
            // echo "</br> <p class='msg'>".$th_name./*($th_code)*/"</p>";
            $t_code=[];$s_code=[];$type=[];
            $sql = "SELECT * FROM teach where teacher_id =?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$th_code]);
            $result =$stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach($result as $row){
            $t_code[] = $row['day_P'];
            $s_code[] = $row['subject_id'];
            $type[] = $row['alias'];
            $room[]= $row['rm_code'];
            $sem[]= $row['semester_id'];
            $sectemp[]=$row['section_id'];
        }
        }catch(PDOException $e){
            echo "Error: " .$e->getMessage();
        }
        $arr =[];
        $sub =[];
        $sql="SELECT subject_name FROM subject where subject_id=?";
        $stmt=$conn->prepare($sql);
        foreach($s_code as $key =>$value){
            $stmt->execute([$value]);
            $result=$stmt->fetchColumn();
        $sub[] = $result.'('. $type[$key] .')';
        }
        $sql="SELECT section_name FROM section where section_id=?";
        $stmt=$conn->prepare( $sql);
        foreach($sectemp as $value){
            $stmt->execute([$value]);
            $res=$stmt->fetchColumn();
            $sec[]=$res;
        }
        for($i=0;$i<5;$i++){
            for($j=0;$j<6;$j++){
                $comp="$i$j";
                if(in_array($comp,$t_code)){
                    $c=array_search($comp,$t_code);
                    $arr[$i][$j]="$sub[$c]</br>$sec[$c]</br>Semester $sem[$c]</br>Room($room[$c])";
                }
                else $arr[$i][$j]=" " ;     
            }
        }
        $t=[];
        $t=out_layout($t);
        $t=add_sub($t,$arr);
        disp_table($t);
    }
    ?>