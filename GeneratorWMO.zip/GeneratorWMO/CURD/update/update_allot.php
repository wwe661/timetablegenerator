<?php 
include('../../Database/config.php');
$id=$_REQUEST['th_sub_id'];
$q=mysqli_query($con,"select * from th_sub where th_sub_id='$id'");
$res=mysqli_fetch_assoc($q);
extract($_POST);
if(isset($update))
{   
    $s = mysqli_query($con,"select * from th_sub where section_id='$sec_box' and subject_id= '$subject_id'");
    $s2 = mysqli_num_rows($s);
    if($s2){
        $err="<font color='red'>This subject of the section is already full!!</font>";
    }else{
        mysqli_query($con,"update th_sub set teacher_id='$teacher_id',subject_id='$subject_id',section_id='$sec_box',semester_id='$sem_box' where th_sub_id='$id' ");
    
        $err= "Records updated";
        header('location:admindashboard.php?info=th_sub');
    }
    
}

// Fetch teachers from the database
$teachers_query = mysqli_query($con, "SELECT * FROM teacher order by name DESC");

// Fetch semesters from the database
$semesters_query = mysqli_query($con, "SELECT * FROM semester");

// Fetch sections from the database
$sections_query = mysqli_query($con, "SELECT * FROM section");

// Fetch subjects from the database
$subjects_query = mysqli_query($con, "SELECT * FROM subject order by subject_id ASC");

?>

<script>
        function showSubject(str) {
            if (str == "") {
                document.getElementById("txtHint").innerHTML = "";
                return;
            }

            // Fetch sections based on the selected semester
            fetchSections(str);
            fetchSubjects(str);
        }

        function fetchSections(semesterId) {
            if (semesterId == "") {
                // If no semester is selected, clear the section dropdown
                document.getElementById("section").innerHTML = '<option disabled selected>Select Section</option>';
                return;
            }

            // Create an AJAX request to fetch sections
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    // Update the section dropdown with the fetched options
                    document.getElementById("section").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET", "get_sections.php?semester_id=" + semesterId, true);
            xmlhttp.send();
        }
        function fetchSubjects(semesterId){
            if (semesterId == "") {
                // If no semester is selected, clear the section dropdown
                document.getElementById("subject").innerHTML = '<option disabled selected>Select Section</option>';
                return;
            }
            // Create an AJAX request to fetch sections
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    // Update the section dropdown with the fetched options
                    document.getElementById("subject").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET", "get_subonsem.php?semester_id=" + semesterId, true);
            xmlhttp.send();
        }
        function showSemester(str) {
        if (str == "") {
            document.getElementById("txtHint").innerHTML = "";
            return;
        }

        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("semester").innerHTML = xmlhttp.responseText;

            // Pass the semester name and ID to the server-side script
            // showSubject(str, echo $semester_id; ); // This line is commented out

            // Extract the selected semester ID from the response
            var selectedSemesterId = document.getElementById("semester").value;

            // Call showSubject with the selected semester ID
            showSubject(selectedSemesterId);
            }
        }
        }
</script>


<div class="row parent">
    <div class="col-md-5"> 
        <h2>Update Allotment</h2>
        <form method="POST" enctype="multipart/form-data">
            <table border="0" cellspacing="5" cellpadding="5" class="table">
                <tr>
                    <td colspan="2"><?php echo @$err; ?></td>
                </tr>

                <tr>
                    <th width="237" scope="row" name="sem_box">Select Semester</th>
                    <td width="213">
                        <?php
                        // Include your config file and establish database connection
                        include('../config.php');
                        
                        // Fetch semesters from the database
                        $semesters_query = mysqli_query($con, "SELECT * FROM semester");
                        
                        // Check if any semesters are fetched
                        if(mysqli_num_rows($semesters_query) > 0) {
                            // Start select dropdown
                            echo '<select name="sem_box" id="semester" onchange="showSubject(this.value)" class="form-control">';
                            echo '<option disabled selected>Select Semester</option>';
                            
                            // Loop through each semester and create an option tag
                            while ($semester = mysqli_fetch_assoc($semesters_query)) {
                                echo '<option value="' . $semester['semester_id'] . '">' . $semester['semester_name'] . '</option>';
                            }
                            
                            // End select dropdown
                            echo '</select>';
                        } else {
                            echo 'No semesters found'; // Show a message if no semesters are found
                        }
                        ?>
                    </td>
                </tr>

                <tr>
                    <th width="237" scope="row">Select Section</th>
                    <td width="213">
                        <?php
                        // Fetch sections from the database
                        $sections_query = mysqli_query($con, "SELECT * FROM section");
                            
                        // Check if any sections are fetched
                        if(mysqli_num_rows($sections_query) > 0) {
                        // Start select dropdown
                        echo '<select  name="sec_box" id="section"  class="form-control">';
                        echo '<option disabled selected>Select Section</option>';
                                
                        // Loop through each section and create an option tag
                        while ($section = mysqli_fetch_assoc($sections_query)) {
                            if ($semester['semester_id'] == $section['semester_id']) {
                                echo '<option value="' . $section['section_id'] . '">' . $section['section_name'] . '</option>';
                            }
                        }
                         // End select dropdown
                         echo '</select>';
                        } else {
                            echo 'No sections found'; // Show a message if no sections are found
                        }
                        ?>
                    </td>
                </tr>

                <tr>   
                    <th width="237" scope="row">Select Subject</th>
                    <td width="213">
                        <select name="subject_id" id="subject" class="form-control">
                            <option selected disabled>Select Subject</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th width="237" scope="row">Select Teacher</th>
                    <td width="213">
                        <select name="teacher_id" id="teacher" class="form-control">
                            <option disabled>Select Teacher</option>
                            <?php
                            // Loop through each teacher and create an option tag
                            while ($teacher = mysqli_fetch_assoc($teachers_query)) {
                                $selected = ($teacher['teacher_id'] == $res['teacher_id']) ? 'selected' : '';
                                echo '<option value="' . $teacher['teacher_id'] . '" ' . $selected . '>' . $teacher['name'] . '</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" value="Update Records" name="update" class="btn myBtn " />
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>