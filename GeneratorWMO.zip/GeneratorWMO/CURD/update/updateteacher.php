<?php 
include('../../Database/config.php');
$teacher_id=$_REQUEST['teacher_id'];
$q=mysqli_query($con,"select * from teacher where teacher_id='$teacher_id'");
$res=mysqli_fetch_assoc($q);
extract($_POST);
if(isset($update))
{   
    // Regular expression pattern for phone numbers (10 digits)
    $phone_pattern = '/^\d+$/';
    
    // Validate phone number format
    if(!preg_match($phone_pattern, $m)) {
        $err="<font color='red'>Please enter a valid phone number.</font>";
    } else {
        mysqli_query($con,"update teacher set name='$n',eid='$e',password='$p',mob='$m' where teacher_id='$teacher_id' ");
        $err= "Records updated";
        header('location:admindashboard.php?info=teacher');
    }   
}
	
?>
    <div class="row parent">
      <div class="col-md-5"> 
                
    <h2>Update Teacher</h2>
      <form method="POST" enctype="multipart/form-data">
        <table border="0" cellspacing="5" cellpadding="5" class="table">
        <tr>
        <td colspan="2"><?php echo @$err; ?></td>
        </tr>
        <tr>
            <th width="237" scope="row">Teacher id</th>
            <td width="213"><input type="text" name="i" value = "<?php echo $res['teacher_id'];?>"readonly/></td>
        </tr>
        <tr>
          <th width="237" scope="row">Teacher Name </th>
          <td width="213"><input type="text" name="n" class="form-control" value="<?php echo $res['name'];?>"/></td>
        </tr>
        
        <tr>
          <th width="237" scope="row">Email </th>
          <td width="213"><input type="text" name="e" class="form-control" value="<?php echo $res['eid'];?>"/></td>
        </tr>
        
        <tr>
          <th width="237" scope="row">Password </th>
          <td width="213"><input type="text" name="p" class="form-control" value="<?php echo $res['password'];?>"/></td>
        </tr>
        
        <tr>
          <th width="237" scope="row">Mobile</th>
          <td width="213"><input type="text" name="m" class="form-control" value="<?php echo $res['mob'];?>"/></td>
        </tr>

        <tr>
          <td colspan="2" align="center">
        <input type="submit" value="Update Records" name="update" class="btn myBtn " />
        <input type="reset" value="Reset">
        </td>
        </tr>
      </table>
      <!-- <input type="submit" value="Update Records" name="update" class="btn myBtn "/> -->

      </form>
      </div>
</div>          
                