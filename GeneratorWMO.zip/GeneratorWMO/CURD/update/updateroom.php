<?php 
include('../../Database/config.php');
session_start();
extract($_POST);

if (isset($update)) {
        
    mysqli_query($con,"UPDATE room SET rm_code='$rm_code', rm_type='$rm_type' WHERE rm_code='$current_room_name' ");
        
        // Rest of your code
        $err = "<font color='blue'>Congratulations! Your data has been saved.</font>";
        header("Location: admindashboard.php?info=room");
          
}

$matcharr = ["A"=>"Lecture","B"=>"Machine Lab","KS"=>"Klab","CS"=>"Cisco lab",
"HS"=>"Hardware lab","FS"=>"Hitachi lab","PS"=>"Physic lab","ES"=>"English lab"];
$rm_code=$_REQUEST['rm_code'];
$q=mysqli_query($con,"SELECT * FROM room WHERE rm_code='$rm_code'");
$res=mysqli_fetch_assoc($q);
?>

<div class="row parent">
    <div class="col-md-5">
        <h2>Update Room</h2>
        <form method="POST" enctype="multipart/form-data">
            <table border="0" cellspacing="5" cellpadding="5" class="table">
                <tr>
                    <td colspan="2"><?php echo @$err; ?></td>
                </tr>
                <tr>
                    <th width="237" scope="row">Current Room Name </th>
                    <td width="213"><input type="text" name="current_room_name" class="form-control" value="<?php echo $res['rm_code'];?>" readonly/></td>
                </tr>
                <tr>
                    <th width="237" scope="row">New Room Name </th>
                    <td width="213"><input type="text" name="rm_code" class="form-control" value=""required /></td>
                </tr>
                <tr>
                    <th width="237" scope="row">Room Type</th>
                    <td width="213">
                        <select name="rm_type"required>
                        <option disabled selected>Select room type</option>;
                            <?php foreach($matcharr as $k=>$v) { 
                                echo "<option value = '$k'>$v</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" value="Update Records" name="update" class="btn  myBtn"/>
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
