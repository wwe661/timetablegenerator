<?php
// Include the database configuration file
include('../../Database/config.php');

// Initialize the error variable
$err = "";

extract($_POST);
// Check if the form is submitted
if(isset($update)) {

    $sub_id = "$presub$sub_id";
    $need = str_repeat($type,$lab);
    $need .= str_repeat("B",$machine);
    $need .= str_repeat("A",$lecture);

    // Update the subject information in the database
    $query = "UPDATE subject SET subject_id='$sub_id', subject_name='$subname', type='$type',need='$need'
    WHERE subject_id='$current_subject_id'";
    
    // Execute the query
    if(mysqli_query($con, $query)) {
        // Set success message
        $err = "Subject information updated successfully";
        header("Location: admindashboard.php?info=subject");
    } else {
        // Set error message
        $err = "Error updating subject information: " . mysqli_error($con);
    }
}

// Retrieve the subject ID from the URL
$subject_id = $_REQUEST['subject_id'];


$matcharr = ["A"=>"Lecture","B"=>"Machine Lab","KS"=>"Klab","CS"=>"Cisco lab",
"HS"=>"Hardware lab","FS"=>"Hitachi lab","PS"=>"Physic lab","ES"=>"English lab"];
$majorarr = ["CST-","CS-","CT-","SE-","KE-","HPC-","BIS-","CN-","ES-"];

// Fetch the subject information from the database
$q = mysqli_query($con, "SELECT * FROM subject WHERE subject_id='$subject_id'");
$res = mysqli_fetch_assoc($q);
?>

<div class="row parent">
    <div class="col-md-5">
        <h2>Update Subject</h2>
        <!-- Display error/success message -->
        <?php if(!empty($err)): ?>
        <div class="alert alert-<?php echo (strpos($err, 'Error') !== false) ? 'danger' : 'success'; ?>">
            <?php echo $err; ?>
        </div>
        <?php endif; ?>

        <!-- Update Subject Form -->
        <form method="POST" enctype="multipart/form-data">
            
            <table border="0" cellspacing="5" cellpadding="5" class="table">
                <tr>
                    <th width="237" scope="row">Current Subject ID </th>
                    <td width="213"><input type="text" name="current_subject_id" class="form-control" value="<?php echo $res['subject_id'];?>" readonly/></td>
                </tr>
                <tr>
                    <th width="237" scope="row">Subject ID</th>
                    <td width="213">
                        <select name="presub" id="">
                            <?php foreach($majorarr as $v) {
                            echo"<option value='$v'>$v</option>";
                            }
                            ?>
                        </select>
                        <input type="number" name="sub_id"id="sub_id" class="form-control"min="1000" max="999999"/></td>
                </tr>
                <tr>
                    <th width="237" scope="row">Subject Name</th>
                    <td width="213"><input type="text" name="subname" class="form-control"/></td>
                </tr>
                <tr>
                    <th width="237" scope="row">Type</th>
                    <td width="213">
                        <select onchange="changerooms(this.value)" name="type">
                        <option disabled selected>Select type</option>;
                            <?php foreach($matcharr as $k=>$v) { 
                                echo "<option value = '$k'>$v</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th width="237" scope="row">Lecture rooms</th>
                    <td width="213">
                        <input type="number" name="lecture" id="lecture"min="0"max="4"step="1"value="0"onchange="balanceoutroom(this)">
                    </td>
                </tr>
                <tr>
                    <th width="237" scope="row">Machine rooms</th>
                    <td width="213">
                        <input type="number" name="machine" id="machine"min="0"max="4"step="1"value="0"onchange="balanceoutroom(this)">
                    </td>
                </tr>
                <tr>
                    <th width="237" scope="row">Lab rooms</th>
                    <td width="213">
                        <input type="number" name="lab" id="lab"min="0"max="4"step="1"value="0"onchange="balanceoutroom(this)">
                    </td>
                </tr>
                <tr>
                    <th colspan="1" scope="row"></th>
                    <td>
                        <input type="submit" value="Update subject" name="update" class="btn  myBtn" />
                        <input type="reset" value="Reset"/>
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
<script>
    lectrooms =document.getElementById("lecture");
    Machrooms =document.getElementById("machine");
    labrooms =document.getElementById("lab");
    function changerooms(value){
        switch(value){
            case "A":
                lectrooms.value = 4;
                Machrooms.value = 0;
                labrooms.value = 0;
                break;
            case "B":
                lectrooms.value = 2;
                Machrooms.value = 2;
                labrooms.value = 0;
                break;
            default:
                lectrooms.value = 3;
                Machrooms.value = 0;
                labrooms.value = 1;
        }
    }
    function balanceoutroom(element){
        total = parseInt(lectrooms.value) + parseInt(Machrooms.value) + parseInt(labrooms.value);
        if(total > 4){
            if(lectrooms!==element&&lectrooms.value>0)lectrooms.value--;
            else if(Machrooms!==element&&Machrooms.value>0)Machrooms.value--;
            else if(labrooms!==element&&labrooms.value>0)labrooms.value--;
        }else if(total <4){
            if(lectrooms!==element&&lectrooms.value<4)lectrooms.value++;
            else if(Machrooms!==element&&Machrooms.value<4)Machrooms.value++;
            else if(labrooms!==element&&labrooms.value<4)labrooms.value++;
        }
    }
</script>
