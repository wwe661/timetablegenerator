<?php 
include('../../Database/config.php');
extract($_POST);

if(isset($save))
{
    // Regular expression pattern for phone numbers (10 digits)
    $phone_pattern = '/^\d+$/';
    
    // Validate phone number format
    if(!preg_match($phone_pattern, $m)) {
        $err="<font color='red'>Please enter a valid phone number with 10 digits.</font>";
    } else {
        $que=mysqli_query($con,"SELECT * FROM teacher WHERE eid='$e'");      
        $row=mysqli_num_rows($que);
        
        if($row) {
            $err="<font color='red'>This teacher already exists</font>";
        } else {
            // Insert the data into the database
            mysqli_query($con, "INSERT INTO teacher (teacher_id,name, eid, password, mob) VALUES ('$i','$n', '$e', '$p', '$m')");   

            $err="<font color='blue'>Congratulations! Your data has been saved.</font>";
            header("Location:admindashboard.php?info=teacher");
        }
    }
}
?>
<div class="row parent">
    <div class="col-md-8">
        <h2>Add Teacher</h2>
        <form method="POST" enctype="multipart/form-data">
            <table border="0" class="table">
                <tr>
                    <td colspan="2"><?php echo @$err; ?></td>
                </tr>
                <tr>
                    <th width="237" scope="row">Teacher id</th>
                    <td width="213"><input type="text" name="i" value = "CST-"class="form-control" placeholder="Enter teacher id" required/></td>
                </tr>
                <tr>
                    <th width="237" scope="row">Teacher Name</th>
                    <td width="213"><input type="text" name="n" class="form-control" placeholder="Enter teacher name"required/></td>
                </tr>
                <tr>
                    <th scope="row">Email</th>
                    <td><input type="email" name="e" class="form-control" placeholder="Enter teacher's email"required/></td>
                </tr>

                <tr>
                    <th scope="row">Password</th>
                    <td><input type="password" name="p" class="form-control" value ="1111"placeholder="Enter default password"required/></td>
                </tr>

                <tr>
                    <th scope="row">Phone</th>
                    <td><input type="text" name="m" class="form-control" placeholder="Enter teacher's mobile"/></td>
                </tr>
                <tr>
                    <th colspan="1" scope="row"></th>
                    <td>
                        <input type="submit" value="Add Teacher" name="save" class="btn myBtn" />
                        <input type="reset" value="Reset" class="btn myBtn"/>
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
