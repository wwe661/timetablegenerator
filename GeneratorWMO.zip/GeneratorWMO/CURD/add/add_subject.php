<?php 
include('../../Database/config.php');
extract($_POST);
if(isset($save))
{
    $sub_id = "$presub$sub_id";
    $que=mysqli_query($con,"SELECT * FROM subject WHERE subject_id='$sub_id'");      
    $row=mysqli_num_rows($que);
    if($row)
    {
        $err="<font color='red'>This Subject already exists</font>";
    }
    else
    {
        $need = str_repeat($type,$lab);
        $need .= str_repeat("B",$machine);
        $need .= str_repeat("A",$lecture);
        // Modified INSERT statement to specify column names
        mysqli_query($con,"INSERT INTO subject(subject_id, subject_name, type,need) VALUES ('$sub_id','$subname', '$type','$need')");   

        $err="<font color='blue'>Congratulations! Your data has been saved.</font>";
        header("Location:admindashboard.php?info=subject");
    }
}

$matcharr = ["A"=>"Lecture","B"=>"Machine Lab","KS"=>"Klab","CS"=>"Cisco lab",
"HS"=>"Hardware lab","FS"=>"Hitachi lab","PS"=>"Physic lab","ES"=>"English lab"];
$majorarr = ["CST-","CS-","CT-","SE-","KE-","HPC-","BIS-","CN-","ES-"];
?>

<script>
function showOpts(str){
    showSemester(str);
    showTeacher(str);
}

function showSemester(str)
{
    if (str=="")
    {
        document.getElementById("txtHint").innerHTML="";
        return;
    }

    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp=new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange=function()
    {
        if (xmlhttp.readyState==4 && xmlhttp.status==200)
        {
            document.getElementById("semester").innerHTML=xmlhttp.responseText;
        }
    }
    xmlhttp.open("GET","semester_ajax.php?id="+str,true);
    xmlhttp.send();
}

function showTeacher(str)
{
    if (str=="")
    {
        document.getElementById("txtHint").innerHTML="";
        return;
    }

    if (window.XMLHttpRequest)
    {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp2=new XMLHttpRequest();
    }
    else
    {
        // code for IE6, IE5
        xmlhttp2=new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp2.onreadystatechange=function()
    {
        if (xmlhttp2.readyState==4 && xmlhttp2.status==200)
        {
            document.getElementById("teacher").innerHTML=xmlhttp2.responseText;
        }
    }
    xmlhttp2.open("GET","teacher_ajax.php?id="+str,true);
    xmlhttp2.send();
}
</script>

<div class="row parent">
    <div class="col-md-8">
        <h2>Add Subject</h2>
        <h4>The subject cannot take more than 4 rooms of any type(in total).</h4>
        <form method="POST" enctype="multipart/form-data">
            <table border="0" cellspacing="5" cellpadding="5" class="table">
                <tr>
                    <td colspan="2"><?php echo @$err; ?></td>
                </tr>
                <tr>
                    <th width="237" scope="row">Subject ID</th>
                    <td width="213">
                        <select name="presub" id="">
                            <?php foreach($majorarr as $v) {
                            echo"<option value='$v'>$v</option>";
                            }
                            ?>
                        </select>
                        <input type="number" name="sub_id"id="sub_id" class="form-control"min="1000" max="999999"/></td>
                </tr>
                <tr>
                    <th width="237" scope="row">Subject Name</th>
                    <td width="213"><input type="text" name="subname" class="form-control"/></td>
                </tr>
                <tr>
                    <th width="237" scope="row">Type</th>
                    <td width="213">
                        <select onchange="changerooms(this.value)" name="type">
                        <option disabled selected>Select type</option>;
                            <?php foreach($matcharr as $k=>$v) { 
                                echo "<option value = '$k'>$v</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th width="237" scope="row">Lecture rooms</th>
                    <td width="213">
                        <input type="number" name="lecture" id="lecture"min="0"max="4"step="1"value="0"onchange="balanceoutroom(this)">
                    </td>
                </tr>
                <tr>
                    <th width="237" scope="row">Machine rooms</th>
                    <td width="213">
                        <input type="number" name="machine" id="machine"min="0"max="4"step="1"value="0"onchange="balanceoutroom(this)">
                    </td>
                </tr>
                <tr>
                    <th width="237" scope="row">Lab rooms</th>
                    <td width="213">
                        <input type="number" name="lab" id="lab"min="0"max="4"step="1"value="0"onchange="balanceoutroom(this)">
                    </td>
                </tr>
                <tr>
                    <th colspan="1" scope="row"></th>
                    <td>
                        <input type="submit" value="Add subject" name="save" class="btn  myBtn" />
                        <input type="reset" value="Reset"/>
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
<script>
    lectrooms =document.getElementById("lecture");
    Machrooms =document.getElementById("machine");
    labrooms =document.getElementById("lab");
    function changerooms(value){
        switch(value){
            case "A":
                lectrooms.value = 4;
                Machrooms.value = 0;
                labrooms.value = 0;
                break;
            case "B":
                lectrooms.value = 2;
                Machrooms.value = 2;
                labrooms.value = 0;
                break;
            default:
                lectrooms.value = 3;
                Machrooms.value = 0;
                labrooms.value = 1;
        }
    }
    function balanceoutroom(element){
        total = parseInt(lectrooms.value) + parseInt(Machrooms.value) + parseInt(labrooms.value);
        console.log(total);
        if(total > 4){
            if(lectrooms!==element&&lectrooms.value>0)lectrooms.value--;
            else if(Machrooms!==element&&Machrooms.value>0)Machrooms.value--;
            else if(labrooms!==element&&labrooms.value>0)labrooms.value--;
        }else if(total <4){
            if(lectrooms!==element&&lectrooms.value<4)lectrooms.value++;
            else if(Machrooms!==element&&Machrooms.value<4)Machrooms.value++;
            else if(labrooms!==element&&labrooms.value<4)labrooms.value++;
        }
    }
</script>