<?php 
include('../../Database/config.php');
extract($_POST);
if(isset($save))
{
$temp="$c$c1";
$que=mysqli_query($con,"select * from section where section_id='$temp'");	
$row=mysqli_num_rows($que);
	if($row)
	{
	$err="<font color='red'>This section already exists</font>";
	}
	else
	{
        $c2= "sec".chr(64 + intval($c1));
        $c1=$temp;
    mysqli_query($con,"insert into section (semester_id,section_id,section_name) values('$c','$c1','$c2')");	

	$err="<font color='blue'>Congrats Your Data Saved!!!</font>";
  header("Location:admindashboard.php?info=section");
	}
	
}

?>
<div class="row parent">
<div class="col-md-5">
<h2>Add Section</h2>
<form method="POST" enctype="multipart/form-data">
  <table  class="table">
  <tr>
  <td colspan="2"><?php echo @$err; ?></td>
  </tr>
 
   <tr>
    <tr>
        <td scope="row" name="sem_box">Select Semester</td>
        <td colspan="2">
            <?php                
            // Fetch semesters from the database
            $semesters_query = mysqli_query($con, "SELECT * FROM semester");
            
            // Check if any semesters are fetched
            if(mysqli_num_rows($semesters_query) > 0) {
                // Start select dropdown
                echo '<select name="c" class="form-control">';
                echo '<option disabled selected>Select Semester</option>';
                
                // Loop through each semester and create an option tag
                while ($semester = mysqli_fetch_assoc($semesters_query)) {
                    echo '<option value="' . $semester['semester_id'] . '">' . $semester['semester_name'] . '</option>';
                }                    
            // End select dropdown
                echo '</select>';
            } else {
                echo 'No semesters found'; // Show a message if no semesters are found
            }
            ?>
        </td>
        </tr>
  </tr>
  <tr>
    <th width="237" scope="row">Section </th>
    <td width="213">
        <select name="c1" id="">
            <option value="1">A</option>
            <option value="2">B</option>
            <option value="3">C</option>
            <option value="4">D</option>
            <option value="5">E</option>
        </select>
    </td>
  </tr>
  <tr>
    <td colspan="2" align="center">
	<input type="submit" value="Add Section" name="save" class="btn myBtn " />
	
	<input type="reset" value="Reset" class="btn  myBtn"/>
	
	</td>
  </tr>
  
  </table>
</form>
</div>
</div>