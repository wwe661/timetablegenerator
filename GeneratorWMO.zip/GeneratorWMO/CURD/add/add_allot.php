<?php 
include('../../Database/config.php');
extract($_POST);

if (isset($save)) {
    $que = mysqli_query($con, "SELECT * FROM th_sub WHERE subject_id='$subj_box' AND section_id='$sec_box' AND semester_id='$sem_box'");
    $row = mysqli_num_rows($que);

    if ($row) {
        $err = "<font color='red'>This class with subject is already alloted!!</font>";
    } else {
        // Extract the selected semester ID from the response
        $semester = $_POST['sem_box'];
        $section = $_POST['sec_box'];
        // $subject = $_POST['sub_box'];
        
        mysqli_query($con, "INSERT INTO th_sub(teacher_id,subject_id,section_id,semester_id) VALUES ('$tch_box','$subj_box', '$sec_box','$sem_box')");
        
        
        // Rest of your code
        $err = "<font color='blue'>Congratulations! Your data has been saved.</font>";
        header("Location:admindashboard.php?info=th_sub");
    }
    
}
?>

<script>
        function showSubject(str) {
            if (str == "") {
                document.getElementById("txtHint").innerHTML = "";
                return;
            }

            // Fetch sections based on the selected semester
            fetchSections(str);
            fetchSubjects(str);
        }

        function fetchSections(semesterId) {
            if (semesterId == "") {
                // If no semester is selected, clear the section dropdown
                document.getElementById("section").innerHTML = '<option disabled selected>Select Section</option>';
                return;
            }

            // Create an AJAX request to fetch sections
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    // Update the section dropdown with the fetched options
                    document.getElementById("section").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET", "get_sections.php?semester_id=" + semesterId, true);
            xmlhttp.send();
        }
        function fetchSubjects(semesterId){
            if (semesterId == "") {
                // If no semester is selected, clear the section dropdown
                document.getElementById("subject").innerHTML = '<option disabled selected>Select Section</option>';
                return;
            }
            // Create an AJAX request to fetch sections
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    // Update the section dropdown with the fetched options
                    document.getElementById("subject").innerHTML = this.responseText;
                }
            };
            xmlhttp.open("GET", "get_subonsem.php?semester_id=" + semesterId, true);
            xmlhttp.send();
        }
        function showSemester(str) {
        if (str == "") {
            document.getElementById("txtHint").innerHTML = "";
            return;
        }

        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("semester").innerHTML = xmlhttp.responseText;

            // Pass the semester name and ID to the server-side script
            // showSubject(str, echo $semester_id; ); // This line is commented out

            // Extract the selected semester ID from the response
            var selectedSemesterId = document.getElementById("semester").value;

            // Call showSubject with the selected semester ID
            showSubject(selectedSemesterId);
            }
        }

        // alert(str);
        // xmlhttp.open("GET", "semester_ajax.php?id=" + str, true);
        // xmlhttp.send();
        }
</script>




<div class="row parent">
    <div class="col-md-8">
        <h2>Allot teacher to subject</h2>
        <form method="POST" enctype="multipart/form-data">
            <table border="0" class="table">
            <tr>
                    <td colspan="2"><?php echo @$err; ?></td>
            </tr>
            <tr>
            
                <th width="237" scope="row" name="sem_box">Select Semester</th>
                <td width="213">
                    <?php
                    
                    // Fetch semesters from the database
                    $semesters_query = mysqli_query($con, "SELECT * FROM semester");
                    
                    // Check if any semesters are fetched
                    if(mysqli_num_rows($semesters_query) > 0) {
                        // Start select dropdown
                        echo '<select name="sem_box" id="semester" onchange="showSubject(this.value)" class="form-control">';
                        echo '<option disabled selected>Select Semester</option>';
                        
                        // Loop through each semester and create an option tag
                        while ($semester = mysqli_fetch_assoc($semesters_query)) {
                            echo '<option value="' . $semester['semester_id'] . '">' . $semester['semester_name'] . '</option>';
                        }
                        
                        // End select dropdown
                        echo '</select>';
                    } else {
                        echo 'No semesters found'; // Show a message if no semesters are found
                    }
                    ?>
                </td>
            </tr>
            <tr>
                <th width="237" scope="row">Select Section</th>
                <td width="213">
                    <?php
                    // Fetch sections from the database
                    $sections_query = mysqli_query($con, "SELECT * FROM section");
                    
                    // Check if any sections are fetched
                    if(mysqli_num_rows($sections_query) > 0) {
                        // Start select dropdown
                        echo '<select  name="sec_box" id="section"  class="form-control">';
                        echo '<option disabled selected>Select Section</option>';
                        
                        // Loop through each section and create an option tag
                        while ($section = mysqli_fetch_assoc($sections_query)) {
                            // var_dump($section['semester_id']);
                            if ($semester['semester_id'] == $section['semester_id']) {
                            echo '<option value="' . $section['section_id'] . '">' . $section['section_name'] . '</option>';
                            }
                        }
                        
                        // End select dropdown
                        echo '</select>';
                    } else {
                        echo 'No sections found'; // Show a message if no sections are found
                    }
                    ?>
                </td>
            </tr>
                <!-- <tr>
                    <th width="237" scope="row">Teacher ID</th>
                    <td width="213"><input type="text" name="teacher_id" class="form-control" placeholder="Enter teacher id"/></td>
                </tr> -->
            <tr>
                <th width="237" scope="row" name="tch_box">Select Subject</th>
                <td width="213">
                    <select name="subj_box" id="subject" class="form-control">
                        <option disabled selected>Select Subject</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th width="237" scope="row" name="tch_box">Select Teacher</th>
                <td width="213">
                    <select name="tch_box" id="teacher" class="form-control">
                        <option disabled selected>Select Teacher</option>
                        <?php
                        // Include your config file and establish database connection
                        include('Database/config.php');

                        // Fetch teachers from the database
                        $teachers_query = mysqli_query($con, "SELECT * FROM teacher order by name DESC");

                        // Check if any teachers are fetched
                        if(mysqli_num_rows($teachers_query) > 0) {
                            // Loop through each teacher and create an option tag
                            while ($teacher = mysqli_fetch_assoc($teachers_query)) {
                                echo '<option value="' . $teacher['teacher_id'] . '">' . $teacher['name'] . '</option>';
                            }
                        } else {
                            echo '<option disabled>No teachers found</option>'; // Show a message if no teachers are found
                        }
                        ?>
                    </select>
                </td>
            </tr>

            
            
                <!--  -->

                <!-- <tr>
                    <th width="237" scope="row">Subject Code</th>
                    <td width="213"><input type="text" name="subject_id" class="form-control" placeholder="Enter subject id"/></td>
                </tr> -->
               
            

                
                <!--  -->
                <tr>
                    <th colspan="1" scope="row"></th>
                    <td>
                        <input type="submit" value="Allot" name="save" class="btn myBtn" />
                        <input type="reset" value="Reset" class="btn myBtn"/>
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
