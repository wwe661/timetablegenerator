<?php 
include('../../Database/config.php');
session_start();
extract($_POST);

if (isset($save)) {
    $que = mysqli_query($con, "SELECT * FROM room WHERE rm_code='$rm_code'");
    $row = mysqli_num_rows($que);

    if ($row) {
        $err = "<font color='red'>This Room already exists</font>";
    } else {
        mysqli_query($con, "INSERT INTO room(rm_code,rm_type) VALUES ('$rm_code','$rm_type')");
        
        $err = "<font color='blue'>Congratulations! Your data has been saved.</font>";
        header("Location:admindashboard.php?info=room");
    }
    
}
$matcharr = ["A"=>"Lecture","B"=>"Machine Lab","KS"=>"Klab","CS"=>"Cisco lab",
"HS"=>"Hardware lab","FS"=>"Hitachi lab","PS"=>"Physic lab","ES"=>"English lab"];
?>

<div class="row parent">
    <div class="col-md-8">
        <h2>Add Room</h2>
        <form method="POST" enctype="multipart/form-data">
            <table border="0" cellspacing="5" cellpadding="5" class="table">
                <tr>
                    <td colspan="2"><?php echo @$err; ?></td>
                </tr>
                <tr>
                    <th width="237" scope="row">Room code</th>
                    <td width="213"><input type="number" name="rm_code" class="form-control"required/></td>
                </tr>
                <tr>
                    <th width="237" scope="row">Room Type</th>
                    <td width="213">
                        <select name="rm_type"required>
                        <option disabled selected>Select room type</option>;
                            <?php foreach($matcharr as $k=>$v) { 
                                echo "<option value = '$k'>$v</option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th colspan="1" scope="row"></th>
                    <td>
                        <input type="submit" value="Add Room" name="save" class="btn  myBtn" />
                        <input type="reset" value="Reset" class="btn  myBtn"/>
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
