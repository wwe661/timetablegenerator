<?php
function connect(){
    // Add the port number to the DSN string
    $dsn = "mysql:host=localhost;dbname=latest;port=3307";
    $username = "wild";
    $password = "Waing@4421661";
    try{
        // Create a PDO instance (connect to the database)
        $conn = new PDO($dsn, $username, $password);
        // Set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        // If the connection fails, output the error
        echo "Connection failed: " . $e->getMessage();
    }
    return $conn;
}
$conn=connect();//PDO connection

