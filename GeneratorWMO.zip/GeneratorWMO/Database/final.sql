-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 08, 2024 at 09:54 PM
-- Server version: 8.0.39-0ubuntu0.24.04.2
-- PHP Version: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `latest`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `eid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `user_name`, `password`, `eid`) VALUES
(1, 'admin', 'admin', 'admin@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `email`, `subject`, `message`) VALUES
(6, 'jhjkhjkj', 'manu@gmail.com', 'jhkkkj', 'gfghghhjj'),
(7, 'Rehan', 'rehan@gmail.com', 'hlo', 'hey');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `department_id` int NOT NULL,
  `department_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`department_id`, `department_name`) VALUES
(1, 'Faculty of Computer Science'),
(2, 'Faculty of Computing '),
(3, 'Faculty of Information Science'),
(4, 'Faculty of Computer Science & Technology'),
(5, 'English '),
(6, 'Myanmar'),
(7, 'Physics');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_id` int UNSIGNED NOT NULL,
  `rm_code` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `rm_type` varchar(20) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_id`, `rm_code`, `rm_type`) VALUES
(1, '231', 'B'),
(2, '232', 'B'),
(3, '233', 'B'),
(4, '234', 'B'),
(5, '235', 'B'),
(6, '236', 'B'),
(7, '321', 'A'),
(8, '322', 'A'),
(9, '323', 'A'),
(10, '324', 'A'),
(11, '325', 'A'),
(12, '326', 'A'),
(13, '331', 'A'),
(14, '332', 'A'),
(15, '333', 'A'),
(16, '334', 'A'),
(17, '335', 'A'),
(18, '336', 'A'),
(19, '351', 'KS'),
(20, '352', 'CS'),
(21, '353', 'HS'),
(22, '342', 'FS'),
(23, '255', 'PS'),
(24, '254', 'ES');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `section_id` int NOT NULL,
  `section_name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `timetable_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `semester_id` int NOT NULL,
  `overlap` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `consecutive` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`section_id`, `section_name`, `timetable_code`, `semester_id`, `overlap`, `consecutive`) VALUES
(11, 'secA', '', 1, '', NULL),
(12, 'secB', '', 1, NULL, NULL),
(13, 'secC', '', 1, NULL, NULL),
(14, 'secD', '', 1, '', NULL),
(15, 'secE', '', 1, '', NULL),
(31, 'secA', '', 3, NULL, NULL),
(32, 'secB', '', 3, '', NULL),
(33, 'secC', '', 3, '', NULL),
(34, 'secD', '', 3, '', NULL),
(35, 'secE', '', 3, '', NULL),
(41, 'secA', '', 4, '', NULL),
(42, 'secB', '', 4, '', NULL),
(43, 'secC', '', 4, '', NULL),
(523, 'secC', NULL, 52, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `semdep`
--

CREATE TABLE `semdep` (
  `assignment_id` int NOT NULL,
  `department_id` int NOT NULL,
  `semester_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `semdep`
--

INSERT INTO `semdep` (`assignment_id`, `department_id`, `semester_id`) VALUES
(1, 19, 1),
(2, 19, 3),
(3, 19, 4),
(4, 19, 2),
(5, 20, 1),
(6, 20, 2),
(7, 20, 3),
(8, 20, 4),
(9, 20, 5),
(10, 20, 6),
(11, 21, 1),
(12, 21, 2),
(13, 21, 3),
(14, 21, 4),
(15, 22, 1),
(16, 22, 2),
(17, 22, 3),
(18, 22, 4),
(19, 23, 1),
(20, 23, 2),
(21, 23, 3),
(22, 24, 1),
(23, 25, 1),
(24, 25, 2),
(25, 19, 5),
(26, 22, 5),
(27, 21, 5),
(28, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `id` int NOT NULL,
  `semester_id` int NOT NULL,
  `semester_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `subject1` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `subject2` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `subject3` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `subject4` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `subject5` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `subject6` varchar(30) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`id`, `semester_id`, `semester_name`, `subject1`, `subject2`, `subject3`, `subject4`, `subject5`, `subject6`) VALUES
(1, 1, 'sem1', 'CST-1201', 'CST-1301', 'CST-1401', 'CST-1501', 'CST-1601', 'CST-1701'),
(2, 3, 'sem3', 'CST-3103', 'CST-3202', 'CST-3302', 'CST-3303', 'CST-3402', 'CST-3503'),
(3, 4, 'sem4', 'CST-4104', 'CST-4202', 'CST-4304', 'CST-4305', 'CST-4403', 'CST-4504'),
(10, 52, 'sem5-CT', 'CST-1401', 'CST-3402', 'CST-3402', 'CST-3402', 'CST-3402', 'CST-4104');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `semester_id` int NOT NULL,
  `section_id` int NOT NULL,
  `stu_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `name`, `password`, `email`, `semester_id`, `section_id`, `stu_id`) VALUES
('cst1566', 'yin mon', '1111', 'yinmon@uit.edu.mm', 1, 11, 10),
('cst1234', 'kyal kyal', '1111', 'kyal@uit.edu.mm', 1, 11, 11),
('cst1646', 'Waing Maw Oo', '1111', 'wmo@uit.edu.mm', 1, 12, 12),
('cst1621', 'thiha wai phyo', '1111', 'thiha@uit.edu.mm', 3, 33, 13),
('cst1692', 'hnin su su hlaing', '1111', 'hssh@uit.edu.mm', 4, 42, 14);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subject_id` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `subject_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `need` varchar(6) COLLATE utf8mb4_general_ci NOT NULL,
  `id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_id`, `subject_name`, `type`, `need`, `id`) VALUES
('CST-1201', 'Calculus I	', 'A', 'AAAA', 3),
('CST-1301', 'Web Technology		', 'B', 'AABB', 4),
('CST-1401', 'Digital Fundamentals of Computer System		', 'A', 'AAAA', 5),
('CST-1501', 'English Language Proficiency I		', 'ES', 'ESAAA', 6),
('CST-1601', 'Myanmar Literature		', 'A', 'AAAA', 7),
('CST-1701', 'Physics (Mechanics)		', 'PS', 'PSAAA', 8),
('CST-3103', 'Operating Systems Fundamentals		', 'A', 'AAAA', 9),
('CST-3202', 'Discrete Structure I		', 'A', 'AAAA', 10),
('CST-3302', 'Software Modelling and Analysis		', 'A', 'AAAA', 11),
('CST-3303', 'Introduction to Business and Fundamental of Inform', 'A', 'AAAA', 12),
('CST-3402', 'Basic Engineering Circuit		', 'KS', 'KSAAA', 13),
('CST-3503', 'English Language Proficiency III		', 'A', 'AAAA', 14),
('CST-4104', 'Data Structure and Algorithms with Java		', 'B', 'AABB', 15),
('CST-4202', 'Discrete Structure II		', 'A', 'AAAA', 16),
('CST-4304', 'Human Computer Interaction &  Information Security', 'A', 'AAAA', 17),
('CST-4305', 'Database Management System		', 'B', 'AABB', 18),
('CST-4403', 'Networking Fundamentals		', 'B', 'AABB', 19),
('CST-4504', 'English Language Proficiency IV		', 'ES', 'ESAAA', 20),
('CST-5307', 'Advanced Web Technology		', 'B', 'AABB', 21),
('CST-5105', 'Artificial Intelligence 		', 'A', 'AAAA', 22),
('CST-5203', 'Engineering Mathematics 		', 'A', 'AAAA', 23),
('CST-5306', 'Software Requirement Engineering 		', 'A', 'AAAA', 24),
('CST-5404', 'Advanced Networking 		', 'CS', 'CSAAA', 25),
('CST-5405', 'Computer Architecture		', 'HS', 'HSAAA', 26),
('CST-5407', 'Engineering Circuits and Signals		', 'KS', 'KSAAA', 27);

-- --------------------------------------------------------

--
-- Table structure for table `teach`
--

CREATE TABLE `teach` (
  `day_P` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `alias` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `rm_code` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `subject_id` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `teacher_id` int NOT NULL,
  `section_id` int NOT NULL,
  `semester_id` int NOT NULL,
  `period_count` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `eid` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL,
  `mob` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacher_id`, `name`, `eid`, `password`, `mob`) VALUES
('111', 'Daw May Thet Swe', 'mts@uit.edu.mm', '1111', '0921474836'),
('113', 'Daw Thet Hsu Aung		', 'tha@uit.edu.mm', '1111', '092147483647'),
('114', 'Daw Aye Aye Aung', 'aaa@uit.edu.mm', '1111', '092147483647'),
('115', 'Dr.Ohnmar Nhway', 'on@uit.edu.mm', '1111', '092147483647'),
('116', 'Dr Thandar Zaw', 'tz@uit.edu.mm', '1111', '09975856581'),
('117', 'Daw Ohnmar Myint', 'omm@uit.edu.mm', '1111', '092147483647'),
('118', 'Daw Mon Zar kyaw		', 'mzk@uit.edu.mm', '1111', '092147483647'),
('119', 'Daw Me Me Swe Win		', 'mmsw@uit.edu.mm', '1111', '092147483647'),
('120', 'Daw Hnin Thida	', 'ht@uit.edu.mm', '1111', '092147483647'),
('121', 'Daw Astar		', 'a@uit.edu.mm', '1111', '092147483647'),
('122', 'Dr.Kyi May San		', 'kms@uit.edu.mm', '1111', '092147483647'),
('123', 'Daw Htet Nay Chi Win		', 'hnw@guit.edu.mm', '1111', '0987547574512'),
('124', 'Daw Lay Myat Myat Thein		', 'lmmt@uit.edu.mm', '1111', '099757476812'),
('125', 'Dr.Ei Thinn Su		', 'ets@uit.edu.mm', '1111', '09976767675'),
('126', 'Daw Yu May Paing		', 'ymp@uit.edu.mm', '1111', '098487887697'),
('127', 'Daw Khin Cho Latt', 'kcl@uit.edu.mm', '1111', '095875868902'),
('128', 'Dr.Thet Thet Aung ', 'tta@uit.edu.mm', '1111', '098857687902'),
('129', 'Dr.Khine Zarni Win		', 'kzw@uit.edu.mm', '1111', '0876879689909'),
('130', 'Dr. May Thu Myint', 'mtm@uit.edu.mm', '1111', '0994576896091'),
('34', 'Daw Khin Mar Wai		', 'kmw@uit.edu.mm', '1111', '02147483647'),
('35', 'Daw Kay Zin Tun		', 'kzt@uit.edu.mm', '1111', '092147483647'),
('36', 'Daw Me Me Ko		', 'mmk@uit.edu.mm', '1111', '092147483647'),
('37', 'Dr. Win Win Myo		', 'wwm@uit.edu.mm', '1111', '092147483647'),
('38', 'Dr.Tha Pyay Win		', 'tw@uit.edu.mm', '1111', '092147483647'),
('39', 'Dr.Hnin Thiri Zaw		', 'htz@uit.edu.mm', '1111', '092147483647'),
('40', 'Daw Shwe Sin Myat Than		', 'ssmt@uit.edu.mm', '1111', '092147483647'),
('41', 'Daw Htoo Htoo Aung		', 'hha@uit.edu.mm', '1111', '092147483647'),
('42', 'Dr.Tin Oo', 'to@uit.edu.mm', '1111', '092147483647'),
('43', 'Dr.Khin Lei Lei Kyaw		', 'kllk@uit.edu.mm', '1111', '092147483647'),
('45', 'Dr. Dim En Nyaung', 'den@uit.edu.mm', '1111', '092147483647'),
('46', 'Daw Sandar Win		', 'sw@uit.edu.mm', '1111', '099978723'),
('47', 'Daw San San Nwe		', 'ssn@uit.edu.mm', '1111', '0123234335'),
('48', 'Daw Akari Myint Soe		', 'ams@uit.edu.mm', '1111', '092147483647'),
('49', 'Daw Kyi Kyi Khine		', 'kkk@uit.edu.mm', '1111', '0121474836'),
('50', 'Daw Htar Htar Aung', 'htar@uit.edu.mm', '1111', '092147483647'),
('51', 'Dr.Aung Htein Maw		', 'ahm@uit.edu.mm', '1111', '096809956741'),
('52', 'Dr. Khin Myo Myo Min		', 'kmm@uit.edu.mm', '1111', '092147483647');

-- --------------------------------------------------------

--
-- Table structure for table `th_sub`
--

CREATE TABLE `th_sub` (
  `teacher_id` int NOT NULL,
  `subject_id` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `section_id` int NOT NULL,
  `semester_id` int NOT NULL,
  `th_sub_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `th_sub`
--

INSERT INTO `th_sub` (`teacher_id`, `subject_id`, `section_id`, `semester_id`, `th_sub_id`) VALUES
(36, 'CST-1201', 11, 1, 25),
(34, 'CST-1301', 11, 1, 26),
(38, 'CST-1401', 11, 1, 27),
(119, 'CST-1501', 11, 1, 28),
(42, 'CST-1601', 11, 1, 29),
(43, 'CST-1701', 11, 1, 30),
(36, 'CST-1201', 12, 1, 31),
(34, 'CST-1301', 12, 1, 32),
(39, 'CST-1401', 12, 1, 33),
(41, 'CST-1501', 12, 1, 34),
(42, 'CST-1601', 12, 1, 35),
(43, 'CST-1701', 12, 1, 36),
(37, 'CST-1201', 13, 1, 37),
(34, 'CST-1301', 13, 1, 38),
(40, 'CST-1401', 13, 1, 39),
(119, 'CST-1501', 13, 1, 40),
(42, 'CST-1601', 13, 1, 41),
(36, 'CST-1201', 14, 1, 42),
(35, 'CST-1301', 14, 1, 43),
(40, 'CST-1401', 14, 1, 44),
(119, 'CST-1501', 14, 1, 45),
(42, 'CST-1601', 14, 1, 46),
(122, 'CST-1701', 14, 1, 48),
(36, 'CST-1201', 15, 1, 49),
(34, 'CST-1301', 15, 1, 50),
(40, 'CST-1401', 15, 1, 51),
(41, 'CST-1501', 15, 1, 52),
(42, 'CST-1601', 15, 1, 53),
(45, 'CST-3103', 31, 3, 54),
(37, 'CST-3202', 31, 3, 55),
(47, 'CST-3302', 31, 3, 56),
(114, 'CST-3303', 31, 3, 57),
(115, 'CST-3402', 31, 3, 58),
(49, 'CST-3503', 31, 3, 59),
(45, 'CST-3103', 32, 3, 60),
(37, 'CST-3202', 32, 3, 61),
(116, 'CST-3302', 32, 3, 62),
(50, 'CST-3303', 32, 3, 63),
(117, 'CST-3402', 32, 3, 64),
(118, 'CST-3503', 32, 3, 65),
(45, 'CST-3103', 33, 3, 66),
(46, 'CST-3202', 33, 3, 67),
(47, 'CST-3302', 33, 3, 68),
(50, 'CST-3303', 32, 3, 69),
(48, 'CST-3402', 33, 3, 70),
(49, 'CST-3503', 33, 3, 71),
(45, 'CST-3103', 34, 3, 72),
(46, 'CST-3202', 34, 3, 73),
(116, 'CST-3302', 34, 3, 74),
(50, 'CST-3303', 34, 3, 75),
(48, 'CST-3402', 34, 3, 76),
(118, 'CST-3503', 34, 3, 77),
(45, 'CST-3103', 35, 3, 78),
(46, 'CST-3202', 35, 3, 79),
(47, 'CST-3302', 35, 3, 80),
(114, 'CST-3303', 35, 3, 81),
(48, 'CST-3402', 35, 3, 82),
(49, 'CST-3503', 35, 3, 83),
(128, 'CST-4104', 41, 4, 84),
(52, 'CST-4202', 41, 4, 85),
(111, 'CST-4304', 41, 4, 86),
(124, 'CST-4305', 41, 4, 87),
(125, 'CST-4403', 41, 4, 88),
(127, 'CST-4504', 41, 4, 89),
(128, 'CST-4104', 42, 4, 90),
(52, 'CST-4202', 42, 4, 91),
(123, 'CST-4304', 42, 4, 92),
(124, 'CST-4305', 42, 4, 93),
(125, 'CST-4403', 42, 4, 94),
(126, 'CST-4504', 42, 4, 95),
(128, 'CST-4104', 43, 4, 96),
(52, 'CST-4202', 43, 4, 97),
(111, 'CST-4304', 43, 4, 98),
(124, 'CST-4305', 43, 4, 99),
(39, 'CST-4403', 43, 4, 100),
(127, 'CST-4504', 43, 4, 101),
(122, 'CST-1701', 13, 1, 102),
(43, 'CST-1701', 15, 1, 103);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `eid` (`eid`),
  ADD KEY `user_name` (`user_name`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`section_id`),
  ADD KEY `fk_semster` (`semester_id`);

--
-- Indexes for table `semdep`
--
ALTER TABLE `semdep`
  ADD PRIMARY KEY (`assignment_id`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stu_id`),
  ADD KEY `semester` (`semester_id`),
  ADD KEY `section` (`section_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teach`
--
ALTER TABLE `teach`
  ADD PRIMARY KEY (`period_count`),
  ADD KEY `fk_sub_code` (`subject_id`),
  ADD KEY `fk_th_code` (`teacher_id`),
  ADD KEY `fk_section_code` (`section_id`),
  ADD KEY `fk_semester_id` (`semester_id`),
  ADD KEY `fk_rm_code` (`rm_code`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`),
  ADD UNIQUE KEY `eid` (`eid`);
ALTER TABLE `teacher` ADD FULLTEXT KEY `name` (`name`);

--
-- Indexes for table `th_sub`
--
ALTER TABLE `th_sub`
  ADD PRIMARY KEY (`th_sub_id`),
  ADD KEY `fk_th_code` (`teacher_id`),
  ADD KEY `fk_sub_code` (`subject_id`),
  ADD KEY `fk_section_code` (`section_id`),
  ADD KEY `fk_semster` (`semester_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `room_id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `semdep`
--
ALTER TABLE `semdep`
  MODIFY `assignment_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `stu_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `teach`
--
ALTER TABLE `teach`
  MODIFY `period_count` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `th_sub`
--
ALTER TABLE `th_sub`
  MODIFY `th_sub_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
