<?php
error_reporting(1); // Suppress non-critical warnings

// Specify the new MySQL port in the mysqli_connect function
$con = mysqli_connect("localhost", "wild", "Waing@4421661", "latest");

// Check if the connection failed
if (!$con) {
    die("Connection failed: " . mysqli_connect_error()); // Display error message if connection fails
}
?>
