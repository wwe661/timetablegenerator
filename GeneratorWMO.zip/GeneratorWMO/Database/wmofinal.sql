-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 10, 2024 at 09:15 PM
-- Server version: 8.0.39-0ubuntu0.24.04.2
-- PHP Version: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wmofinal`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `eid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `department_id` int NOT NULL,
  `department_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `ID` int UNSIGNED NOT NULL,
  `rm_code` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `rm_type` varchar(20) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`ID`, `rm_code`, `rm_type`) VALUES
(1, '231', 'B'),
(2, '232', 'B'),
(3, '233', 'B'),
(4, '234', 'B'),
(5, '235', 'B'),
(6, '236', 'B'),
(7, '321', 'A'),
(8, '322', 'A'),
(9, '323', 'A'),
(10, '324', 'A'),
(11, '325', 'A'),
(12, '326', 'A'),
(13, '331', 'A'),
(14, '332', 'A'),
(15, '333', 'A'),
(16, '334', 'A'),
(17, '335', 'A'),
(18, '336', 'A'),
(19, '353', 'K'),
(20, '352', 'C'),
(21, '351', 'H'),
(22, '342', 'F'),
(23, '245', 'P'),
(24, '244', 'E'),
(26, '214', 'A'),
(27, '215', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `section_id` int NOT NULL,
  `section_name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `timetable_code` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `semester_id` int NOT NULL,
  `overlap` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `consecutive` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`section_id`, `section_name`, `timetable_code`, `semester_id`, `overlap`, `consecutive`) VALUES
(11, 'secA', NULL, 1, NULL, NULL),
(12, 'secB', NULL, 1, NULL, NULL),
(13, 'secC', NULL, 1, NULL, NULL),
(14, 'secD', NULL, 1, NULL, NULL),
(15, 'secE', NULL, 1, NULL, NULL),
(31, 'secA', NULL, 3, NULL, NULL),
(32, 'secB', NULL, 3, NULL, NULL),
(33, 'secC', NULL, 3, NULL, NULL),
(34, 'secD', NULL, 3, NULL, NULL),
(35, 'secE', NULL, 3, NULL, NULL),
(511, 'secA', NULL, 51, NULL, NULL),
(512, 'secB', NULL, 51, NULL, NULL),
(513, 'secC', NULL, 51, NULL, NULL),
(514, 'secD', NULL, 51, NULL, NULL),
(521, 'secA', NULL, 52, NULL, NULL),
(611, 'secA', NULL, 61, NULL, NULL),
(612, 'secB', NULL, 61, NULL, NULL),
(613, 'secC', NULL, 61, NULL, NULL),
(621, 'secA', NULL, 62, NULL, NULL),
(711, 'secA', NULL, 71, NULL, NULL),
(721, 'secA', NULL, 72, NULL, NULL),
(731, 'secA', NULL, 73, NULL, NULL),
(741, 'secA', NULL, 74, NULL, NULL),
(751, 'secA', NULL, 75, NULL, NULL),
(761, 'secA', NULL, 76, NULL, NULL),
(911, 'secA', NULL, 91, NULL, NULL),
(921, 'secA', NULL, 92, NULL, NULL),
(931, 'secA', NULL, 93, NULL, NULL),
(941, 'secA', NULL, 94, NULL, NULL),
(951, 'secA', NULL, 95, NULL, NULL),
(1111, 'AAAA', NULL, 1111, NULL, '5');

-- --------------------------------------------------------

--
-- Table structure for table `semdep`
--

CREATE TABLE `semdep` (
  `assignment_id` int NOT NULL,
  `department_id` int NOT NULL,
  `semester_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `id` int NOT NULL,
  `semester_id` int NOT NULL,
  `semester_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `subject1` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `subject2` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `subject3` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `subject4` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `subject5` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `subject6` varchar(30) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`id`, `semester_id`, `semester_name`, `subject1`, `subject2`, `subject3`, `subject4`, `subject5`, `subject6`) VALUES
(1, 1, 'sem1', 'CST-1201', 'CST-1301', 'CST-1401', 'CST-1501', 'CST-1601', 'CST-1701'),
(2, 3, 'sem3', 'CST-3102', 'CST-3103', 'CST-3202', 'CST-3302', 'CST-3303', 'CST-3503'),
(3, 51, 'sem5-CS', 'CS-5307', 'CST-5105', 'CST-5203', 'CST-5306', 'CST-5404', 'CST-5405'),
(4, 52, 'sem5-CT', 'CT-5407', 'CST-5105', 'CST-5203', 'CST-5306', 'CST-5404', 'CST-5405'),
(5, 61, 'sem6-CS', 'CST-6106', 'CST-6107', 'CST-6204', 'CST-6308', 'CST-6406', 'CST-6108'),
(6, 62, 'sem6-CT', 'CST-6106', 'CST-6107', 'CST-6204', 'CST-6308', 'CST-6406', 'CST-6108'),
(7, 71, 'sem7-SE', 'CS-7109', 'CS-7311', 'CS-7312', 'CS-7313', 'CS-7314', 'CST-7505'),
(2222, 1111, 'test', '1111', '2222', '3333', '4444', '5555', '6666'),
(2223, 72, 'sem7-KE', 'CS-7109', 'CST-7416', 'CS-7312', 'KE-7112', 'KE-7113', 'CST-7505'),
(2224, 73, 'sem7-HPC', 'CS-7109', 'CST-7110', 'CST-7412', 'CST-7413', 'HPC-7111', 'CST-7505'),
(2225, 74, 'sem7-BIS', 'BIS-7315', 'CS-7311', 'CS-7312', 'CS-7313', 'CS-7314', 'CST-7505'),
(2226, 75, 'sem7-CN', 'CN-7410', 'CST-7110', 'CST-7412', 'CST-7413', 'CN-7411', 'CST-7505'),
(2227, 76, 'sem7-ES', 'ES-7207', 'CST-7416', 'ES-7417', 'ES-7418', 'ES-7419', 'CST-7505'),
(2228, 91, 'sem9-SE', 'CS-9124', 'CS-9320', 'CST-9212', 'SE-9325', 'SE-9326', 'SE-9327'),
(2229, 92, 'sem9-KE', 'CS-9124', 'KE-9125', 'CST-9212', 'KE-9126', 'KE-9127', 'KE-9128'),
(2230, 93, 'sem9-HPC', 'CST-9119', 'HPC-9120', 'CST-9212', 'HPC-9121', 'HPC-9122', 'HPC-9123'),
(2231, 94, 'sem9-BIS', 'BIS-9321', 'CS-9320', 'CST-9212', 'BIS-9322', 'BIS-9323', 'BIS-9324'),
(2232, 95, 'sem9-CN', 'CST-9119', 'CT-9427', 'CST-9212', 'CN-9424', 'CN-9425', 'CN-9426');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `semester_id` int NOT NULL,
  `section_id` int NOT NULL,
  `stu_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subject_id` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `subject_name` varchar(80) COLLATE utf8mb4_general_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `need` varchar(6) COLLATE utf8mb4_general_ci NOT NULL,
  `id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_id`, `subject_name`, `type`, `need`, `id`) VALUES
('CST-1201', 'Calclus', 'A', 'AAAA', 1),
('CST-1301', 'Introduction to Business and Fundamentals of Information Systems(sem1)', 'B', 'BBAA', 2),
('CST-1401', 'Digital Fundamentals of Computer Systems', 'B', 'BAAA', 3),
('CST-1501', 'Intregrating Critical Thought and Language Skills', 'E', 'EAAA', 4),
('CST-1601', 'Myanmar Literature', 'A', 'AAAA', 5),
('CST-1701', 'Physics (Mechanics and Electromagnetism)', 'P', 'PPAA', 6),
('CST-3102', 'Data Structure and Algorithms', 'A', 'AAAA', 7),
('CST-3103', 'Operating Systems Fundamentals', 'B', 'BBBB', 8),
('CST-3202', 'Discrete Structure I', 'A', 'AAAA', 9),
('CST-3302', 'Software Modelling and Analysis', 'B', 'BAAA', 10),
('CST-3303', 'Introduction to Business and Fundamentals of Information Systems', 'B', 'BAAA', 11),
('CST-3503', 'English Language Proficiency III', 'E', 'EAAA', 12),
('CS-5307', 'Advanced WebTechnology', 'B', 'BBBB', 13),
('CST-5105', 'Artificial Intelligence', 'A', 'AAAA', 14),
('CST-5203', 'Engineering Mathematics', 'B', 'BAAA', 15),
('CST-5306', 'Software Requirement Engineering', 'B', 'BAAA', 16),
('CST-5404', 'Advanced Networking', 'B', 'BAAA', 17),
('CST-5405', 'Computer Architecture', 'B', 'BAAA', 18),
('CT-5407', 'Engineering Circuit and Signals', 'B', 'BAAA', 19),
('CST-6106', 'Social Issues and Ethics', 'A', 'AAAA', 20),
('CST-6107', 'Computer Organization', 'B', 'BBAA', 21),
('CST-6204', 'Linear Algebra', 'A', 'AAAA', 22),
('CST-6308', 'Management Principled & Engineering Economics', 'A', 'AAAA', 23),
('CST-6406', 'Network Design & Engineering', 'B', 'BBAA', 24),
('CS-6309', 'Microservices for the Enterprise', 'A', 'AAAA', 25),
('CS-6310', 'Introduction to Entrepreneurshinp', 'A', 'AAAA', 26),
('CST-6410', 'Foundations of Cybersecurity', 'A', 'AAAA', 27),
('CST-6108', 'Enterprise Applications Development Using Java', 'B', 'BBBB', 28),
('CT-6408', 'Electronic Devies for Embedded Systems', 'A', 'AAAA', 29),
('CT-6409', 'Data and Computer Communications', 'A', 'AAAA', 30),
('CS-7109', 'Analysis of Algorithms', 'A', 'AAAA', 31),
('CS-7311', 'Business Management Information Systems', 'A', 'AAAA', 32),
('CS-7312', 'Enterprise Systems, Security and Risk Management', 'B', 'BAAA', 33),
('CS-7313', 'Advanced Database Management System', 'B', 'BAAA', 34),
('CS-7314', 'Software Quality Management', 'B', 'BAAA', 35),
('CST-7505', 'Technical Writing for Professional Development', 'B', 'BAAA', 36),
('CST-7416', 'Fuzzy Logic System', 'A', 'AAAA', 37),
('KE-7112', 'Computer Graphics', 'B', 'BBAA', 38),
('KE-7113', 'Knowledge Engineering and Intelligent Systems', 'B', 'BAAA', 39),
('CST-7110', 'Distributed Systems', 'A', 'AAAA', 40),
('CST-7412', 'Network Management and Monitoring', 'B', 'BAAA', 41),
('CST-7413', 'Cryptographic Techniques and Data Security', 'A', 'AAAA', 42),
('HPC-7111', 'Introduction to High Performance Computing', 'B', 'BAAA', 43),
('BIS-7315', 'Business Process Management 		', 'A', 'AAAA', 44),
('CN-7410', 'Network Operating System', '', '', 45),
('CN-7411', 'Wireless and Mobile Communications', 'B', 'BAAA', 46),
('ES-7207', 'Mathematical Models of System and Control	', '', '', 47),
('ES-7417', 'Microcontroller Programming		', '', '', 48),
('ES-7418', 'Sensors & Electronics', '', '', 49),
('ES-7419', 'Control System		', '', '', 50),
('CS-9124', 'Interactive Multimedia Systems', 'B', 'BAAA', 51),
('CS-9320', 'Service Oriented Architecture:Concept and Technolo', 'B', 'BBAA', 52),
('CST-9212', 'Stochastic Models', 'A', 'AAAA', 53),
('SE-9325', 'Machine Learning  with Data Visualization', 'B', 'BAAA', 54),
('SE-9326', 'Advanced Software Engineering', 'B', 'BBBA', 55),
('SE-9327', 'Data processing Techniques in Distributed  Systems', 'A', 'AAAA', 56),
('KE-9125', 'Computational Liguistics', 'B', 'BBAA', 57),
('KE-9126', 'Data Science for Business', 'B', 'BAAA', 58),
('KE-9127', 'Semantic Web and Ontology Engineering', 'B', 'BBBA', 59),
('KE-9128', 'Design, Concepts and Methodology for Knowledge-bas', 'B', 'BBBA', 60),
('CST-9119', 'Data Center Networking and the New Converged Inter', 'B', 'BBAA', 61),
('HPC-9120', 'Virtualization Technology and Cloud Computing ', 'B', 'BAAA', 62),
('HPC-9121', 'Blockchain Technology and the Internet of Things', 'F', 'FAAA', 63),
('HPC-9122', 'High Performance Big Data Analytics', 'F', 'FFFF', 64),
('HPC-9123', 'Design and Concepts for Building a Modern Computin', 'F', 'FFFF', 65),
('BIS-9321', 'Business Intelligence', 'B', 'BAAA', 66),
('BIS-9322', 'Information Systems Project Management', 'B', 'BAAA', 67),
('BIS-9323', 'IT/IS Strategy, Management and Acquisition', 'B', 'BAAA', 68),
('BIS-9324', 'Accounting for Managers', 'A', 'AAAA', 69),
('CN-9424', 'Network and Internet Security', 'C', 'CCCC', 70),
('CN-9425', 'Broadband Communication and Mobile Networking', 'B', 'BAAA', 71),
('CN-9426', ' Advanced Network  Design and Performance Computin', 'B', 'BAAA', 72),
('CT-9427', 'Digital Forensics	', 'H', 'HBAA', 73),
('1111', 'blah1', 'A', 'AAAA', 1111),
('2222', 'blah2', 'B', 'BBAA', 2222),
('3333', 'balh3', 'A', 'AAAA', 3333),
('4444', 'blah4', 'B', 'BAAA', 4444),
('5555', 'blah5', 'E', 'EEAA', 5555),
('6666', 'blah6', 'P', 'PPAA', 6666);

-- --------------------------------------------------------

--
-- Table structure for table `teach`
--

CREATE TABLE `teach` (
  `day_P` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `alias` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `rm_code` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `subject_id` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `teacher_id` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `section_id` int NOT NULL,
  `semester_id` int NOT NULL,
  `period_count` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `eid` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `password` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `mob` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacher_id`, `name`, `eid`, `password`, `mob`) VALUES
('CST-1', 'Daw Lay Myat Myat Thein', NULL, NULL, NULL),
('CST-10', 'Daw Khin Mar Wai', NULL, NULL, NULL),
('CST-11', 'Dr. Zin Mar Kyu', NULL, NULL, NULL),
('CST-12', 'Daw Khin Ei Ei Chaw', NULL, NULL, NULL),
('CST-13', 'Dr. Hlaing Htake Khaung Tin', NULL, NULL, NULL),
('CST-14', 'Daw Khin Sandi Bo', NULL, NULL, NULL),
('CST-15', 'Dr. Kyawe Kyawe San', NULL, NULL, NULL),
('CST-16', 'Dr. Than Than Nwe', NULL, NULL, NULL),
('CST-17', 'Dr. Aye Chan Mon', NULL, NULL, NULL),
('CST-18', 'Dr. Tha Pyay Win', NULL, NULL, NULL),
('CST-19', 'Daw Aye Thant Thant Moe', NULL, NULL, NULL),
('CST-2', 'Daw Htet Nay Chi Lyinn', NULL, NULL, NULL),
('CST-20', 'Daw Su Su Naing', NULL, NULL, NULL),
('CST-21', 'Dr. Hnin Thiri Zaw', NULL, NULL, NULL),
('CST-22', 'Daw Ohnmar Myint', NULL, NULL, NULL),
('CST-23', 'Dr. Aung Htein Maw', NULL, NULL, NULL),
('CST-24', 'Daw Akari Myint Soe', NULL, NULL, NULL),
('CST-25', 'Dr. Ei Thin Su', NULL, NULL, NULL),
('CST-26', 'Dr. Thiri Thitsar Khaing', NULL, NULL, NULL),
('CST-28', 'Daw Shwe Sin Myat Than', NULL, NULL, NULL),
('CST-29', 'Dr. Myat Thida Mon', NULL, NULL, NULL),
('CST-3', 'Daw Kay Zin Htun', NULL, NULL, NULL),
('CST-30', 'Dr. Thet Thet Zin', NULL, NULL, NULL),
('CST-31', 'Dr. May Thu Myint', NULL, NULL, NULL),
('CST-32', 'Dr. Mhway Mhway Tar', NULL, NULL, NULL),
('CST-33', 'Daw Htar Htar Aung', NULL, NULL, NULL),
('CST-34', 'Daw Soe Kalayar Naing', NULL, NULL, NULL),
('CST-35', 'Dr. May Thet Htun', NULL, NULL, NULL),
('CST-36', 'Dr. Hay Mar Moh Moh Lwin', NULL, NULL, NULL),
('CST-37', 'Dr. Win Win Thant', NULL, NULL, NULL),
('CST-38', 'Dr. Nwe Nwe Myint Thein', NULL, NULL, NULL),
('CST-39', 'Dr. Myat Pwint Phyu', NULL, NULL, NULL),
('CST-4', 'Daw Jiin San Mann', NULL, NULL, NULL),
('CST-40', 'Dr. Aye Myat Myat Paing', NULL, NULL, NULL),
('CST-41 ', 'Dr. Ei Moh Moh Aung', NULL, NULL, NULL),
('CST-42', 'Dr. Aung Nway Oo', NULL, NULL, NULL),
('CST-43', 'Dr. Thin Thin Wai', NULL, NULL, NULL),
('CST-44', 'Daw Lei Lei Lynn', NULL, NULL, NULL),
('CST-45', 'Daw Thae Nu Aye', NULL, NULL, NULL),
('CST-46', 'Daw Aye Aye Aung', NULL, NULL, NULL),
('CST-47', 'Daw Ni Win Bo', NULL, NULL, NULL),
('CST-48', 'Daw Thin Thin Wai', NULL, NULL, NULL),
('CST-49', 'Dr. Ohnmar Nhway', NULL, NULL, NULL),
('CST-5', 'Daw San San Nwe', NULL, NULL, NULL),
('CST-50', 'C1', NULL, NULL, NULL),
('CST-51', 'C2', NULL, NULL, NULL),
('CST-52', 'C3', NULL, NULL, NULL),
('CST-53', 'E1', NULL, NULL, NULL),
('CST-54', 'E2', NULL, NULL, NULL),
('CST-55', 'E3', NULL, NULL, NULL),
('CST-56', 'M1', NULL, NULL, NULL),
('CST-57', 'M2', NULL, NULL, NULL),
('CST-58', 'M3', NULL, NULL, NULL),
('CST-59', 'P1', NULL, NULL, NULL),
('CST-6', 'Daw Htay Htay Win', NULL, NULL, NULL),
('CST-60', 'P2', NULL, NULL, NULL),
('CST-61', 'P3', NULL, NULL, NULL),
('CST-7', 'Daw Win PaPa May Phyoe Aung', NULL, NULL, NULL),
('CST-8', 'Daw Lei Yi Win Lwin', NULL, NULL, NULL),
('CST-9', 'Daw May Thet Swe', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `th_sub`
--

CREATE TABLE `th_sub` (
  `teacher_id` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `subject_id` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `section_id` int NOT NULL,
  `semester_id` int NOT NULL,
  `th_sub_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `th_sub`
--

INSERT INTO `th_sub` (`teacher_id`, `subject_id`, `section_id`, `semester_id`, `th_sub_id`) VALUES
('CST-1', 'CST-1301', 11, 1, 1),
('CST-1', 'CST-1301', 12, 1, 2),
('CST-1', 'SE-9327', 911, 91, 3),
('CST-2', 'CST-1301', 13, 1, 4),
('CST-2', 'CST-1301', 14, 1, 5),
('CST-2', 'CST-1301', 15, 1, 6),
('CST-5', 'CST-3302', 31, 3, 7),
('CST-5', 'CST-5306', 511, 51, 8),
('CST-5', 'CST-5306', 512, 51, 9),
('CST-4', 'CST-3302', 33, 3, 11),
('CST-3', 'CST-3302', 34, 3, 12),
('CST-3', 'CST-3302', 35, 3, 13),
('CST-4', 'CST-5306', 513, 51, 14),
('CST-4', 'CST-3302', 32, 3, 16),
('CST-8', 'CST-5306', 514, 51, 17),
('CST-3', 'CS-7314', 711, 71, 18),
('CST-6', 'CST-3303', 31, 3, 19),
('CST-6', 'CST-3303', 32, 3, 20),
('CST-6', 'CST-6308', 611, 61, 21),
('CST-7', 'CST-3303', 33, 3, 22),
('CST-7', 'CST-3303', 34, 3, 23),
('CST-7', 'CST-3303', 35, 3, 24),
('CST-11', 'CS-5307', 511, 51, 26),
('CST-11', 'SE-9326', 911, 91, 27),
('CST-9', 'CS-5307', 512, 51, 28),
('CST-10', 'CS-5307', 514, 51, 30),
('CST-10', 'BIS-9322', 941, 94, 31),
('CST-9', 'CS-7312', 711, 71, 32),
('CST-9', 'CS-5307', 513, 51, 33),
('CST-12', 'CST-6308', 612, 61, 34),
('CST-12', 'CST-6308', 613, 61, 35),
('CST-12', 'BIS-9323', 941, 94, 36),
('CST-13', 'BIS-7315', 741, 74, 37),
('CST-14', 'CS-7311', 711, 71, 38),
('CST-15', 'CS-7313', 711, 71, 39),
('CST-16', 'BIS-9321', 941, 94, 40),
('CST-13', 'BIS-9324', 941, 94, 41),
('CST-17', 'CS-9320', 911, 91, 42),
('CST-15', 'SE-9325', 911, 91, 43),
('CST-29', 'CN-9426', 951, 95, 44),
('CST-29', 'ES-7418', 761, 76, 45),
('CST-23', 'CST-5404', 511, 51, 46),
('CST-23', 'CST-6406', 611, 61, 47),
('CST-18', 'CST-5405', 511, 51, 48),
('CST-18', 'CST-5405', 512, 51, 49),
('CST-18', 'ES-7417', 761, 76, 50),
('CST-26', 'CST-7412', 751, 75, 51),
('CST-26', 'CT-9427', 951, 95, 52),
('CST-25', 'CST-6406', 612, 61, 53),
('CST-25', 'CST-6406', 613, 61, 54),
('CST-49', 'CN-9425', 951, 95, 55),
('CST-22', 'CT-5407', 521, 52, 56),
('CST-22', 'CST-7416', 721, 72, 57),
('CST-24', 'CST-1401', 11, 1, 58),
('CST-28', 'CST-5405', 513, 51, 59),
('CST-28', 'ES-7419', 761, 76, 60),
('CST-21', 'CST-5404', 512, 51, 61),
('CST-21', 'CST-5404', 513, 51, 62),
('CST-21', 'CN-7410', 751, 75, 63),
('CST-19', 'CST-1401', 12, 1, 64),
('CST-19', 'CST-1401', 13, 1, 65),
('CST-20', 'CST-1401', 14, 1, 66),
('CST-20', 'CST-1401', 15, 1, 67),
('CST-44', 'CST-3102', 31, 3, 68),
('CST-45', 'CST-3102', 32, 3, 69),
('CST-45', 'CST-3102', 33, 3, 70),
('CST-45', 'CST-3102', 34, 3, 71),
('CST-35', 'CST-3102', 35, 3, 72),
('CST-41 ', 'CST-3103', 31, 3, 73),
('CST-47', 'CST-3103', 32, 3, 74),
('CST-46', 'CST-3103', 33, 3, 75),
('CST-46', 'CST-3103', 34, 3, 76),
('CST-47', 'CST-3103', 35, 3, 77),
('CST-43', 'CST-5105', 511, 51, 78),
('CST-30', 'CST-5105', 512, 51, 79),
('CST-31', 'CST-5105', 513, 51, 80),
('CST-31', 'CST-5105', 514, 51, 81),
('CST-32', 'CST-6106', 611, 61, 82),
('CST-33', 'CST-6106', 612, 61, 83),
('CST-33', 'CST-6106', 613, 61, 84),
('CST-31', 'CST-6107', 611, 61, 85),
('CST-34', 'CST-6107', 612, 61, 86),
('CST-34', 'CST-6107', 613, 61, 87),
('CST-35', 'CST-6108', 611, 61, 88),
('CST-36', 'CST-6108', 612, 61, 89),
('CST-36', 'CST-6108', 613, 61, 90),
('CST-37', 'CS-7109', 711, 71, 91),
('CST-44', 'CS-7109', 721, 72, 92),
('CST-44', 'CS-7109', 731, 73, 93),
('CST-38', 'CST-7110', 751, 75, 94),
('CST-38', 'CST-7110', 731, 73, 95),
('CST-39', 'HPC-7111', 731, 73, 96),
('CST-41 ', 'KE-7112', 721, 72, 97),
('CST-30', 'KE-7113', 721, 72, 98),
('CST-40', 'CST-9119', 951, 95, 99),
('CST-40', 'HPC-9120', 931, 93, 100),
('CST-38', 'HPC-9121', 931, 93, 101),
('CST-39', 'HPC-9122', 931, 93, 102),
('CST-42', 'CS-9124', 911, 91, 103),
('CST-36', 'CS-9124', 921, 92, 104),
('CST-37', 'KE-9125', 921, 92, 105),
('CST-32', 'KE-9126', 921, 92, 106),
('CST-43', 'KE-9127', 921, 92, 107),
('CST-50', 'CST-1201', 11, 1, 108),
('CST-51', 'CST-1201', 12, 1, 109),
('CST-51', 'CST-1201', 13, 1, 110),
('CST-50', 'CST-1201', 14, 1, 111),
('CST-52', 'CST-1201', 15, 1, 112),
('CST-53', 'CST-1501', 11, 1, 113),
('CST-53', 'CST-1501', 12, 1, 114),
('CST-54', 'CST-1501', 13, 1, 115),
('CST-54', 'CST-1501', 14, 1, 116),
('CST-55', 'CST-1501', 15, 1, 117),
('CST-56', 'CST-1601', 11, 1, 118),
('CST-56', 'CST-1601', 12, 1, 119),
('CST-57', 'CST-1601', 13, 1, 120),
('CST-57', 'CST-1601', 14, 1, 121),
('CST-58', 'CST-1601', 15, 1, 122),
('CST-59', 'CST-1701', 11, 1, 123),
('CST-59', 'CST-1701', 12, 1, 124),
('CST-60', 'CST-1701', 13, 1, 125),
('CST-60', 'CST-1701', 14, 1, 126),
('CST-61', 'CST-1701', 15, 1, 127);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `eid` (`eid`),
  ADD KEY `user_name` (`user_name`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`section_id`),
  ADD KEY `fk_semster` (`semester_id`);

--
-- Indexes for table `semdep`
--
ALTER TABLE `semdep`
  ADD PRIMARY KEY (`assignment_id`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stu_id`),
  ADD KEY `semester` (`semester_id`),
  ADD KEY `section` (`section_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teach`
--
ALTER TABLE `teach`
  ADD PRIMARY KEY (`period_count`),
  ADD KEY `fk_sub_code` (`subject_id`),
  ADD KEY `fk_th_code` (`teacher_id`),
  ADD KEY `fk_section_code` (`section_id`),
  ADD KEY `fk_semester_id` (`semester_id`),
  ADD KEY `fk_rm_code` (`rm_code`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`),
  ADD UNIQUE KEY `eid` (`eid`);
ALTER TABLE `teacher` ADD FULLTEXT KEY `name` (`name`);

--
-- Indexes for table `th_sub`
--
ALTER TABLE `th_sub`
  ADD PRIMARY KEY (`th_sub_id`),
  ADD KEY `fk_th_code` (`teacher_id`),
  ADD KEY `fk_sub_code` (`subject_id`),
  ADD KEY `fk_section_code` (`section_id`),
  ADD KEY `fk_semster` (`semester_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `ID` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `semdep`
--
ALTER TABLE `semdep`
  MODIFY `assignment_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2233;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `stu_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6669;

--
-- AUTO_INCREMENT for table `teach`
--
ALTER TABLE `teach`
  MODIFY `period_count` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `th_sub`
--
ALTER TABLE `th_sub`
  MODIFY `th_sub_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
