<?php
class materials{
    public $table;
    public $index;
    public $sub;//substr
    public function __construct($table = [],$index=[],$sub=[]){
        $this->table=$table;
        $this->index=$index;
        $this->sub=$sub;
    }
}
class subject {
public $sub_name;
public $sub_teacher;
public $sub_period;
public $frpdofth;
public $sub_type;
public $amtime = 2;
public $pmtime = 2;
private $pream ;
private $prepm;
public function amrec(){
    $this->pream=$this->amtime;
}
public function pmrec(){
    $this->prepm=$this->pmtime;
}
public function rollback(){
$this->amtime =$this->pream;
$this->pmtime =$this->prepm;
}
}
$errors = [];

function customErrorHandler($errno, $errstr) {
    global $errors;
    $errors[] = $errstr;
}
set_error_handler('customErrorHandler');
//create subjects teached by different teacher
$box=new materials;
$sub1=new subject;
$sub2=new subject;
$sub3=new subject;
$sub4=new subject;
$sub5=new subject;
$sub6=new subject;
$sub_str = [$sub1,$sub2,$sub3,$sub4,$sub5,$sub6];
function connect(){
    $dsn = "mysql:host=localhost;dbname=mydatabase";
    $username = "root";
    $password = "";
    try{
        $conn = new PDO($dsn, $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
    }
    return $conn;
}
//default layout
function out_layout($table){
$dates = ["Monday","Tueday","Wednesday","Thursday","Friday"];
$periods = ["8:30am - 9:30am","9:40am - 10:40am","10:50am - 11:50am","11:50am - 12:40pm","12:40pm - 1:40pm","1:50pm - 2:50pm","3:00pm - 4:00pm"];
$table[0][0] = "DAYS\PERIODS";
for($p=1;$p<=7;$p++) {
    $table[0][$p] = $periods[$p-1];
}
for($d=1;$d<=5;$d++) {
    $table[$d][0] = $dates[$d-1];
    $table[$d][4] = "Lunch";
}

return $table;
}
function free_time($tablecl,$sem){
    // echo "<br>Adding free periods";
    $table=$tablecl->table;
    $def_index=$tablecl->index;
    $sub_str=$tablecl->sub;
//make 4 random free periods free
//Mon=6,Thu=6,Tue=4,Fri=4
$count=0;

    while($count<2){ 
       $free=rand(0,2);
       do{
       $free1=rand(0,2);
       }while($free==$free1);
       $free2= rand(3,5);
        if(!isset($table[1][$free])&&!isset($table[1][$free2])&&$count==0){//i!isset is used to check data overlap
        $table[1][$free]="no data";
        $ind[1][$free]=6;
        $table[1][$free2]="no data";
        $ind[1][$free2]=6;
        $count++;
        }elseif(!isset($table[2][$free])&&!isset($table[2][$free2])&&$count==1&&$sem>3){
        $table[2][$free]="no data";
        $ind[2][$free]=6;
        $table[2][$free2]="no data";
        $ind[2][$free2]=6;
        $count++;
        }
        elseif(!isset($table[4][$free])&&!isset($table[4][$free2])&&$count==1){
        $table[4][$free]="no data";
        $ind[4][$free]=6;
        $table[4][$free2]="no data";
        $ind[4][$free2]=6;
        $count++;
        }
    }
//2 default free time on Wednesday for third years and above else on Friday
if($sem<=3){//there will be complete control later
    $table[2][4]="no data";
    $table[2][5]="no data";
    $ind[2][4]=6;
    $ind[2][5]=6;
}else{
    $table[4][4]="no data";
    $table[4][5]="no data";
    $ind[4][4]=6;
    $ind[4][5]=6;
}
$revar =new materials($table,$def_index,$sub_str);
  return $revar;
}
function fill_cell($material,$ind){
    echo "<br> Covering empty slots";
    $table=$material->table;
    // $ind=$material->ind;
    $sub_str=$material->sub;
    // print_r($sub_str);
    for($i=0;$i<=5;$i++){
        $sub_instance[$i]=$sub_str[$i]->sub_name;
        }
        $amneed =0;$pmneed=0;$i=0;$j=0;
    foreach($sub_str as $key =>$value){
        if($value->amtime>0){$amneed++;$subjectam[]=$key;$temp=$key;}
        elseif($value->pmtime>0){$pmneed++;$subjectpm[]=$key;$temp=$key;}
    }
    $len=count($table[0])-1;
    for($date=0;$date<=count($table)-1;$date++){
        for($period=0;$period<=$len;$period++){
            if(!isset($table[$date][$period])) {//only if no data present
                $exc=array_values(array_diff([0,1,2,3,4,5],$ind[$date]));//take subindexes that are not in here

            if($period<3){
                if(!in_array($subjectam[$i],$ind[$date])){//if the left is not in empty cell arr,
                    // echo "def=ind";
                    $table[$date][$period] = $sub_instance[$subjectam[$i]];//put into empty cell
                    $ind[$date][$period]=$subjectam[$i];$i++;break;
                }
                else{
                    // echo"def!=ind";
                    foreach($ind as $key => $value){//echo $key;search the whole array
                    if(isset($subjectam[$i])&&!in_array($subjectam[$i],$value)){//echo "def is not in here";for a row that doesn't have the left sub
                        for($k=0;$k<count($exc);$k++){
                            // if($c>=2&&$period<4)continue;
                            //  else{
                        if(in_array ($exc[$k],$value)){//echo "exc is in here";about to swap so notin subindex existed row is taked
                            $index = array_search($exc[$k],$value);//take cell key where the not in exist
                            if($index >2)continue;//for am time
                            $table[$key][$index]=$sub_instance[$subjectam[$i]];//exc is overwrited
                            $ind[$key][$index] = $subjectam[$i];//in index too
                            $table[$date][$period]=$sub_instance[$exc[$k]];//emptycell is filled
                            $ind[$date][$period]=$exc[$k];
                            $i++;//insummary the cell are swapped and empt get filled
                            break;}
                        // }
                        }
                        break;
                    }
                }

                }break;
            }
            else{
                if(!in_array($subjectpm[$j],$ind[$date])){//if the left is not in empty cell arr,
                    // echo "def=ind";
                    $table[$date][$period] = $sub_instance[$subjectpm[$j]];//put into empty cell
                    $ind[$date][$period]=$subjectpm[$i];$j++;break;
                }
                else{
                    // echo"def!=ind";
                    foreach($ind as $key => $value){//echo $key;search the whole array
                    if(isset($subjectpm[$j])&&!in_array($subjectpm[$j],$value)){//echo "def is not in here";for a row that doesn't have the left sub
                        for($k=0;$k<count($exc);$k++){
                            // if($c>=2&&$period<4)continue;
                            //  else{
                        if(in_array ($exc[$k],$value)){//echo "exc is in here";about to swap so notin subindex existed row is taked
                            $index = array_search($exc[$k],$value);//take cell key where the not in exist
                            if($index<3)continue;//for pm time
                            $table[$key][$index]=$sub_instance[$subjectpm[$j]];//exc is overwrited
                            $ind[$key][$index] = $subjectpm[$j];//in index too
                            $table[$date][$period]=$sub_instance[$exc[$k]];//emptycell is filled
                            $ind[$date][$period]=$exc[$k];
                            $j++;//insummary the cell are swapped and empt get filled
                            break;}
                        // }
                        }
                        break;
                    }
                }

                }break;
            }
            }

        }
    }
    $revar = new materials( $table,[],$sub_str);
    return $revar;

}
function sub_generator($tablecl){
    echo "<br>Generating subject table for section";
    $sub_str =$tablecl->sub;
    // $ind=$tablecl->ind;
    for($i=0;$i<=5;$i++){
    $sub_instance[$i]=$sub_str[$i]->sub_name;//because sometime php ignre '->'
    $frpdofth[$i]=$sub_str[$i]->frpdofth ;
    }
    // $sub_count = $tablecl->max_sub;

    $table = $tablecl->table;        $blah=0;


    for($date=0;$date<=4;$date++){
        
        $pm =$tablecl->index;
        $am =$tablecl->index;
        // $temp = $sub_count;
        foreach($sub_str as $value){
            $value->amrec();
            $value->pmrec();
        }
        if($date>0){
            foreach($sub_str as $key => $subj){
        if($subj->amtime==0)
        {
           unset($am[$key]);
        }
        if($subj->pmtime==0)
        {
        unset($pm[$key]);
        }                    
                }
    }

        for($period=0;$period<=5;$period++){
            if(isset($table[$date][$period]))continue;//skip filled cells

            if(!empty($am)||!empty($pm)){
                
                // $test = rand(0,count($sub_index)-1);//out random
                if($period<3) {
                    $sub_index=array_values($am);
                    $test = rand(0,count($sub_index)-1);}
                else {
                    $sub_index=array_values($pm);
                    $test = rand(0,count($sub_index)-1);}
                    // if($sub_str[$sub_index[$test]]->teacher )//check if teachers are free


                    $check ="$date$period";//for no th period overlap
                    while(!empty($frpdofth[$sub_index[$test]])&&in_array($check,$frpdofth[$sub_index[$test]])){
                        unset($sub_index[$test]);
                        $sub_index=array_values($sub_index);
                        $test = rand(0,count($sub_index)-1);//rand without the unwanted
                    }
                    $table[$date][$period]= $sub_instance[$sub_index[$test]];//put data into timeslots
                    // $ind[$date][$period]=$sub_index[$test]; // record of indexes
                    //record period of subject
            //no first period overlap
            if($date>0 && count($sub_index)!=1 &&$period==0){
                while($table[$date][0] == $table[$date-1][0]){
                    // if($date==4){
                    //     $mark=1;
                    //     do{
                    //     $shuf=$table[$date-1][$period+$mark];
                    //     $mark++;
                    // }while($shuf==$table[$date-2][$period]&&$mark<3);

                    //     $table[$date-1][$period+1]=$table[$date-1][$period];
                    //     $table[$date-1][$period]=$shuf;
                    //     break;
                    // }
                        unset($sub_index[$test]);
                        $sub_index=array_values($sub_index);
                        $test = rand(0,count($sub_index)-1);
                    //check if teachers are free
                    $table[$date][$period]=$sub_instance[$sub_index[$test]];
                    // $ind[$date][$period]=$sub_index[$test];
                }
                }
                if(!isset($sub_str[$sub_index[$test]]))die(1);
            if($period<3) $sub_str[$sub_index[$test]]->amtime--;
            else $sub_str[$sub_index[$test]]->pmtime--;
            unset($am[$sub_index[$test]]);
            unset($pm[$sub_index[$test]]);
             } else break;
            
        } 
       //no last period overlap
       if($date>0){
        if(isset($table[$date][5])&&$table[$date][5]!="no data"&&$table[$date][5]==$table[$date-1][5]){
            for($p=0;$p<=5;$p++){
                if($table[$date][$p]=="no data")continue;
                else $table[$date][$p]=null; 
                } 
                foreach($sub_str as $value){
                    $value->rollback();
                }
                $date--;
        //    $sub_count=$temp;
        }
    }
 }

$revar = new materials($table,[],$sub_str/*,$sub_count*/);
 return $revar;
}
function getperiod($table,$sub_str){
    for($date=0;$date<=count($table)-1;$date++){
        for($period=0;$period<=count($table[$date])-1;$period++){
            for($i=0;$i<count($sub_str);$i++){
                if(!isset($table[$date][$period]))continue;
                if($table[$date][$period]== $sub_str[$i]->sub_name){
            $sub_str[$i]->sub_period[]="$date$period";
            }
            }
        }

    }
}
function add_sub($table,$subject){
    for($date=1;$date<count($table);$date++){
        for($period=1;$period<8;$period++){
            if($period==4)continue;//skip lunch
            // if(isset($table[$date][$period]))continue;//skip filled cells
            if($period<4)$table[$date][$period]=$subject[$date-1][$period-1];
            else $table[$date][$period]=$subject[$date-1][$period-2];
    }
}
return $table;
}
function add_Ltda($table,$ind,$sub_str,$sem){
    if((ceil($sem/2))%2==0){$am="TDA";$pm="L";}
    else {$am="L";$pm="TDA";}
    for($date=0;$date<count($table);$date++){
        for($period=0;$period<count($table[$date]);$period++){
            if($table[$date][$period]=="no data")continue;
            $sind=$ind[$date][$period];
            if($sub_str[$sind]->sub_type=="lecture"){
            if($period<(count($table[$date])/2))
            $table[$date][$period].="($am)   ";
            else 
            $table[$date][$period].="($pm) ";
            }else $table[$date][$period].="(LAB) ";
    }
}
return($table);
}
function addthname($arr,$conn,$sub_str){
    $sql="SELECT * FROM teachers where th_code=?";
    $stmt=$conn->prepare($sql);
    foreach($sub_str as $value){
       $stmt->execute([$value->sub_teacher]); 
       $result=$stmt->fetchAll(PDO::FETCH_ASSOC);
       foreach($result as $row){
        $temparr[$row['th_code']]=$row['name'];
       }
    }
    for($i=0;$i<count($arr);$i++){
        for($j=0;$j<count($arr[$i]);$j++){
            foreach($temparr as $thid => $thname){
                if($thid==$arr[$i][$j]) $arr[$i][$j].="</br>$thname";
            }
        }
    }
    return $arr;
}
function generate_table($sem,$sub_str){
echo "<br>Table Generating . . .";
    $ind=[];
    $def_index =[0,1,2,3,4,5];
    $subj = [];
    $subject = new materials($subj,$def_index,$sub_str);
    try{
    $subject = free_time($subject,$sem);
    echo"<pre>";print_r($subject);
    $subject = sub_generator($subject);
    $ind=getInd($subject->table,$subject->sub);
    $subject=fill_cell($subject,$ind);
    getperiod($subject->table,$sub_str);
    // var_dump($sub_str);
    }catch(Exception $e){
        echo "Please try again";
    };
    echo "<br>Subject Table generated";
    return $subject;
}
function disp_table($table){
    // echo count($table);
    // echo count($table[3]);
    echo "<table border='1' style='border-collapse:collapse'>";
    for($date=0;$date<=count($table)-1;$date++){
    echo "<tr>";
    for($period=0;$period<=count($table[$date])-1;$period++){
        // if(!isset($table[$date][$period]))continue;
        if(!isset($table[$date][$period])){
            $table[$date][$period]="";
             echo "<td>".$table[$date][$period]." </td>";
    }else
        if($date==0||$period==0){
            echo "<th> ".$table[$date][$period]."</th>";
        }
        else echo "<td>".$table[$date][$period]." </td>";
    }
    echo"</tr>";
}
echo"</table>";
}
function arrtocode($arr){
    $tcode = "";
    for($i=0;$i<count($arr);$i++){
        for($j=0;$j<count($arr[$i]);$j++){
            $tcode.=$arr[$i][$j];
        }
    }
    return $tcode;
}
function getInd($table,$sub_str){
    $ind=[];
    foreach($sub_str as $value){
        $sub_instance[] = $value->sub_name;
    }
    for($date=0;$date<count($table);$date++){
        if(!isset($table[$date]))die(1);
        for($period=0;$period<count($table[$date]);$period++){
            foreach($sub_instance as $key => $value){
                if($table[$date][$period]=="no data")$ind[$date][$period]=6;
                if($table[$date][$period]==$value){
                    $ind[$date][$period]=$key;break;
                }
            }
        }
    }
    return $ind;
}
function add_room(){
    $lrcode=[];
    $trcode=[];
$sql = "SELECT * FROM room where semster = ? and rm_type =?";
$stmt = $conn->prepare($sql);
$stmt->execute($sem,'lab');
$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
    $lrcode[]=$row['rm_code'];
}
$stmt->execute([$sem,'lecture']);
$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
foreach($result as $row){
    $trcode[]=$row['rm_code'];
}

for($i=0;$i<count($table);$i++){
    for($j=0;$j<count($table[$i]);$j++){
        if($table[$i][$j]=="no data")continue;
        if($sub_str[$ind[$i][$j]]->sub_type=='lab'){
            $test=rand(0,count($lrcode));
            
        }
    }
}
}
function view_thtable($th_code,$conn){
    try{
        $t_code=[];$s_code=[];$type=[];
    $sql = "SELECT * FROM teach where th_code =?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$th_code]);
    $result =$stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach($result as $row){
     $t_code[] = $row['day_P'];
     $s_code[] = $row['sub_code'];
     $type[] = $row['alias'];
    }
    }catch(PDOException $e){
        echo "Error: " .$e->getMessage();
    }
    $arr =[];
    $sub =[];
    foreach($s_code as $key =>$value){
     $sub[] = $value.'('. $type[$key] .')';
    }
    for($i=0;$i<5;$i++){
        for($j=0;$j<6;$j++){
            $comp="$i$j";
            if(in_array($comp,$t_code)){
                $c=array_search($comp,$t_code);
                $arr[$i][$j]=$sub[$c];
            }
            else $arr[$i][$j]="no data";     
        }
    }
    $t=[];
    $t=out_layout($t,$conn);
    $t=add_sub($t,$arr);
    disp_table($t);
    }
    //take subjcode
function getscode($sem,$conn){
    $temp=[];
    try{
    $sql = "SELECT * FROM semster where semster= ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$sem]);
    $result =$stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($result as $row){
        foreach ($row as $key => $columnValue) {
            $temp[]= $columnValue;
        }
    }
    }catch(PDOException $e){
        echo "Error: " .$e->getMessage();
    }
    return $temp;
}
    //take teacher
function getsubth($sub_str,$conn,$sec){
    $temp =[];
    try{
            $sql="SELECT * FROM th_sub where sub_code= ? AND section_code= ?";
            $stmt = $conn->prepare($sql);
        foreach($sub_str as $subobj){
            $sub= $subobj->sub_name;
    // var_dump($sub);
    $stmt->execute([$sub,$sec]);
    $result=$stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($result as $row){
    $temp[]=$row['th_code'];
    }
        }
    }catch(PDOException $e){
        echo "error ".$e->getMessage();
    }
    // var_dump($temp);
    return $temp;
    }
    //get subtype
function getsubtype($sub_str,$conn){
    $temp=[];
    try{
    $sql="SELECT * FROM subject where sub_code= ?";
    $stmt = $conn->prepare($sql);
        foreach($sub_str as $subobj){
            $sub= $subobj->sub_name;
    $stmt->execute([$sub]);
    $result=$stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($result as $row){
    $temp[]=$row['sub_type'];
    }
        }
    }catch(PDOException $e){
        echo "error ".$e->getMessage();
    }
    return $temp;
    }
    //get formerperiod of teacher
function getfrpdofth($sub_str,$conn){
    $temp=[];
    try{
    $sql = "SELECT * FROM teach where th_code=?";
    $stmt = $conn->prepare($sql);
    foreach($sub_str as $key => $subobj){
        $th= $subobj->sub_teacher;
    $stmt->execute([$th]);
    $result=$stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($result as $row){
    $temp[$key][]=$row['day_P'];
    }
    }
    }catch(PDOException $e){
        echo "error ".$e->getMessage();
    }
    return $temp;
    }
function buildsubstr($sub_str,$conn,$sem,$sec){
        $temp=getscode($sem,$conn);
        for($i=0;$i<count($sub_str);$i++){
            $sub_str[$i]->sub_name=$temp[$i +1];
        }
        $temp=getsubth($sub_str,$conn,$sec);
        // var_dump($temp);
        for($i=0;$i<count($sub_str);$i++){
            $sub_str[$i]->sub_teacher=$temp[$i];
        }
        $temp=getsubtype($sub_str,$conn);
        for($i=0;$i<count($sub_str);$i++){
            $sub_str[$i]->sub_type =$temp[$i];
        }
        $temp=getfrpdofth($sub_str,$conn);
        for($i=0;$i<count($sub_str);$i++){
            $sub_str[$i]->frpdofth = empty($temp) ? null : $temp[$i];
        }
    }
function savetimetable($ind,$conn,$sem,$sec){
        $ttcode=arrtocode($ind);
        try{
            $sql = "UPDATE section set timetable_code = ? where section_code = ? and semster = ?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$ttcode,$sec,$sem]);
        }catch(PDOException $e){
            echo "error ".$e->getMessage();
        }
    }
function savethsub($conn,$sub_str,$sec,$sem){
    if((ceil($sem/2))%2==0){$am="TDA";$pm="L";}
    else {$am="L";$pm="TDA";}
        try{
            $sql = "INSERT INTO teach (`day_P`,`alias`, `sub_code`,`th_code`,`section_code`,`semster`,`period_count`) VALUES (?,?,?, ?,?,?,null)";
            $stmt=$conn->prepare($sql);
            echo"<pre>";
            // var_dump($sub_str);
            foreach ($sub_str as $value){
            $s_code = $value->sub_name;
            $t_code= $value->sub_teacher;
            $s_period = $value->sub_period;
            // var_dump($s_period);
            foreach($s_period as $per){
            $tdayp=$per;
            if($value->sub_type=="lecture")$alias = $per[1]<=2 ? $am :$pm;
            else $alias = $value->sub_type;
            $stmt->execute([$tdayp,$alias,$s_code,$t_code,$sec,$sem]);    
            }}
        }catch(PDOException $e){
        echo "Error ".$e->getMessage();
    }
}
function codetotable($sub_str,$conn,$sem,$sec){
    $arr =[];
    try{
    $sql = "SELECT timetable_code FROM section where section_code =? and semster =?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$sec,$sem]);
    $tcode =$stmt->fetchColumn();
    }catch(PDOException $e){
        echo "Error: " .$e->getMessage();
    }
    for($i=0;$i<=strlen($tcode)-1;$i++){
        $j= intval($i/6!=5 ? $i/6 : null);
     if(isset($j))$arr[$j][]=$tcode[$i];
    }
    for($i=0;$i<=5;$i++){
        $sub_instance[$i]=$sub_str[$i]->sub_name;
    }
    $sub_instance[6]="no data";
    $ind=$arr;
    for($i=0;$i<count($arr);$i++){
        for($j=0;$j<count($arr[$i]);$j++){
            foreach($sub_instance as $key=>$sname){
               if($key==$arr[$i][$j]){
                 $arr[$i][$j]=$sname;
                 break;
               }
            }
        }
    }
    
    return $arr;
}
function gthtable($arr,$sub_str){
    $temparr=[];
    for($i=0;$i<=5;$i++){
        $temparr[$sub_str[$i]->sub_name]=$sub_str[$i]->sub_teacher;
    }
    for($i=0;$i<count($arr);$i++){
        for($j=0;$j<count($arr[$i]);$j++){
            foreach($temparr as $sub=>$teacher){
                if($sub==$arr[$i][$j]){
                  $arr[$i][$j]=$teacher;
                  break;
                }
            }
        }
    }
    return $arr;
}
if(strpos($overlap,"I") !== false){
    if(strpos($overlap,"A") !== false)
        $section_id="11";
    else if(strpos($overlap,"B") !== false)
    $section_id= "12";
    else if(strpos($overlap,"C") !== false)
    $section_id= "13";
    else if(strpos($overlap,"D") !== false)
    $section_id= "14";
    else if(strpos($overlap,"E") !== false)
    $section_id= "15";
}elseif(strpos($overlap,"W") !== false){
    if(strpos($overlap,"A") !== false)
        $section_id="21";
    else if(strpos($overlap,"B") !== false)
    $section_id= "22";
    else if(strpos($overlap,"C") !== false)
    $section_id= "23";
    else if(strpos($overlap,"D") !== false)
    $section_id= "24";
    else if(strpos($overlap,"E") !== false)
    $section_id= "25";
}elseif(strpos($overlap,"V") !== false){
    if(strpos($overlap,"A") !== false)
        $section_id="31";
    else if(strpos($overlap,"B") !== false)
    $section_id= "32";
    else if(strpos($overlap,"C") !== false)
    $section_id= "33";
    else if(strpos($overlap,"D") !== false)
    $section_id= "34";
    else if(strpos($overlap,"E") !== false)
    $section_id= "35";
}elseif(strpos($overlap,"Y") !== false){
    if(strpos($overlap,"A") !== false)
        $section_id="41";
    else if(strpos($overlap,"B") !== false)
    $section_id= "42";
    else if(strpos($overlap,"C") !== false)
    $section_id= "43";
    else if(strpos($overlap,"D") !== false)
    $section_id= "44";
    else if(strpos($overlap,"E") !== false)
    $section_id= "45";
}elseif(strpos($overlap,"G") !== false){
    if(strpos($overlap,"C") !== false){
    if(strpos($overlap,"A") !== false)
        $section_id="51";
    else if(strpos($overlap,"B") !== false)
    $section_id= "52";
    else if(strpos($overlap,"C") !== false)
    $section_id= "53";
    else if(strpos($overlap,"D") !== false)
    $section_id= "54";
    else if(strpos($overlap,"E") !== false)
    $section_id= "55";
    }elseif(strpos($overlap,"T") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="56";
        else if(strpos($overlap,"B") !== false)
        $section_id= "57";
        else if(strpos($overlap,"C") !== false)
        $section_id= "58";
        else if(strpos($overlap,"D") !== false)
        $section_id= "59";
        else if(strpos($overlap,"E") !== false)
        $section_id= "50";
    }
}elseif(strpos($overlap,"R") !== false){
    if(strpos($overlap,"C") !== false){
    if(strpos($overlap,"A") !== false)
        $section_id="61";
    else if(strpos($overlap,"B") !== false)
    $section_id= "62";
    else if(strpos($overlap,"C") !== false)
    $section_id= "63";
    else if(strpos($overlap,"D") !== false)
    $section_id= "64";
    else if(strpos($overlap,"E") !== false)
    $section_id= "65";
    }elseif(strpos($overlap,"T") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="66";
        else if(strpos($overlap,"B") !== false)
        $section_id= "67";
        else if(strpos($overlap,"C") !== false)
        $section_id= "68";
        else if(strpos($overlap,"D") !== false)
        $section_id= "69";
        else if(strpos($overlap,"E") !== false)
        $section_id= "60";
    }
}elseif(strpos($overlap,"O") !== false){
    if(strpos($overlap,"S") !== false){
    if(strpos($overlap,"A") !== false)
        $section_id="701";
    else if(strpos($overlap,"B") !== false)
    $section_id= "702";
    else if(strpos($overlap,"C") !== false)
    $section_id= "703";
    else if(strpos($overlap,"D") !== false)
    $section_id= "704";
    else if(strpos($overlap,"E") !== false)
    $section_id= "705";
    }elseif(strpos($overlap,"K") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="706";
        else if(strpos($overlap,"B") !== false)
        $section_id= "707";
        else if(strpos($overlap,"C") !== false)
        $section_id= "708";
        else if(strpos($overlap,"D") !== false)
        $section_id= "709";
        else if(strpos($overlap,"E") !== false)
        $section_id= "710";
    }else if(strpos($overlap,"P") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="711";
        else if(strpos($overlap,"B") !== false)
        $section_id= "712";
        else if(strpos($overlap,"C") !== false)
        $section_id= "713";
        else if(strpos($overlap,"D") !== false)
        $section_id= "714";
        else if(strpos($overlap,"E") !== false)
        $section_id= "715";
    }else if(strpos($overlap,"H") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="716";
        else if(strpos($overlap,"B") !== false)
        $section_id= "717";
        else if(strpos($overlap,"C") !== false)
        $section_id= "718";
        else if(strpos($overlap,"D") !== false)
        $section_id= "719";
        else if(strpos($overlap,"E") !== false)
        $section_id= "720";
    }else if(strpos($overlap,"N") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="721";
        else if(strpos($overlap,"B") !== false)
        $section_id= "722";
        else if(strpos($overlap,"C") !== false)
        $section_id= "723";
        else if(strpos($overlap,"D") !== false)
        $section_id= "724";
        else if(strpos($overlap,"E") !== false)
        $section_id= "725";
    }else if(strpos($overlap,"E") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="726";
        else if(strpos($overlap,"B") !== false)
        $section_id= "727";
        else if(strpos($overlap,"C") !== false)
        $section_id= "728";
        else if(strpos($overlap,"D") !== false)
        $section_id= "729";
        else if(strpos($overlap,"E") !== false)
        $section_id= "730";
    }
}elseif(strpos($overlap,"M") !== false){
    if(strpos($overlap,"S") !== false){
    if(strpos($overlap,"A") !== false)
        $section_id="801";
    else if(strpos($overlap,"B") !== false)
    $section_id= "802";
    else if(strpos($overlap,"C") !== false)
    $section_id= "803";
    else if(strpos($overlap,"D") !== false)
    $section_id= "804";
    else if(strpos($overlap,"E") !== false)
    $section_id= "805";
    }elseif(strpos($overlap,"K") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="806";
        else if(strpos($overlap,"B") !== false)
        $section_id= "807";
        else if(strpos($overlap,"C") !== false)
        $section_id= "808";
        else if(strpos($overlap,"D") !== false)
        $section_id= "809";
        else if(strpos($overlap,"E") !== false)
        $section_id= "810";
    }else if(strpos($overlap,"P") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="811";
        else if(strpos($overlap,"B") !== false)
        $section_id= "812";
        else if(strpos($overlap,"C") !== false)
        $section_id= "813";
        else if(strpos($overlap,"D") !== false)
        $section_id= "814";
        else if(strpos($overlap,"E") !== false)
        $section_id= "815";
    }else if(strpos($overlap,"H") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="816";
        else if(strpos($overlap,"B") !== false)
        $section_id= "817";
        else if(strpos($overlap,"C") !== false)
        $section_id= "818";
        else if(strpos($overlap,"D") !== false)
        $section_id= "819";
        else if(strpos($overlap,"E") !== false)
        $section_id= "820";
    }else if(strpos($overlap,"N") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="821";
        else if(strpos($overlap,"B") !== false)
        $section_id= "822";
        else if(strpos($overlap,"C") !== false)
        $section_id= "823";
        else if(strpos($overlap,"D") !== false)
        $section_id= "824";
        else if(strpos($overlap,"E") !== false)
        $section_id= "825";
    }else if(strpos($overlap,"E") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="826";
        else if(strpos($overlap,"B") !== false)
        $section_id= "827";
        else if(strpos($overlap,"C") !== false)
        $section_id= "828";
        else if(strpos($overlap,"D") !== false)
        $section_id= "829";
        else if(strpos($overlap,"E") !== false)
        $section_id= "830";
    }
}elseif(strpos($overlap,"L") !== false){
    if(strpos($overlap,"S") !== false){
    if(strpos($overlap,"A") !== false)
        $section_id="901";
    else if(strpos($overlap,"B") !== false)
    $section_id= "902";
    else if(strpos($overlap,"C") !== false)
    $section_id= "903";
    else if(strpos($overlap,"D") !== false)
    $section_id= "904";
    else if(strpos($overlap,"E") !== false)
    $section_id= "905";
    }elseif(strpos($overlap,"K") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="906";
        else if(strpos($overlap,"B") !== false)
        $section_id= "907";
        else if(strpos($overlap,"C") !== false)
        $section_id= "908";
        else if(strpos($overlap,"D") !== false)
        $section_id= "909";
        else if(strpos($overlap,"E") !== false)
        $section_id= "910";
    }else if(strpos($overlap,"P") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="911";
        else if(strpos($overlap,"B") !== false)
        $section_id= "912";
        else if(strpos($overlap,"C") !== false)
        $section_id= "913";
        else if(strpos($overlap,"D") !== false)
        $section_id= "914";
        else if(strpos($overlap,"E") !== false)
        $section_id= "915";
    }else if(strpos($overlap,"H") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="916";
        else if(strpos($overlap,"B") !== false)
        $section_id= "917";
        else if(strpos($overlap,"C") !== false)
        $section_id= "918";
        else if(strpos($overlap,"D") !== false)
        $section_id= "919";
        else if(strpos($overlap,"E") !== false)
        $section_id= "920";
    }else if(strpos($overlap,"N") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="921";
        else if(strpos($overlap,"B") !== false)
        $section_id= "922";
        else if(strpos($overlap,"C") !== false)
        $section_id= "923";
        else if(strpos($overlap,"D") !== false)
        $section_id= "924";
        else if(strpos($overlap,"E") !== false)
        $section_id= "925";
    }else if(strpos($overlap,"E") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="926";
        else if(strpos($overlap,"B") !== false)
        $section_id= "927";
        else if(strpos($overlap,"C") !== false)
        $section_id= "928";
        else if(strpos($overlap,"D") !== false)
        $section_id= "929";
        else if(strpos($overlap,"E") !== false)
        $section_id= "930";
    }
}elseif(strpos($overlap,"J") !== false){
    if(strpos($overlap,"S") !== false){
    if(strpos($overlap,"A") !== false)
        $section_id="001";
    else if(strpos($overlap,"B") !== false)
    $section_id= "002";
    else if(strpos($overlap,"C") !== false)
    $section_id= "003";
    else if(strpos($overlap,"D") !== false)
    $section_id= "004";
    else if(strpos($overlap,"E") !== false)
    $section_id= "005";
    }elseif(strpos($overlap,"K") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="006";
        else if(strpos($overlap,"B") !== false)
        $section_id= "007";
        else if(strpos($overlap,"C") !== false)
        $section_id= "008";
        else if(strpos($overlap,"D") !== false)
        $section_id= "009";
        else if(strpos($overlap,"E") !== false)
        $section_id= "010";
    }else if(strpos($overlap,"P") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="011";
        else if(strpos($overlap,"B") !== false)
        $section_id= "012";
        else if(strpos($overlap,"C") !== false)
        $section_id= "013";
        else if(strpos($overlap,"D") !== false)
        $section_id= "014";
        else if(strpos($overlap,"E") !== false)
        $section_id= "015";
    }else if(strpos($overlap,"H") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="016";
        else if(strpos($overlap,"B") !== false)
        $section_id= "017";
        else if(strpos($overlap,"C") !== false)
        $section_id= "018";
        else if(strpos($overlap,"D") !== false)
        $section_id= "019";
        else if(strpos($overlap,"E") !== false)
        $section_id= "020";
    }else if(strpos($overlap,"N") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="021";
        else if(strpos($overlap,"B") !== false)
        $section_id= "022";
        else if(strpos($overlap,"C") !== false)
        $section_id= "023";
        else if(strpos($overlap,"D") !== false)
        $section_id= "024";
        else if(strpos($overlap,"E") !== false)
        $section_id= "025";
    }else if(strpos($overlap,"E") !== false){
        if(strpos($overlap,"A") !== false)
            $section_id="026";
        else if(strpos($overlap,"B") !== false)
        $section_id= "027";
        else if(strpos($overlap,"C") !== false)
        $section_id= "028";
        else if(strpos($overlap,"D") !== false)
        $section_id= "029";
        else if(strpos($overlap,"E") !== false)
        $section_id= "030";
    }
}
$overlap = "JEA123";
$semarr=["I","W","V","Y","G","R","O","M","L","J"];
$semov=array_search($overlap[0],$semarr);
$secarr=["A","B","C","D","E"];
$mj1 = ["C","T"];
$mj2 = ["S","K","P","H","N","E"];
if($semov !== false){
    $semov++;
    if($semov<=4){
        $secov = array_search($overlap[1],$secarr) + 1;
        $section_id="$semov$secov";
    }elseif($semov<=6){
        $mj1ov = array_search($overlap[1],$mj1)+1;
        $secov = array_search($overlap[2],$secarr)+1;
        $section_id = "$semov$mj1ov$secov";
    }else{
        $mj2ov = array_search($overlap[1],$mj2)+1;
        $secov = array_search($overlap[2],$secarr)+1;
                    if($semov==10)$semov=0;
                    $section_id = "$semov$mj2ov$secov";
    }
}
echo $section_id;
function add_Ltda($table,$rind,$sem,$conn,$am,$pm){     
    $sql="SELECT * FROM room where rm_type =?";
    $stmt=$conn->prepare($sql);
    $stmt->execute(['A']); 
    $Arcode = $stmt->fetchAll(PDO::FETCH_COLUMN);
    for($date=0;$date<count($table);$date++){
        for($period=0;$period<count($table[$date]);$period++){
            if($table[$date][$period]==" ")continue;
            $flag = true;
            switch($rind["$date$period"]){
                case 351:$table[$date][$period].="(Klab)   "; break;
                case 352:$table[$date][$period].="(Cisco lab)   "; break;
                case 353:$table[$date][$period].="(Hardware lab)   "; break;
                case 342:$table[$date][$period].="(Hitachi lab)   "; break;
                case 254:$table[$date][$period].="(English lab)   "; break;
                case 255:$table[$date][$period].="(Physic lab)   "; break;
            }
            if($flag){
            if(!in_array($rind["$date$period"],$Arcode))
            $table[$date][$period].="(lab)   ";
            elseif($period<(count($table[$date])/2))
            $table[$date][$period].="($am)   ";
            else 
            $table[$date][$period].="($pm)   ";
            }
        }
    }
    return $table;
}