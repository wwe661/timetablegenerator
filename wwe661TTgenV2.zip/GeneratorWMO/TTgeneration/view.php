<?php
    function getInd($conn,$sem,$sec){
        $arr =[];
        try{
            $sql = "SELECT timetable_code FROM section where section_id =? and semester_id =?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$sec,$sem]);
            $code =$stmt->fetchColumn();
            }catch(PDOException $e){
                echo "Error: " .$e->getMessage();
            }
            for($i=0;$i<=strlen($code)-1;$i++){
                $j= intval($i/6!=5 ? $i/6 : null);
            if(isset($j))$arr[$j][]=$code[$i];
            }
        return $arr;
    }
    function codetotable($sub_str,$conn,$sem,$sec){
        $arr =[];
        try{
        $sql = "SELECT timetable_code FROM section where section_id =? and semester_id =?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$sec,$sem]);
        $tcode =$stmt->fetchColumn();
        }catch(PDOException $e){
            echo "Error: " .$e->getMessage();
        }
        if(!empty($tcode)){
        for($i=0;$i<=strlen($tcode)-1;$i++){
            $j= intval($i/6!=5 ? $i/6 : null);
        if(isset($j))$arr[$j][]=$tcode[$i];
        }
        for($i=0;$i<=5;$i++){
            $sub_instance[$i]=$sub_str[$i]->sub_name;
        }
        $sub_instance[6]=" ";
        $ind=$arr;
        for($i=0;$i<count($arr);$i++){
            for($j=0;$j<count($arr[$i]);$j++){
                foreach($sub_instance as $key=>$sname){
                if($key==$arr[$i][$j]){
                    $arr[$i][$j]=$sname;
                    break;
                }
                }
            }
        }}
        return $arr;
    }
    function gthtable($arr,$conn,$sub_str){
            $temparr=[];
                $sql="SELECT name FROM teacher where teacher_id=?";
                $stmt=$conn->prepare($sql);
            for($i=0;$i<=5;$i++){
                $temp=$sub_str[$i]->sub_teacher;
                $stmt->execute([$temp]);
                $res = $stmt->fetchColumn();
                $temparr[$sub_str[$i]->sub_name]=$res;
            }
            for($i=0;$i<count($arr);$i++){
                for($j=0;$j<count($arr[$i]);$j++){
                    foreach($temparr as $sub=>$teacher){
                        if($sub==$arr[$i][$j]){
                        $arr[$i][$j]=$teacher;
                        break;
                        }
                    }
                }
            }
            return $arr;
        }
    function addthname($arr,$conn,$sub_str){
            $sql="SELECT * FROM teacher where teacher_id=?";
            $stmt=$conn->prepare($sql);
            foreach($sub_str as $value){
            $stmt->execute([$value->sub_teacher]); 
            $result=$stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach($result as $row){
                $temparr[$row['th_code']]=$row['name'];
            }
            }
            for($i=0;$i<count($arr);$i++){
                for($j=0;$j<count($arr[$i]);$j++){
                    foreach($temparr as $thid => $thname){
                        if($thid==$arr[$i][$j]) $arr[$i][$j].="</br>$thname";
                    }
                }
            }
            return $arr;
        }
function get_Ltda($table,$rind,$conn,$am,$pm){   
    $temp=[];  
    $sql="SELECT rm_code FROM room where rm_type =?";
    $stmt=$conn->prepare($sql);
    $stmt->execute(['A']); 
    $Arcode = $stmt->fetchAll(PDO::FETCH_COLUMN);
    for($date=0;$date<count($table);$date++){
        for($period=0;$period<count($table[$date]);$period++){
            if($table[$date][$period]==" ")continue;

            switch($rind["$date$period"]){
                case 351:$temp["$date$period"]="(Klab)"; break;
                case 352:$temp["$date$period"]="(Cisco lab)"; break;
                case 353:$temp["$date$period"]="(Hardware lab)"; break;
                case 342:$temp["$date$period"]="(Hitachi lab)"; break;
                case 254:$temp["$date$period"]="(English lab)"; break;
                case 255:$temp["$date$period"]="(Physic lab)"; break;
                default:
                    if(!in_array($rind["$date$period"],$Arcode))
                        $temp["$date$period"]="(lab)";
                    elseif($period<(count($table[$date])/2))
                        $temp["$date$period"]="($am)";
                    else 
                        $temp["$date$period"]="($pm)";break;
            }
        }
    }
    return $temp;
}
function get_Ltdaed($sec,$conn){
    $sql = "select * from teach where section_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$sec]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $arr=[];
    foreach($result as $row){
        $arr[$row["day_P"]]=$row["alias"];
    }
    return $arr;
}
function getrind($conn,$sec,$sem){
    $temp=[];
    $sql="SELECT * FROM teach where day_P=? and section_id=? and semester_id=?";
    $stmt=$conn->prepare($sql);
    for($i=0;$i<5;$i++){
        for($j=0;$j<6;$j++){
            $key="$i$j";
            $stmt->execute([$key,$sec,$sem]);
            $result=$stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach($result as $row){
                $temp[$row['day_P']]=$row['rm_code'];
            }
        }
    }
    return $temp;
}
function add_aliases($table,$rind,$ltdas){
    for($i=0;$i<5;$i++){
        for($j=0;$j<6;$j++){
            if(!empty($rind["$i$j"]&&isset($rind["$i$j"])))
            $table[$i][$j].=$ltdas["$i$j"]."   <br>Room ( ".$rind["$i$j"]." )";
        }
    }
    return $table;
}
function defaultlayout($table){
    $dates = ["Monday","Tuesday","Wednesday","Thursday","Friday"];
    $periods = ["8:30am - 9:30am","9:40am - 10:40am","10:50am - 11:50am","11:50am - 12:40pm","12:40pm - 1:40pm","1:50pm - 2:50pm","3:00pm - 4:00pm"];
    $table[0][0] = "DAYS\PERIODS";
    for($d=0;$d<count($dates)+1;$d++) {
        for($p=0;$p<count($periods)+1;$p++) {
            if(isset($table[$d][$p])) continue;
            if($d == 0) $table[$d][$p]=$periods[$p-1];
            else if($p == 4)$table[$d][$p] = "Lunch";
            else if($p == 0) $table[$d][$p] = $dates[$d-1];
            else $table[$d][$p] = " ";
        }
    }
    return $table;
}
function out_layout($table,$conn){
    
    $sql = "select * from layout";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // var_dump($result);
    for($i=0;$i<count($result);$i++){
        for($j=0;$j<count($result[$i]);$j++){
            if($result[$i][$j]!= null){
            $table[$i][$j] = $result[$i][$j];
            }
        }
    }
    return $table;
    }
    function add_sub($table,$subject){
        for($date=1;$date<count($table);$date++){
            for($period=1;$period<8;$period++){
                if($period==4)continue;//skip lunch
                // if(isset($table[$date][$period]))continue;//skip filled cells
                if($period<4)$table[$date][$period]=$subject[$date-1][$period-1];
                else $table[$date][$period]=$subject[$date-1][$period-2];
        }
        }
        return $table;
    }
    function disp_table($table){
        // echo count($table);
        // echo count($table[3]);
        echo '<table id="result_table" style="margin-top:20px;">';
        for($i=0;$i<count($table);$i++){
        echo "<tr>";
            for($j=0;$j<count($table[$i]);$j++){
            if(!isset($table[$i][$j]))$table[$i][$j]="";
            if($i==0||$j==0||$j==4){echo "<th> ".$table[$i][$j]."</th>";   continue;}    
            echo "<td>".$table[$i][$j]." </td>";
        }
        echo"</tr>";
    }
        echo"</table>";
    }
    function timetablefooter($sub_str,$conn){
        ?>
            <table>
                <tr>
                    <th>Subject Code</th>
                    <th>Subject Description</th>
                    <th>Lecturer</th>
                </tr>
                <?php 
                $subnamesql="SELECT subject_name FROM subject where subject_id=?";
                $subnamestmt=$conn->prepare($subnamesql);
                $tchsql="SELECT name FROM teacher where teacher_id=?";
                $tchstmt=$conn->prepare($tchsql);
                foreach($sub_str as $row){ 
                    echo "<tr><td>$row->sub_name</td>";
                    $subnamestmt->execute([$row->sub_name]);
                    $name = $subnamestmt->fetchColumn();
                    echo "<td>$name</td>";
                    $tchstmt->execute([$row->sub_teacher]);
                    $name = $tchstmt->fetchColumn();
                    echo "<td>".$name."</td></tr>";
                }
                ?>
            </table>
        <?php
    }
    function view_thtable($th_code,$conn){
        try{
            $sql="SELECT name FROM teacher where teacher_id=?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$th_code]);
            $th_name= $stmt->fetchColumn();
            // echo "</br> <p class='msg'>".$th_name./*($th_code)*/"</p>";
            $t_code=[];$s_code=[];$type=[];
            $sql = "SELECT * FROM teach where teacher_id =?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$th_code]);
            $result =$stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach($result as $row){
            $t_code[] = $row['day_P'];
            $s_code[] = $row['subject_id'];
            $type[] = $row['alias'];
            $room[]= $row['rm_code'];
            $sem[]= $row['semester_id'];
            $sectemp[]=$row['section_id'];
        }
        }catch(PDOException $e){
            echo "Error: " .$e->getMessage();
        }
        $arr =[];
        $sub =[];
        $sql="SELECT subject_name FROM subject where subject_id=?";
        $stmt=$conn->prepare($sql);
        foreach($s_code as $key =>$value){
            $stmt->execute([$value]);
            $result=$stmt->fetchColumn();
            $sub_name[$value] = $result;
            $sub[] = $value.'('. $type[$key] .')';
        }
        $sql="SELECT section_name FROM section where section_id=?";
        $stmt=$conn->prepare( $sql);
        foreach($sectemp as $value){
            $stmt->execute([$value]);
            $res=$stmt->fetchColumn();
            $sec[]=$res;
        }
        $sql="SELECT semester_name FROM semester where semester_id=?";
        $stmt=$conn->prepare( $sql);
        foreach($sem as $value){
            $stmt->execute([$value]);
            $res=$stmt->fetchColumn();
            $semarr[]=$res;
        }
        for($i=0;$i<5;$i++){
            for($j=0;$j<6;$j++){
                $comp="$i$j";
                if(in_array($comp,$t_code)){
                    $c=array_search($comp,$t_code);
                    $arr[$i][$j]="$sub[$c]</br>$sec[$c]</br>$semarr[$c]</br>Room($room[$c])";
                }
                else $arr[$i][$j]=" " ;     
            }
        }
        $t=[];
        $t=out_layout($t,$conn);
        $t=add_sub($t,$arr);
        disp_table($t);
    }
    function tablefromteach($code,$conn, $row_name){
        try{
            // $stmt->execute([$th_code]);
            // $th_name= $stmt->fetchColumn();
            // echo "</br> <p class='msg'>".$th_name./*($th_code)*/"</p>";
                $temp[] ="";$s_code=[];$type=[];
            $sql="SELECT name FROM teacher where teacher_id=?";
            $tchstmt = $conn->prepare($sql);
            $sql="SELECT subject_name FROM subject where subject_id=?";
            $substmt=$conn->prepare($sql);
            $sql="SELECT semester_name FROM semester where semester_id=?";
            $semstmt=$conn->prepare( $sql);
            $sql="SELECT section_name FROM section where section_id=?";
            $secstmt=$conn->prepare( $sql);
            $sql = "SELECT * FROM teach where $row_name =?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$code]);
            $result =$stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach($result as $row){
                if(!empty($temp[$row['day_P']])&&str_contains($temp[$row['day_P']],$row['subject_id'])){
                    $secstmt->execute([$row['section_id']]);
                    $result=$secstmt->fetchColumn();
                    $temp[$row['day_P']].="<span class='semsec'>".$result."  ";
                    $semstmt->execute([$row['semester_id']]);
                    $result=$semstmt->fetchColumn();
                    $temp[$row['day_P']].= $result."</span><br/>";
                    if(!str_contains($temp[$row["day_P"]],$row["rm_code"])){
                    $temp[$row['day_P']] .="<span class ='room'>Room (".$row['rm_code'].")</span><br/>";}
                    if(!str_contains($temp[$row["day_P"]],$row["teacher_id"])){
                        $temp[$row['day_P']].="<span class ='tch'>".$row['teacher_id']."</span><br/>";}
                }else{
                    $temp[$row['day_P']].= "<span class='subject'>".$row['subject_id'];
                    $substmt->execute([$row['subject_id']]);
                    $result=$substmt->fetchColumn();
                    $footersub[$row['subject_id']]= $result;
                    $temp[$row['day_P']].= "(".$row['alias'].")</span><br/>";
                    $secstmt->execute([$row['section_id']]);
                    $result=$secstmt->fetchColumn();
                    $temp[$row['day_P']].="<span class='semsec'>".$result."  ";
                    $semstmt->execute([$row['semester_id']]);
                    $result=$semstmt->fetchColumn();
                    $temp[$row['day_P']].= $result."</span><br/>";
                    $temp[$row['day_P']] .="<span class ='room'>Room (".$row['rm_code'].")</span><br/>";
                    $tchstmt->execute([$row['teacher_id']]);
                    $result=$tchstmt->fetchColumn();
                    $footertch[$row['subject_id']]=$result;
                    $temp[$row['day_P']].="<span class ='tch'>".$row['teacher_id']."</span><br/>";
                }
                // $substmt->execute($row['subject_id']);
                // $result=$substmt->fetchColumn();
                // $temp[$row['day_P']]['sub'] = $result;
            }
        }catch(PDOException $e){
            echo "Error: " .$e->getMessage();
        }
        $arr =[];
        for($i=0;$i<5;$i++){
            for($j=0;$j<6;$j++){
                $arr[$i][$j]=$temp["$i$j"];
            }
        }
        $t=[];
        $t=out_layout($t,$conn);
        $t=add_sub($t,$arr);
        disp_table($t);
        echo"<table>
        <tr> <th>Subject Code</th>
        <th>Subject Name </th>
        <th>Teacher Name </th>
        </tr>
        ";
        foreach($footersub as $scode=>$sub){
            echo"<tr>
            <td>$scode</td>
            <td>$sub</td>
            <td>$footertch[$scode]</td>
            </tr>";
        }
        echo"</table>";
    }
    ?>