<?php
function free_time($tablecl,$conn,$overlap,$fixedfree){
    // echo "<br>Adding free periods";
    $table=$tablecl->table;
    $def_index=$tablecl->index;
    $sub_str=$tablecl->sub;

    if ($overlap->overlap){
        $sql = "SELECT * FROM teach WHERE section_id = ? and subject_id = ?";
        $stmt = $conn->prepare($sql);
        //get subject names
        foreach($overlap->subjects as $subject){
            $sub_instance=$sub_str[$subject]->sub_name;
            $stmt->execute([$overlap->section_id,$sub_instance]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach($rows as $row){
            $temp = $row["day_P"];
            $i = $temp[0];$j = $temp[1];
            $table[$i][$j] = $row["subject_id"];
            $sub_str[$subject]->sub_period[]="$i$j";
            }
        $sub_str[$subject]->amtime=0;
        $sub_str[$subject]->pmtime=0;
        $sub_str[$subject]->sub_need= "";
        unset($def_index[$subject]);                    
        }
    }

    //2 default free time on Wednesday for third years and above else on Friday
    $table[$fixedfree][4]=" ";
    $table[$fixedfree][5]=" ";
    //make 4 random free periods free
    //Mon=6,Thu=6,Tue=4,Fri=4
    for($i=1;$i<5;$i++){
        do{ 
            $free=rand(0,15);
            $r = $free==15?($free-1)/3:$free/3;
            $c = ($i % 3) == 0?($free%3)+3:$free%3;
        }while(isset($table[$r][$c])||$c==2||$c==4||$r==$fixedfree);
        $table[$r][$c]=" ";
    }
    $revar =new materials($table,$def_index,$sub_str);
    // var_dump($revar);
    return $revar;
}

function fill_cell($material,$ind){
    // echo "<br> Covering empty slots";
    $table=$material->table;
    // $ind=$material->ind;
    $sub_str=$material->sub;
    // echo "<pre>";
    // print_r($ind);
    for($i=0;$i<=5;$i++){
        $sub_instance[$i]=$sub_str[$i]->sub_name;
        }
    $find = call_user_func_array('array_merge', $ind);
    $oc=array_count_values($find);
        $amneed =0;$pmneed=0;$i=0;$j=0;
    foreach($oc as $a => $b){
        if($b<4){
            if($sub_str[$a]->amtime>0){$amneed++;$subjectam[]=$a;}
            elseif($sub_str[$a]->pmtime>0){$pmneed++;$subjectpm[]=$a;}      
        }
    }
    for($date=0;$date<5;$date++){
        for($period=0;$period<6;$period++){
            if(!isset($table[$date][$period])) {//only if absent
                $exc=array_values(array_diff([0,1,2,3,4,5],$ind[$date]));//take subindexes that are not in here
            if($period<3){
                if(!in_array($subjectam[$i],$ind[$date])){//if the left is not in empty cell arr,
                    // echo "def=ind";
                    $table[$date][$period] = $sub_instance[$subjectam[$i]];//put into empty cell
                    $ind[$date][$period]=$subjectam[$i];$i++;break;
                }else{
                    // echo"def!=ind";
                    foreach($ind as $key => $value){//echo $key;search the whole array
                        
                    if(isset($subjectam[$i])&&!in_array($subjectam[$i],$value)){//echo "def is not in here";for a row that doesn't have the left sub
                        for($k=0;$k<count($exc);$k++){
                            // if($c>=2&&$period<4)continue;
                            //  else{
                        if(in_array ($exc[$k],$value)){//echo "exc is in here";about to swap so notin subindex existed row is taked
                            $index = array_search($exc[$k],$value);//take cell key where the not in exist
                            if($index >2)continue;//for am time
                            if(isset($sub_str[$subjectam[$i]]->frpdofth)&&in_array("$key$index",$sub_str[$subjectam[$i]]->frpdofth))continue;
                            $table[$key][$index]=$sub_instance[$subjectam[$i]];//exc is overwrited
                            $ind[$key][$index] = $subjectam[$i];//in index too
                            $table[$date][$period]=$sub_instance[$exc[$k]];//emptycell is filled
                            $ind[$date][$period]=$exc[$k];
                            $i++;//insummary the cell are swapped and empt get filled
                            break;}
                        // }
                        }
                        break;
                    }
                }

                }
            }else{
                if(!in_array($subjectpm[$j],$ind[$date])){//if the left is not in empty cell arr,
                    // echo "def=ind";
                    $table[$date][$period] = $sub_instance[$subjectpm[$j]];//put into empty cell
                    $ind[$date][$period]=$subjectpm[$i];$j++;break;
                }
                else{
                    // echo"def!=ind";
                    foreach($ind as $key => $value){//echo $key;search the whole array
                    if(isset($subjectpm[$j])&&!in_array($subjectpm[$j],$value)){//echo "def is not in here";for a row that doesn't have the left sub
                        for($k=0;$k<count($exc);$k++){
                            // if($c>=2&&$period<4)continue;
                            //  else{
                        if(in_array ($exc[$k],$value)){//echo "exc is in here";about to swap so notin subindex existed row is taked
                            $index = array_search($exc[$k],$value);//take cell key where the not in exist
                            if($index<3)continue;//for pm time
                            if(isset($sub_str[$subjectam[$i]]->frpdofth)&&in_array("$key$index",$sub_str[$subjectam[$i]]->frpdofth))continue;
                            $table[$key][$index]=$sub_instance[$subjectpm[$j]];//exc is overwrited
                            $ind[$key][$index] = $subjectpm[$j];//in index too
                            $table[$date][$period]=$sub_instance[$exc[$k]];//emptycell is filled
                            $ind[$date][$period]=$exc[$k];
                            $j++;//insummary the cell are swapped and empt get filled
                            break;}
                        // }
                        }
                        break;
                    }
                }

                }
            }
            }

        }
    }
    $revar = new materials( $table,[],$sub_str);
    return $revar;

}
function sub_generator($tablecl){
    // echo "<br>Generating subject table for section";
    $sub_str =$tablecl->sub;
    $table = $tablecl->table;
    $defind = $tablecl->index;
    // var_dump($table);
    // var_dump($sub_str);
    // $ind=$tablecl->ind;
    foreach($defind as $i){
        $sub_instance[$i]=$sub_str[$i]->sub_name;//because sometime php ignre '->'
        $frpdofth[$i]=$sub_str[$i]->frpdofth ;
    }               
    for($date=0;$date<=4;$date++){
        $pm =$am =$defind;
        // $temp = $sub_count;
        foreach($sub_str as $value){
            $value->amrec();
            $value->pmrec();
        }
        if($date>0){
            foreach($sub_str as $key => $subj){
        if($subj->amtime==0)
        {
        unset($am[$key]);
        }
        if($subj->pmtime==0)
        {
        unset($pm[$key]);
        }                    
                }
    }
        for($period=0;$period<=5;$period++){
            // echo "$date$period".$table[$date][$period]."</br>";
            if(isset($table[$date][$period]))continue;//skip filled cells
            if(!empty($am)||!empty($pm)){
                // $test = rand(0,count($sub_index)-1);//out random
                if($period<3) {
                    $sub_index=array_values($am);
                    $test = rand(0,count($sub_index)-1);
                }else {
                    $sub_index=array_values($pm);
                    $test = rand(0,count($sub_index)-1);
                }
                if(!empty($sub_index)){
                    // if($sub_str[$sub_index[$test]]->teacher )//check if teachers are free
                    $check ="$date$period";//for no th period overlap
                    while(!empty($frpdofth[$sub_index[$test]])&&in_array($check,$frpdofth[$sub_index[$test]])&&count($sub_index)>1){
                        if(count($sub_index)>1)unset($sub_index[$test]);
                        else $table[$date][$period] = null;
                        $sub_index=array_values($sub_index);
                        $test = rand(0,count($sub_index)-1);//rand without the unwanted
                    }
                        $crucial=[];
                    if($date>0&&$date!=4){
                        if($period<3){
                            foreach($sub_str as $key=>$value){
                                if($value->amtime+$value->pmtime>=5-$date&&$value->amtime>=$value->pmtime){
                                    $crucial[]=$key;
                                }
                            }
                        }elseif($period>=3){
                            foreach($sub_str as $key=>$value){
                                if($value->amtime+$value->pmtime>=5-$date&&$value->amtime<=$value->pmtime){
                                    $crucial[]=$key;
                                }
                            }
                        }
                    }
                    if(!empty($crucial)){
                    $test = rand(0,count($crucial)-1);
                    $table[$date][$period]= $sub_instance[$crucial[$test]];//put data into timeslots
                    }else{
                    $table[$date][$period]= $sub_instance[$sub_index[$test]];//put data into timeslots

                    // var_dump($sub_str[$test]);
                    $able = false;
                    $bool=$sub_str[$test]->consecutive;
                    echo $bool;
                    if($period!=2&&$period!=5&&$date!=0&&$bool){
                        var_dump($sub_str[$test]);
                        echo"why are u here $date$period  $test  ";
                        // var_dump($sub_str[$test]->consecutive);
                        if($period<3&&$sub_str[$test]->amtime>1){
                            $sub_str[$test]->amtime--;$able = true;
                        }elseif($period< 5&&$sub_str[$test]->pmtime>1){
                            $sub_str[$test]->pmtime--;$able = true;
                        }
                        if($able){
                        // echo"$date$period" ;
                        $table[$date][$period+1]= $sub_instance[$sub_index[$test]];
                        
                        $sub_str[$test]->consecutive = false;
                        $able = false;
                        }
                    }
                }
            // $ind[$date][$period]=$sub_index[$test]; // record of indexes
            //record period of subject
            //no first period overlap
            if($date>0 && count($sub_index)!=1 &&$period==0){
                if($table[$date][0] == $table[$date-1][0]){
                    $pd=1;
                    $table[$date][$period]= null;
                    while(isset($table[$date][$period+$pd])){
                        $pd++;
                    }
                    $table[$date][$period+$pd]= $sub_instance[$sub_index[$test]];//put data into timeslots
                    $period--;
                    // $ind[$date][$period]=$sub_index[$test];
                }
                }
            if($period<3) {
                if(!empty($crucial))$sub_str[$crucial[$test]]->amtime--;
                else $sub_str[$sub_index[$test]]->amtime--;
            }else {
                if(!empty($crucial))$sub_str[$crucial[$test]]->pmtime--;
                else $sub_str[$sub_index[$test]]->pmtime--;
            }
            if(!empty($crucial)){
            unset($am[$crucial[$test]]);
            unset($pm[$crucial[$test]]);
        }else{
            unset($am[$sub_index[$test]]);
            unset($pm[$sub_index[$test]]);
        }
            }
        } else break;
        // echo "$date$period".$table[$date][$period]."</br>";
            
        } 
    //no last period overlap
    // if($date>0){
    //     if(isset($table[$date][5])&&$table[$date][5]!=" "&&$table[$date][5]==$table[$date-1][5]){
    //         for($p=0;$p<=5;$p++){
    //             if($table[$date][$p]==" ")continue;
    //             else $table[$date][$p]=null; 
    //             } 
    //             foreach($sub_str as $value){
    //                 $value->rollback();
    //             }
    //             $date--;
    //     //    $sub_count=$temp;
    //     }
    // }
    // var_dump($table[$date]);
    }
    $revar = new materials($table,[],$sub_str/*,$sub_count*/);
    // var_dump($revar);
    return $revar;
}
function getperiod($table,$sub_str){
    for($date=0;$date<=count($table)-1;$date++){
        for($period=0;$period<=count($table[$date])-1;$period++){
            for($i=0;$i<count($sub_str);$i++){
                if(!isset($table[$date][$period]))continue;
                if($table[$date][$period]== $sub_str[$i]->sub_name){
            $sub_str[$i]->sub_period[]="$date$period";
            }
            }
        }

    }
}
function generate_table($conn,$sem,$sub_str,$overlap,$fixedfree){
    // echo "<br>Table Generating . . .";
    echo "<pre>";
    $ind=[];
    $def_index =[0,1,2,3,4,5];
    $subj = [];
    $subject = new materials($subj,$def_index,$sub_str);
    try{
    $subject = free_time($subject,$conn,$overlap,$fixedfree);
    // var_dump($subject);
    $subject = sub_generator($subject);
    $ind=getrandInd($subject->table,$subject->sub);
    $subject=fill_cell($subject,$ind);
    getperiod($subject->table,$sub_str);
    // var_dump($sub_str);
    }catch(Exception $e){
        echo "Please try again";
    };
    // echo "<br>Subject Table generated";
    return $subject;
}
function arrtocode($arr){
    $tcode = "";
    for($i=0;$i<count($arr);$i++){
        for($j=0;$j<count($arr[$i]);$j++){
            $tcode.=$arr[$i][$j];
        }
    }
    return $tcode;
}
function getrandInd($table,$sub_str){
    $ind=[];
    foreach($sub_str as $value){
        $sub_instance[] = $value->sub_name;
    }
    for($date=0;$date<count($table);$date++){
        if(!isset($table[$date]))die(1);
        for($period=0;$period<count($table[$date]);$period++){
            if(!isset($table[$date][$period]))continue;
            if($table[$date][$period]==" ")$ind[$date][$period]=6;
            foreach($sub_instance as $key => $value){
                if(strpos($table[$date][$period],$value)!==false){
                    $ind[$date][$period]=$key;break;
                }
            }
        }
    }
    return $ind;
}
function getrandrind($ind,$sub_str,$conn,$frpdofrm,$overlap){
    $rind=[];
    $temp =[];
    $key = [];
    if($overlap->overlap){
        foreach($sub_str as $value){
            $sub_code[] = $value -> sub_name;
        }
        $section_id=$overlap->section_id;
        foreach($overlap->subjects as $subject){
            $sql = "SELECT * FROM teach WHERE section_id = ? and subject_id =?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$section_id,$sub_code[$subject]]);
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($result as $row) {
                $rind[$row["day_P"]] = $row['rm_code'];
            }
        }
        // var_dump($subject,$sub_code,$sub_code[$subject]);
        // var_dump( $rind );
    }
    $sql = "select * from room";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($result as $row) {
        $allrooms[] = $row["rm_code"];
        $rmcodearr[$row["rm_type"]][] = $row["rm_code"];
    }
    $prev=[6,"",10];
    for($i=0;$i<5;$i++){
        for($j=0;$j<6;$j++){
            if(isset($rind["$i$j"])) {
                // echo"$i$j rind existed<br>";
                continue;}
        // echo "ind";print_r($ind);
            if($ind[$i][$j]==6){
                // echo"$i$j ind <br>";
                continue;}
            // echo "$i$j";
            $available_rooms = empty($frpdofrm["$i$j"])?$allrooms:array_diff($allrooms,$frpdofrm["$i$j"]);
            // var_dump($allrooms,$frpdofrm["$i$j"],$available_rooms);
            $netemp=$sub_str[$ind[$i][$j]]->sub_need;
            $z = $j-1;
            // var_dump($prev);
            if($i==$prev[2]&&$ind[$i][$j]==$prev[0] && substr_count($netemp,$prev[1])>1&&in_array($rind["$i$z"],$available_rooms)){
                echo"one room consecutive";
                $rind["$i$j"] = $rind["$i$z"];
                continue;
            }
            $key = str_split($netemp);$useable = [];
            $c = count($key);
            // echo $netemp."<br>";
            foreach ($key as $f=>$v) {
                if($v!='A'&&($i==0||$j==0)&&$c!=$f) continue;
                foreach($rmcodearr[$v] as $value){
                    if(in_array($value,$available_rooms)){
                        $useable[] = $value;
                    }
                }
                // var_dump($useable);
                if(!empty($useable)) {
                    $prev[1]=$v;
                    $sub_str[$ind[$i][$j]]->sub_need=preg_replace('/'.$v.'/','',$netemp,1);
                    // $random = rand(0,count($rmcodearr[$v])-1);
                    $rind["$i$j"] = $useable[0];
                    break;
                }else {echo "no room left ON $i$j FOR $v<br>";continue;}
            }
            $prev[2]=$i;
            $prev[0] = $ind[$i][$j];
    }
    }
    // var_dump($rind);
    $count = 24 - count($rind);
    if(count($rind)<24) echo "$count room is missing";
    return $rind;
}
function getfrpdofrm($conn){
    $temp=[];
    try{
    $sql = "SELECT * FROM teach where day_P=?";
    $stmt = $conn->prepare($sql);
    for($i=0;$i<5;$i++){
        for($j=0;$j<7;$j++){
            $key="$i$j";
    $stmt->execute([$key]);
    $result=$stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($result as $row){
        $temp[$key][]=$row['rm_code'];
    }
        }
    }
    }catch(PDOException $e){
        echo "error ".$e->getMessage();
    }
    return $temp;
}
function savetimetable($ind,$conn,$sem,$sec){
    $ttcode=arrtocode($ind);
        try{
            $sql = "UPDATE section set timetable_code = ? where section_id = ? and semester_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$ttcode,$sec,$sem]);
        }catch(PDOException $e){
            echo "error ".$e->getMessage();
        }
}
function savethsub($conn,$sub_str,$rind,$ltdas,$ind,$sec,$sem){
    try{
        $sql = "INSERT INTO teach (`day_P`,`alias`,`rm_code`,`subject_id`,`teacher_id`,`section_id`,`semester_id`)
        VALUES (?,?,?,?,?,?,?)";
        $stmt=$conn->prepare($sql);
        foreach($sub_str as $value){
            // var_dump($value);
            $s_code = $value->sub_name;
            $t_code= $value->sub_teacher;    
            // var_dump($t_code);
            $s_period = $value->sub_period;
            foreach($s_period as $per){
                $roomcode = $rind[$per];
                $alias = $ltdas[$per];
                $stmt->execute([$per,$alias,$roomcode,$s_code,$t_code,$sec,$sem]);    
            }
        }
        for($i=0;$i<5;$i++){
            for($j=0;$j<6;$j++){
                if($ind[$i][$j]==6) $stmt->execute(["$i$j",null,null,null,null,$sec,$sem]);
            }
        }
    }catch(PDOException $e){
    echo "Error ".$e->getMessage();
}
}
function checkInd($ind,$sub_str){
    $prev="";
    $testarr = [0,0,0,0,0,0,0];
    $consec =[];
    // var_dump($ind);
    $a = 0;
    for($i= 0;$i<count($ind);$i++){
        for( $j= 0;$j<count($ind[$i]);$j++){
            $testarr[$ind[$i][$j]]++;
            if($a==$i&&$ind[$i][$j] == $prev){
                // echo $ind[$i][$j];
                $consec[]= $ind[$i][$j];
            }
            $a = $i;
            $prev = $ind[$i][$j];
            // var_dump($prev);
        }
    }
    foreach($testarr as $k=>$v){
        if($k != 6){
        if($v > 4)echo"<p class='msg'>".$sub_str[$k]->sub_name." is populating ".$v." times <br></p>";
        elseif($v<4)echo"<p class='msg'>".$sub_str[$k]->sub_name." is populating ".$v." times <br></p>";
        }else {
            if($v>6) echo"<p class='msg'>The blank space is taking $v times<br></p>";
        }
    }
    // var_dump($consec);
    foreach($consec as $v){
        if($v!=6)echo "<p class='msg'>".$sub_str[$v]->sub_name."  is consecutive<br></p>";
    }
}