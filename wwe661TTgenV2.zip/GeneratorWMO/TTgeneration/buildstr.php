<?php
function saveconov($sec,$ovsec,$sub,$consecutive,$conn){
    //semester ::A,B,C,D,E,F,G,H,I,J semester 1 to 10    
    //major ::A,B,C,D,E,F,G,H,I (CS,CT,SE,KE,HPC,BIS,NETWORKING,ES,CYBER)
    //sections ::A,B,C,D,E (Max 5 sections)
    //subjects :: 0,1,2,3,4,5 (6 subjects) 
    $temp = "";
    if(isset($ovsec)){
    foreach (str_split($ovsec) as $value) {
        $temp .= chr(64 + intval($value)); 
    }
    foreach ($sub as $value) {
        $temp .=  $value; 
    }}else $temp = null;

    $contemp="";
    if(isset($consecutive)){
    foreach ($consecutive as $value) {
        $contemp .= $value;
    }
    }else $contemp=null;
    
    // var_dump($temp);var_dump($sec);var_dump($ovsec);var_dump($sub);
    $stmt=$conn->prepare("update section set overlap= ? ,consecutive = ? where section_id = ?");
    $stmt->execute([$temp,$contemp,$sec]);
}
function getoverlap($sec,$conn){
    $section_id="";
    $sql = "SELECT * FROM section WHERE section_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$sec]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $row) {
        $overlap= $row['overlap'];
    }
    if ($overlap) {
    $bool = true;
    foreach(str_split($overlap) as $letter){
        if ($letter >= 'A' && $letter <= 'Z') {
        $section_id.= ord($letter) - 64; // 'A' = 1, 'B' = 2, etc.
        }else{
            $subjects[]=$letter;
        }
    }
    }else {
        $overlap = null;
        $section_id = null;
        $subjects = null;
    }
    $revar = new overlap($bool,$section_id,$subjects);
return $revar;
}
function buildsubstr($sub_str,$conn,$sem,$sec){ 
    $temp=getscode($sem,$conn);
    for($i=0;$i<count($sub_str);$i++){
        $sub_str[$i]->sub_name=$temp[$i +3];
    }        
    $temp=getsubth($sub_str,$conn,$sec);
    for($i=0;$i<count($sub_str);$i++){
        $sub_str[$i]->sub_teacher=$temp[$i];
    }        
    $temp=getsubtype($sub_str,$conn);
    for($i=0;$i<count($sub_str);$i++){
        $sub_str[$i]->sub_type =$temp[$i];
    }        
    $temp=getfrpdofth($sub_str,$conn);
    for($i=0;$i<count($sub_str);$i++){
        $sub_str[$i]->frpdofth = empty($temp) ? null : $temp[$i];
    }      
    $temp=getsubneed($sub_str,$conn);
    for($i=0;$i<count($sub_str);$i++){
        $sub_str[$i]->sub_need =$temp[$i];
    }  
    $sub_str = checkconsec($sub_str,$sec,$conn);     
return $sub_str;
}
function getscode($sem,$conn){
$temp=[];
try{
$sql = "SELECT * FROM semester where semester_id= ?";
$stmt = $conn->prepare($sql);
$stmt->execute([$sem]);
$result =$stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($result as $row){
    foreach ($row as $key => $columnValue) {
        $temp[]= $columnValue;
    }
}
}catch(PDOException $e){
    echo "Error: " .$e->getMessage();
}
return $temp;
}
//take teacher
function getsubth($sub_str,$conn,$sec){
$temp =[];
try{
        $sql="SELECT * FROM th_sub where subject_id= ? AND section_id= ?";
        $stmt = $conn->prepare($sql);
    foreach($sub_str as $subobj){
        $sub = $subobj->sub_name;
// var_dump($sub);
$stmt->execute([$sub,$sec]);
$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($result as $row){
$temp[]=$row['teacher_id'];
}
    }
}catch(PDOException $e){
    echo "error ".$e->getMessage();
}
return $temp;
}
//get subtype
function getsubtype($sub_str,$conn){
$temp=[];
try{
$sql="SELECT * FROM subject where subject_id= ?";
$stmt = $conn->prepare($sql);
    foreach($sub_str as $subobj){
        $sub= $subobj->sub_name;
$stmt->execute([$sub]);
$result=$stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($result as $row){
$temp[]=$row['type'];
}
    }
}catch(PDOException $e){
    echo "error ".$e->getMessage();
}
return $temp;
}
//get formerperiod of teacher
function getfrpdofth($sub_str,$conn){
    $temp=[];
    try{
    $sql = "SELECT * FROM teach where teacher_id=?";
    $stmt = $conn->prepare($sql);
    foreach($sub_str as $key => $subobj){
        $th= $subobj->sub_teacher;
    $stmt->execute([$th]);
    $result=$stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($result as $row){
    $temp[$key][]=$row['day_P'];
    }
    }
    }catch(PDOException $e){
        echo "error ".$e->getMessage();
    }
    return $temp;
}
function getsubneed($sub_str,$conn){
    $temp=[];
    try{
    $sql="SELECT * FROM subject where subject_id= ?";
    $stmt = $conn->prepare($sql);
        foreach($sub_str as $subobj){
            $sub= $subobj->sub_name;
    $stmt->execute([$sub]);
    $result=$stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($result as $row){
    $temp[]=$row['need'];
    }
        }
    }catch(PDOException $e){
        echo "error ".$e->getMessage();
    }
    return $temp;
}
function checkconsec($sub_str,$sec,$conn){
    // echo"<pre>";
    $sql="select consecutive from section where section_id =?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$sec]);
    $result=$stmt->fetchColumn();
    // var_dump("seriously ".$result);
    if(isset($result)){
        $arr = str_split($result);
        foreach ($sub_str as $key => $value){
        if(in_array($key,$arr)){$value->consecutive=true;
        // var_dump($value);
        }
        }
    }
    return $sub_str;
}