<?php
session_start();
extract($_POST);
include("Database/config.php");
// var_dump($_SESSION["db_name"]);
    $con = conn_mysqli("localhost","USER","wild","Waing@4421661");
if(isset($login)){
    $pwd = $PASS; // See the entire $_POST array
    // Use a prepared statement
    $stmt = $con->prepare("SELECT * FROM users WHERE name = ? AND password = ?");
    $stmt->bind_param("ss", $UN, $pwd);  // "ss" indicates that both parameters are strings

    // Execute the statement
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    if(count($row) > 0){
        $_SESSION['user'] = $row['name'];
        header("Location: display/start.php");
    }
}
if(isset($reg)){
$stmt = $con->prepare("SELECT * FROM users WHERE name = ?");
$stmt->bind_param("s", $UN);  // "ss" indicates that both parameters are strings

// Execute the statement
$stmt->execute();
$result = $stmt->get_result();
$username = $result->fetch_assoc();
$stmt = $con->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $EM);  // "ss" indicates that both parameters are strings

// Execute the statement
$stmt->execute();
$result = $stmt->get_result();
$email = $result->fetch_assoc();
if(isset($username)&&count($username) > 0){
    $err="The name is already taken";
    header("Location: index.php?info=reg&err=$err");
}elseif(isset($email)&&count($email) > 0){
    $err="This email is already taken.";
    header("Location: index.php?info=reg&err=$err");
}else{
    $stmt = $con->prepare("insert into users (name,email,password) values (?,?,?)");
    $stmt->bind_param("sss", $UN,$EM,$PASS);
    $stmt->execute();
    $err = "Register successfully";
    header("Location: index.php?info=login&err=$err");
}
}