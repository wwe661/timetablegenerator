<?php
session_start();
error_reporting(1); // Suppress non-critical warnings
function conn_mysqli($db_host,$db_name,$db_username,$db_password){
    // Specify the new MySQL port in the mysqli_connect function
    $con = mysqli_connect("$db_host", "$db_username", "$db_password", "$db_name");

    // Check if the connection failed
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error()); // Display error message if connection fails
    }
    return $con;
}
function connect($db_host,$db_name,$db_username,$db_password){
    // Add the port number to the DSN string
    $dsn = "mysql:host=$db_host;dbname=$db_name";
    try{
        // Create a PDO instance (connect to the database)
        $conn = new PDO($dsn, $db_username, $db_password);
        // Set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        // If the connection fails, output the error
        echo "Connection failed: " . $e->getMessage();
    }
    return $conn;
}
$db_host = "localhost";
$db_username = "wild";
$db_password = "Waing@4421661";
// var_dump($_SESSION['db_name']);
$db_name = $_REQUEST['db_name'];
if(isset($_REQUEST['db_name']))$_SESSION['db_name'] = $db_name;
// var_dump($_SESSION['db_name']);

if (isset($_SESSION['db_name']) && !empty($_SESSION['db_name'])) {
    $db_name = $_SESSION['db_name'];
    // echo"<style>
    // #toggle{
    // display:none;}
    // </style>";
} 
$con = conn_mysqli($db_host,$db_name,$db_username,$db_password);
$conn=connect($db_host,$db_name,$db_username,$db_password);//PDO connection
