<form id="programForm" method="POST" action="">
    <label>
        <input type="radio" name="programChoice" value="existing" checked>
        Choose an existing program
    </label>
    <select name="existingProgram">
        <!-- Populate this with existing programs from the database -->
        <option value="program1">Program 1</option>
        <option value="program2">Program 2</option>
    </select>
    
    <label>
        <input type="radio" name="programChoice" value="new">
        Create a new program
    </label>
    <input type="text" name="newProgramName" placeholder="Enter new program name" disabled>

    <button type="submit">Submit</button>
</form>

<script>
    // Enable/Disable new program name input based on radio selection
    document.querySelectorAll('input[name="programChoice"]').forEach((radio) => {
        radio.addEventListener('change', function() {
            const newProgramInput = document.querySelector('input[name="newProgramName"]');
            if (this.value === 'new') {
                newProgramInput.disabled = false;
            } else {
                newProgramInput.disabled = true;
                newProgramInput.value = ''; // Clear input if not creating new
            }
        });
    });
</script>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection details
    $host = 'localhost';
    $rootUser = 'wild';
    $rootPass = 'Waing@4421661';

    // Get the form inputs
    $programChoice = $_POST['programChoice'];
    $newProgramName = isset($_POST['newProgramName']) ? $_POST['newProgramName'] : null;
    $existingProgram = isset($_POST['existingProgram']) ? $_POST['existingProgram'] : null;

    // Choose database based on user selection
    $databaseToUse = '';

    if ($programChoice == 'new' && !empty($newProgramName)) {
        // Create a new database with the user-provided name
        try {
            $conn = new PDO("mysql:host=$host", $rootUser, $rootPass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Create the new database
            $sql = "CREATE DATABASE " . $newProgramName;
            $conn->exec($sql);

            // Use the new database
            $databaseToUse = $newProgramName;

            // Import the shell.sql file
            $sqlFile = file_get_contents('shell.sql');
            $conn->exec("USE $databaseToUse; " . $sqlFile);

            echo "Database '$newProgramName' created successfully!";
            echo "<a href='../display/admindashboard.php?db_name=$databaseToUse'>Continue</a>";
        } catch (PDOException $e) {
            echo $e->getMessage();
            echo "<a href='../display/admindashboard.php?db_name=$databaseToUse'>Continue</a>";
        }
    } elseif ($programChoice == 'existing' && !empty($existingProgram)) {
        // Use the selected existing program
        $databaseToUse = $existingProgram;
        echo "Using existing database '$existingProgram'.";
        echo "<a href='../display/admindashboard.php&dbname=$databaseToUse'>Continue</a>";
    } else {
        echo "No valid choice made.";
        exit;
    }

    // Connect to the chosen database and proceed with further operations
    // Example: $conn = new PDO("mysql:host=$host;dbname=$databaseToUse", $rootUser, $rootPass);
}
?>