-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 08, 2024 at 08:48 PM
-- Server version: 8.0.39-0ubuntu0.24.04.2
-- PHP Version: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wmofinal1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `eid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `department_id` int NOT NULL,
  `department_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `layout`
--

CREATE TABLE `layout` (
  `id` int NOT NULL,
  `0` varchar(20) DEFAULT NULL,
  `1` varchar(20) DEFAULT NULL,
  `2` varchar(20) DEFAULT NULL,
  `3` varchar(20) DEFAULT NULL,
  `4` varchar(20) DEFAULT NULL,
  `5` varchar(20) DEFAULT NULL,
  `6` varchar(20) DEFAULT NULL,
  `7` varchar(20) DEFAULT NULL,
  `8` varchar(20) DEFAULT NULL,
  `9` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `layout`
--

INSERT INTO `layout` (`id`, `0`, `1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`, `9`) VALUES
(0, 'DAYS\\PERIODS', '8:30am - 9:30am', '9:40am - 10:40am', '10:50am - 11:50am', '11:50am - 12:40pm', '12:40pm - 1:40pm', '1:50pm - 2:50pm', '3:00pm - 4:00pm', NULL, NULL),
(1, 'Monday', ' ', ' ', ' ', 'Lunch', ' ', ' ', ' ', NULL, NULL),
(2, 'Tuesday', ' ', ' ', ' ', 'Lunch', ' ', ' ', ' ', NULL, NULL),
(3, 'Wednesday', ' ', ' ', ' ', 'Lunch', ' ', ' ', ' ', NULL, NULL),
(4, 'Thursday', ' ', ' ', ' ', 'Lunch', ' ', ' ', ' ', NULL, NULL),
(5, 'Friday', ' ', ' ', ' ', 'Lunch', ' ', ' ', ' ', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `ID` int UNSIGNED NOT NULL,
  `rm_code` varchar(20) NOT NULL,
  `rm_type` varchar(20) NOT NULL,
  `rm_capacity` int NOT NULL DEFAULT '40'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`ID`, `rm_code`, `rm_type`, `rm_capacity`) VALUES
(1, '231', 'B', 40),
(2, '232', 'B', 40),
(3, '233', 'B', 40),
(4, '234', 'B', 40),
(5, '235', 'B', 40),
(6, '236', 'B', 40),
(7, '321', 'A', 40),
(8, '322', 'A', 40),
(9, '323', 'A', 40),
(10, '324', 'A', 40),
(11, '325', 'A', 40),
(12, '326', 'A', 40),
(13, '331', 'A', 40),
(14, '332', 'A', 40),
(15, '333', 'A', 40),
(16, '334', 'A', 40),
(17, '335', 'A', 40),
(18, '336', 'A', 40),
(19, '353', 'K', 40),
(20, '352', 'C', 40),
(21, '351', 'H', 40),
(22, '342', 'F', 40),
(23, '245', 'P', 40),
(24, '244', 'E', 40),
(26, '214', 'A', 80),
(27, '215', 'A', 80),
(28, '346', 'A', 40);

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE `section` (
  `section_id` int NOT NULL,
  `section_name` varchar(20) NOT NULL,
  `timetable_code` varchar(50) DEFAULT NULL,
  `semester_id` int NOT NULL,
  `section_capacity` int NOT NULL DEFAULT '40',
  `overlap` varchar(30) DEFAULT NULL,
  `consecutive` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `section`
--

--
-- Table structure for table `semdep`
--

CREATE TABLE `semdep` (
  `assignment_id` int NOT NULL,
  `department_id` int NOT NULL,
  `semester_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `id` int NOT NULL,
  `semester_id` int NOT NULL,
  `semester_name` varchar(50) NOT NULL,
  `subject1` varchar(30) NOT NULL,
  `subject2` varchar(30) NOT NULL,
  `subject3` varchar(30) NOT NULL,
  `subject4` varchar(30) NOT NULL,
  `subject5` varchar(30) NOT NULL,
  `subject6` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `semester_id` int NOT NULL,
  `section_id` int NOT NULL,
  `stu_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subject_id` varchar(20) NOT NULL,
  `subject_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `type` varchar(20) NOT NULL,
  `need` varchar(6) NOT NULL,
  `id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_id`, `subject_name`, `type`, `need`, `id`) VALUES
('CST-1201', 'Calculus', 'A', 'AAAA', 1),
('CST-1301', 'Introduction to Business and Fundamentals of Information Systems(sem1)', 'B', 'BBAA', 2),
('CST-1401', 'Digital Fundamentals of Computer Systems', 'B', 'BAAA', 3),
('CST-1501', 'Integrating Critical Thought and Language Skills', 'E', 'EAAA', 4),
('CST-1601', 'Myanmar Literature', 'A', 'AAAA', 5),
('CST-1701', 'Physics (Mechanics and Electromagnetism)', 'P', 'PPAA', 6),
('CST-3102', 'Data Structure and Algorithms', 'A', 'AAAA', 7),
('CST-3103', 'Operating Systems Fundamentals', 'B', 'BBAA', 8),
('CST-3202', 'Discrete Structure I', 'A', 'AAAA', 9),
('CST-3302', 'Software Modeling and Analysis', 'B', 'BAAA', 10),
('CST-3303', 'Introduction to Business and Fundamentals of Information Systems', 'B', 'BAAA', 11),
('CST-3503', 'English Language Proficiency III', 'E', 'EAAA', 12),
('CS-5307', 'Advanced Web Technology', 'B', 'BBBB', 13),
('CST-5105', 'Artificial Intelligence', 'A', 'AAAA', 14),
('CST-5203', 'Engineering Mathematics', 'B', 'BAAA', 15),
('CST-5306', 'Software Requirement Engineering', 'B', 'BAAA', 16),
('CST-5404', 'Advanced Networking', 'B', 'BAAA', 17),
('CST-5405', 'Computer Architecture', 'B', 'BAAA', 18),
('CT-5407', 'Engineering Circuit and Signals', 'B', 'BAAA', 19),
('CST-6106', 'Social Issues and Ethics', 'B', 'BAAA', 20),
('CST-6107', 'Computer Organization', 'B', 'BAAA', 21),
('CST-6204', 'Linear Algebra', 'B', 'BAAA', 22),
('CST-6308', 'Management Principled & Engineering Economics', 'A', 'AAAA', 23),
('CST-6406', 'Network Design & Engineering', 'B', 'BBAA', 24),
('CS-6309', 'Microservices for the Enterprise', 'A', 'AAAA', 25),
('CS-6310', 'Introduction to Entrepreneurshinp', 'A', 'AAAA', 26),
('CST-6410', 'Foundations of Cybersecurity', 'A', 'AAAA', 27),
('CST-6108', 'Enterprise Applications Development Using Java', 'B', 'BBAA', 28),
('CT-6408', 'Electronic Devices for Embedded Systems', 'B', 'BAAA', 29),
('CT-6409', 'Data and Computer Communications', 'A', 'AAAA', 30),
('CS-7109', 'Analysis of Algorithms', 'A', 'AAAA', 31),
('CS-7311', 'Business Management Information Systems', 'B', 'BAAA', 32),
('CS-7312', 'Enterprise Systems, Security and Risk Management', 'B', 'BAAA', 33),
('CS-7313', 'Advanced Database Management System', 'B', 'BBAA', 34),
('CS-7314', 'Software Quality Management', 'B', 'BAAA', 35),
('CST-7505', 'Technical Writing for Professional Development', 'E', 'EAAA', 36),
('CST-7416', 'Fuzzy Logic System', 'A', 'AAAA', 37),
('KE-7112', 'Computer Graphics', 'B', 'BBAA', 38),
('KE-7113', 'Knowledge Engineering and Intelligent Systems', 'B', 'BAAA', 39),
('CST-7110', 'Distributed Systems', 'A', 'AAAA', 40),
('CST-7412', 'Network Management and Monitoring', 'B', 'BAAA', 41),
('HPC-7111', 'Introduction to High Performance Computing', 'B', 'BAAA', 43),
('BIS-7315', 'Business Process Management ', 'B', 'BAAA', 44),
('ES-7207', 'Mathematical Models of System and Control	', '', '', 47),
('ES-7417', 'Microcontroller Programming		', '', '', 48),
('ES-7418', 'Sensors & Electronics', '', '', 49),
('ES-7419', 'Control System		', '', '', 50),
('CS-9124', 'Interactive Multimedia Systems', 'B', 'BAAA', 51),
('CS-9320', 'Service Oriented Architecture:Concept and Technology(Capstone Project)', 'B', 'BBAA', 52),
('CST-9212', 'Stochastic Models', 'A', 'AAAA', 53),
('SE-9325', 'Machine Learning  with Data Visualization', 'B', 'BAAA', 54),
('SE-9326', 'Advanced Software Engineering', 'B', 'BBBA', 55),
('SE-9327', 'Data processing Techniques in Distributed Systems', 'B', 'BBAA', 56),
('KE-9125', 'Computational Linguistics', 'B', 'BBAA', 57),
('KE-9126', 'Data Science for Business', 'B', 'BAAA', 58),
('KE-9127', 'Semantic Web and Ontology Engineering', 'B', 'BBBA', 59),
('KE-9128', 'Design, Concepts and Methodology for Knowledge-based Intelligent Systems(Capstone Project)', 'B', 'BBBA', 60),
('CST-9119', 'Data Center Networking and the New Converged Inter', 'B', 'BBAA', 61),
('HPC-9120', 'Virtualization Technology and Cloud Computing ', 'B', 'BAAA', 62),
('HPC-9121', 'Blockchain Technology and the Internet of Things', 'F', 'FAAA', 63),
('HPC-9122', 'High Performance Big Data Analytics', 'F', 'FFFF', 64),
('HPC-9123', 'Design and Concepts for Building a Modern Computing System(Capstone Project)', 'F', 'FFFF', 65),
('BIS-9321', 'Business Intelligence', 'B', 'BAAA', 66),
('BIS-9322', 'Information Systems Project Management', 'B', 'BAAA', 67),
('BIS-9323', 'IT/IS Strategy, Management and Acquisition', 'B', 'BAAA', 68),
('BIS-9324', 'Accounting for Managers', 'A', 'AAAA', 69),
('CN-9424', 'Network and Internet Security', 'C', 'CCCC', 70),
('CN-9425', 'Broadband Communication and Mobile Networking', 'B', 'BAAA', 71),
('CN-9426', ' Advanced Network  Design and Performance Computing(Capstone Project)', 'B', 'BAAA', 72),
('CT-9427', 'Digital Forensics	', 'H', 'HBAA', 73),
('1111', 'blah1', 'A', 'AAAA', 1111),
('2222', 'blah2', 'B', 'BBAA', 2222),
('3333', 'balh3', 'A', 'AAAA', 3333),
('4444', 'blah4', 'B', 'BAAA', 4444),
('5555', 'blah5', 'E', 'EEAA', 5555),
('6666', 'blah6', 'P', 'PPAA', 6666),
('CN-7411', 'Network Operating System', 'C', 'CCCC', 6667),
('CN-7413', 'Multimedia Communication', 'B', 'BBAA', 6668),
('CST-7213', 'Applied Cryptography', 'B', 'BBAA', 6669);

-- --------------------------------------------------------

--
-- Table structure for table `teach`
--

CREATE TABLE `teach` (
  `day_P` varchar(11) NOT NULL,
  `alias` varchar(20) NOT NULL,
  `rm_code` varchar(20) DEFAULT NULL,
  `subject_id` varchar(20) NOT NULL,
  `teacher_id` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `section_id` int NOT NULL,
  `semester_id` int NOT NULL,
  `period_count` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `teach`
--

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `eid` varchar(50) DEFAULT NULL,
  `password` varchar(10) DEFAULT NULL,
  `mob` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacher_id`, `name`, `eid`, `password`, `mob`) VALUES
('CST-1', 'Daw Lay Myat Myat Thein', NULL, NULL, NULL),
('CST-10', 'Daw Khin Mar Wai', NULL, NULL, NULL),
('CST-11', 'Dr. Zin Mar Kyu', NULL, NULL, NULL),
('CST-12', 'Daw Khin Ei Ei Chaw', NULL, NULL, NULL),
('CST-13', 'Dr. Hlaing Htake Khaung Tin', NULL, NULL, NULL),
('CST-14', 'Daw Khin Sandi Bo', NULL, NULL, NULL),
('CST-15', 'Dr. Kyawe Kyawe San', NULL, NULL, NULL),
('CST-16', 'Dr. Than Than Nwe', NULL, NULL, NULL),
('CST-17', 'Dr. Aye Chan Mon', NULL, NULL, NULL),
('CST-18', 'Dr. Tha Pyay Win', NULL, NULL, NULL),
('CST-19', 'Daw Aye Thant Thant Moe', NULL, NULL, NULL),
('CST-2', 'Daw Htet Nay Chi Lyinn', NULL, NULL, NULL),
('CST-20', 'Daw Su Su Naing', NULL, NULL, NULL),
('CST-21', 'Dr. Hnin Thiri Zaw', NULL, NULL, NULL),
('CST-22', 'Daw Ohnmar Myint', NULL, NULL, NULL),
('CST-23', 'Dr. Aung Htein Maw', NULL, NULL, NULL),
('CST-24', 'Daw Akari Myint Soe', NULL, NULL, NULL),
('CST-25', 'Dr. Ei Thin Su', NULL, NULL, NULL),
('CST-26', 'Dr. Thiri Thitsar Khaing', NULL, NULL, NULL),
('CST-28', 'Daw Shwe Sin Myat Than', NULL, NULL, NULL),
('CST-29', 'Dr. Myat Thida Mon', NULL, NULL, NULL),
('CST-3', 'Daw Kay Zin Htun', NULL, NULL, NULL),
('CST-30', 'Dr. Thet Thet Zin', NULL, NULL, NULL),
('CST-31', 'Dr. May Thu Myint', NULL, NULL, NULL),
('CST-32', 'Dr. Mhway Mhway Tar', NULL, NULL, NULL),
('CST-33', 'Daw Htar Htar Aung', NULL, NULL, NULL),
('CST-34', 'Daw Soe Kalayar Naing', NULL, NULL, NULL),
('CST-35', 'Dr. May Thet Htun', NULL, NULL, NULL),
('CST-36', 'Dr. Hay Mar Moh Moh Lwin', NULL, NULL, NULL),
('CST-37', 'Dr. Win Win Thant', NULL, NULL, NULL),
('CST-38', 'Dr. Nwe Nwe Myint Thein', NULL, NULL, NULL),
('CST-39', 'Dr. Myat Pwint Phyu', NULL, NULL, NULL),
('CST-4', 'Daw Jiin San Mann', NULL, NULL, NULL),
('CST-40', 'Dr. Aye Myat Myat Paing', NULL, NULL, NULL),
('CST-41 ', 'Dr. Ei Moh Moh Aung', NULL, NULL, NULL),
('CST-42', 'Dr. Aung Nway Oo', NULL, NULL, NULL),
('CST-43', 'Dr. Thin Thin Wai', NULL, NULL, NULL),
('CST-44', 'Daw Lei Lei Lynn', NULL, NULL, NULL),
('CST-45', 'Daw Thae Nu Aye', NULL, NULL, NULL),
('CST-46', 'Daw Aye Aye Aung', NULL, NULL, NULL),
('CST-47', 'Daw Ni Win Bo', NULL, NULL, NULL),
('CST-48', 'Daw Thin Thin Wai', NULL, NULL, NULL),
('CST-49', 'Dr. Ohnmar Nhway', NULL, NULL, NULL),
('CST-5', 'Daw San San Nwe', NULL, NULL, NULL),
('CST-50', 'Daw Nan Thazin', NULL, NULL, NULL),
('CST-51', 'Dr. Khin Lei Lei Kyaw', NULL, NULL, NULL),
('CST-52', 'Daw Sandar Aung', NULL, NULL, NULL),
('CST-53', 'Dr. Kyi May San', NULL, NULL, NULL),
('CST-54', 'Dr. Zin Mar Soe', NULL, NULL, NULL),
('CST-55', 'Daw Myint Myint Than', NULL, NULL, NULL),
('CST-56', 'U Pyae Phyo Maung', NULL, NULL, NULL),
('CST-57', 'Dr. Tin Oo', NULL, NULL, NULL),
('CST-58', 'Daw Hnin Thidar', NULL, NULL, NULL),
('CST-59', 'Daw Naw Aesatar', NULL, NULL, NULL),
('CST-6', 'Daw Htay Htay Win', NULL, NULL, NULL),
('CST-60', 'Daw Thwe Thwe Oo', NULL, NULL, NULL),
('CST-61', 'Daw Khin Cho Lat', NULL, NULL, NULL),
('CST-62', 'Daw Mon Zar Kyaw', NULL, NULL, NULL),
('CST-63', 'Daw Mi Mi Swe Win', NULL, NULL, NULL),
('CST-64', 'Daw Mi Khin Thidar Htun', NULL, NULL, NULL),
('CST-65', 'Daw Htoo Htoo Aung', NULL, NULL, NULL),
('CST-66', 'Dr. Win Win Myo', NULL, NULL, NULL),
('CST-67', 'Dr. Khin Hnin Hnin Thein', NULL, NULL, NULL),
('CST-68', 'Dr. Khin Myo Myo Min', NULL, NULL, NULL),
('CST-69', 'Dr. Sandar Win', NULL, NULL, NULL),
('CST-7', 'Daw Win PaPa May Phyoe Aung', NULL, NULL, NULL),
('CST-70', 'Daw Mi Mi Ko', NULL, NULL, NULL),
('CST-71', 'Daw Phyu Phyu Aung', NULL, NULL, NULL),
('CST-72', 'Daw Aye Nyein San', NULL, NULL, NULL),
('CST-8', 'Daw Lei Yi Win Lwin', NULL, NULL, NULL),
('CST-9', 'Daw May Thet Swe', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `th_sub`
--

CREATE TABLE `th_sub` (
  `teacher_id` varchar(10) NOT NULL,
  `subject_id` varchar(20) NOT NULL,
  `section_id` int NOT NULL,
  `semester_id` int NOT NULL,
  `th_sub_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `th_sub`
--

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `eid` (`eid`),
  ADD KEY `user_name` (`user_name`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `layout`
--
ALTER TABLE `layout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`section_id`),
  ADD KEY `fk_semster` (`semester_id`);

--
-- Indexes for table `semdep`
--
ALTER TABLE `semdep`
  ADD PRIMARY KEY (`assignment_id`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`stu_id`),
  ADD KEY `semester` (`semester_id`),
  ADD KEY `section` (`section_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teach`
--
ALTER TABLE `teach`
  ADD PRIMARY KEY (`period_count`),
  ADD KEY `fk_sub_code` (`subject_id`),
  ADD KEY `fk_th_code` (`teacher_id`),
  ADD KEY `fk_section_code` (`section_id`),
  ADD KEY `fk_semester_id` (`semester_id`),
  ADD KEY `fk_rm_code` (`rm_code`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`),
  ADD UNIQUE KEY `eid` (`eid`);
ALTER TABLE `teacher` ADD FULLTEXT KEY `name` (`name`);

--
-- Indexes for table `th_sub`
--
ALTER TABLE `th_sub`
  ADD PRIMARY KEY (`th_sub_id`),
  ADD KEY `fk_th_code` (`teacher_id`),
  ADD KEY `fk_sub_code` (`subject_id`),
  ADD KEY `fk_section_code` (`section_id`),
  ADD KEY `fk_semster` (`semester_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `department_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `ID` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `semdep`
--
ALTER TABLE `semdep`
  MODIFY `assignment_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2234;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `stu_id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6670;

--
-- AUTO_INCREMENT for table `teach`
--
ALTER TABLE `teach`
  MODIFY `period_count` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1764;

--
-- AUTO_INCREMENT for table `th_sub`
--
ALTER TABLE `th_sub`
  MODIFY `th_sub_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=249;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
