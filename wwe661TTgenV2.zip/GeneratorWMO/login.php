<div class="container d-flex justify-content-center align-items-center min-vh-100">
        <!----------------------- Login Container -------------------------->
      <div class="typing row border rounded-5 p-3  shadow box-area"  style="background-color: inherit; ">
        
                  <!--------------------------- Left Box ----------------------------->
              <div class="col-md-4  d-flex justify-content-center align-items-center flex-column admin-left-box border-end border-3" >
                  <div class="featured-image mb-3">
                    <img src="homeimg/admin.png" class="img-fluid" style="width: 250px;">
                  </div>
                  <!-- <div class="typing">
                    <h3 class=" fs-2 text-center mb-4" ><b> ညှိယူ</b></h3>
                  <h5 class=" text-wrap text-center" style="width: 17rem;"><b>Timetable generator</b></h5>
                  </div> -->
                  
              </div> 
            <!-------------------- ------ Right Box ---------------------------->
              <div class="col-md-8 p-5 right-box ">
                  <div class="row align-items-center">
                        <div class="header-text mb-4">
                            <p><?php $err=$_REQUEST['err'];echo $err; ?></p>
                            <h2 class="welcome" style="text-align: center;">Welcome</h2>
                            <p style="text-align: center;">Please Log into Dashboard</p>
                        </div>
                        <form action="validate.php" method="POST">
                          <div class="input-group mb-3">
                              <input type="text" name="UN" class="form-control form-control-lg bg-light fs-6" placeholder="Username" required id="adminname">
                          </div>
                          <div class="input-group mb-1">
                              <input type="password" name="PASS" class="form-control form-control-lg bg-light fs-6" placeholder="Password" required id="password">
                          </div>
                          <div class="mb-5 d-flex justify-content-between">
                              <div class="form-check">
                              </div>
                              <div class="forgot">
                                  <small><a href="index.php?info=login&err=Please Contact the Adminstrator: wildking4421@gmail.com "  class="forgot-pswd" style="text-decoration: underline;color:white;">Forgot Password?</a></small>
                              </div>
                          </div>
                          <div class="input-group mb-3" id="btngroup">
                          <input type="hidden" name="db_name"value="USER">
                              <input class="btn btn-lg fs-6 login-btn" name="login" type="submit" value="Login">
                                <a href="index.php?info=reg" class="btn btn-lg fs-6 login-btn text-center">Register</a>
                              <!-- <button class="btn btn-lg btn-primary w-100 fs-6">Login</button> -->
                          </div>
                        </form>
                        
                  </div>
                </div> 
              </div>
        
        
    </div>