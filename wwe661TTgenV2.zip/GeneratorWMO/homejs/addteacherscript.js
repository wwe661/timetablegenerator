var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    var addteacherBtn = document.getElementById("teachermanual");
    var heading = document.getElementById("popupHead");
    var facultyForm = document.getElementById("addTeacherForm");
    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks the button, open the modal

    addteacherBtn.onclick = function () {
        modal.style.display = "block";
        //heading.innerHTML = "Faculty Login";
        facultyForm.style.display = "block";
        //adminForm.style.display = "none";


    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
        //adminForm.style.display = "none";
        facultyForm.style.display = "none";

    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // Define a function to handle the click event of the delete button
    function deleteRow(row) {
        var confirmation = confirm("Are you sure you want to delete this row?");
    if (confirmation) {
        var id = row.cells[0].innerText; // Get the teacher ID from the first cell of the row
        row.parentNode.removeChild(row); // Remove the row from the table

        // Make an AJAX request to the PHP script to delete the record from the database
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "deleteteacher.php?id=" + id, true);
        xhr.send();
    }
    }

   // Function to open edit modal with existing data
   function openEditModal(row) {
        var cells = row.getElementsByTagName("td");
        document.getElementById("editTeacherID").value = cells[0].innerText; // Assuming ID is in the first column
        document.getElementById("editTeacherName").value = cells[1].innerText; // Assuming name is in the second column
        document.getElementById("editTeacherPassword").value = cells[2].innerText; 
        document.getElementById("editDesignation").value = cells[3].innerText;
        document.getElementById("editDprt").value = cells[4].innerText; 
        document.getElementById("editTeacherContactnumber").value = cells[5].innerText; 
        document.getElementById("editTeacherEmailID").value = cells[6].innerText;  
        // Add similar lines for other input fields if needed
        
        // Show the edit modal
        var modalEdit = document.getElementById('myModalEdit');
        modalEdit.style.display = "block";
    }

    // Get the close button for the edit modal
    var spanEdit = document.getElementsByClassName("close")[1]; // Assuming the close button index is 1

    // Close the edit modal when the user clicks on <span> (x)
    spanEdit.onclick = function() {
        var modalEdit = document.getElementById('myModalEdit');
        modalEdit.style.display = "none";
    }

    // Close the edit modal when the user clicks anywhere outside of it
    window.onclick = function(event) {
        var modalEdit = document.getElementById('myModalEdit');
        if (event.target == modalEdit) {
            modalEdit.style.display = "none";
        }
    }