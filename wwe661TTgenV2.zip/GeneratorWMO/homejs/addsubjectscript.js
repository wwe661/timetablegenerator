var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    var addsubjectBtn = document.getElementById("subjectmanual");
    var heading = document.getElementById("popupHead");
    var subjectForm = document.getElementById("addSubjectForm");
    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks the button, open the modal

    addsubjectBtn.onclick = function () {
        modal.style.display = "block";
        subjectForm.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
        subjectForm.style.display = "none";

    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    // Define a function to handle the click event of the delete button
    function deleteRow(row) {
        var confirmation = confirm("Are you sure you want to delete this row?");
    if (confirmation) {
        var id = row.cells[0].innerText; // Get the teacher ID from the first cell of the row
        row.parentNode.removeChild(row); // Remove the row from the table

        // Make an AJAX request to the PHP script to delete the record from the database
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "deletesubject.php?id=" + id, true);
        xhr.send();
    }
    }

    // Function to open edit modal with existing data
    function openEditModal(row) {
        // Extract data from the table row
        var cells = row.getElementsByTagName("td");
        var subjectCode = cells[0].innerText;
        var subjectName = cells[1].innerText;
        var courseType = cells[2].innerText;
        var semester = cells[3].innerText;
        var department = cells[4].innerText;
    
        // Populate the modal fields with the extracted data
        document.getElementById("editsubjectcode").value = subjectCode;
        document.getElementById("editsubjectname").value = subjectName;
        document.getElementById("editsubjecttype").value = courseType;
        document.getElementById("editsubjectsemester").value = semester;
        document.getElementById("editsubjectdepartment").value = department;
    
        // Display the modal
        var modal = document.getElementById("myModalEdit");
        modal.style.display = "block";
    }
    

    // Get the close button for the edit modal
    var spanEdit = document.getElementsByClassName("close")[1]; // Assuming the close button index is 1

    // Close the edit modal when the user clicks on <span> (x)
    spanEdit.onclick = function() {
        var modalEdit = document.getElementById('myModalEdit');
        modalEdit.style.display = "none";
    }

    // Close the edit modal when the user clicks anywhere outside of it
    window.onclick = function(event) {
        var modalEdit = document.getElementById('myModalEdit');
        if (event.target == modalEdit) {
            modalEdit.style.display = "none";
        }
    }