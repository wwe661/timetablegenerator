document.getElementById('button1').addEventListener('click', function() {
    // Get the selected role
    var selectedRole = document.querySelector('input[name="option"]:checked');
    
    // Check if a role is selected
    if (selectedRole) {
        // Redirect based on the selected role
        if (selectedRole.id === 'admin') {
            window.location.href = 'adminLogin.php';
        } else if (selectedRole.id === 'teacher') {
            window.location.href = 'staffLogin.php';
        } else if (selectedRole.id === 'student') {
            window.location.href = 'studentlogin.php';
        }
    } else {
        alert('Please select a role before clicking Next.');
    }
});