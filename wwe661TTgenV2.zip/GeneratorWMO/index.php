<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Timetable generator - home page</title>

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;1,500&display=swap" rel="stylesheet" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="homecss/aos.css" rel="stylesheet">
  <link href="homecss/bootstrap.min.css" rel="stylesheet">
  <link href="homecss/bootstrap-icons.css" rel="stylesheet">
  <link href="homecss/glightbox.min.css" rel="stylesheet">
  <link href="homecss/remixicon.css" rel="stylesheet">
  <link href="homecss/swiper-bundle.min.css" rel="stylesheet">
  <link rel="stylesheet" href="homecss/owl.carousel.min.css">
  <link href="homecss/boxicons.min.css" rel="stylesheet">

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
  <!-- <link rel="stylesheet" href="https://unpkg.com/boxicons@latest/css/boxicons.min.css"> -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" />
  <!-- Template Main CSS File -->
  <link rel="stylesheet" href="homecss/loginStyle.css">
  <link href="homecss/style.css" rel="stylesheet">
</head>

<body>
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center justify-content-between">    
      <div class="logo">
        <a href="#"><img src="homeimg/logo transparent.png"></a>
      </div>
    
      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <!-- <li><a class="nav-link scrollto" href="#our-testimonial">Teammates</a></li> -->
          <li><a class="nav-link scrollto" href="#contact">Contact us</a></li>
          <li><a class="getstarted scrollto" href="index.php?info=login">Get Started</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
     </div>
   </div>
  </header>

  <?php
  $info = $_REQUEST['info'];
  if($info!=""){
  if($info=="login") include("login.php");
  elseif($info== "reg") include("reg.php");
  else  include('intro.php');
  }else include("intro.php");
  ?>

  <!-- Vendor JS Files -->
  <script src="homejs/purecounter_vanilla.js"></script>
  <script src="homejs/aos.js"></script>
  <script src="homejs/bootstrap.bundle.min.js"></script>
  <script src="homejs/glightbox.min.js"></script>
  <script src="homejs/isotope.pkgd.min.js"></script>
  <script src="homejs/swiper-bundle.min.js"></script>
  <script src="homejs/bootstrap.min.js"></script> 
  <script src="homejs/jquery-3.6.0.min.js"></script> 
  <!--Owl Slider--> 
  <script src="homejs/owl.carousel.min.js"></script> 

  <!-- Template Main JS File -->
  <script src="homejs/main.js"></script>

</body>
</html>