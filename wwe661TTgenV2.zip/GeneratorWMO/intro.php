<!-- Hero Section -->
<section id="hero" class="d-flex align-items-center">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 pt-5 pt-lg-0 order-2 order-lg-1 d-flex flex-column justify-content-center">
          <h1 data-aos="fade-up">Manage your work with us</h1>
          <h2 data-aos="fade-up" data-aos-delay="400">Effortlessly Navigate Your Work with Our Scheduling Wizardry!</h2>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="fade-left" data-aos-delay="200">
          <img src="homeimg/logo transparent.png" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>
  </section>

  <main id="main">
    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">
        <div class="section-title" data-aos="fade-up">
          <h2>About</h2>
          <p>Our Automatic Timetable Generator (ATG) for a university is a software tool designed to streamline and automate the process of creating and managing schedules for various academic activities within a university setting.
            Our Website offers several advantages.
          </p>
        </div>

        <div class="row">
          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="100">
              <div class="icon"><i class='bx bx-timer'></i></i></div>
              <b><h4 class="title">Time Efficiency </h4></b>
              <p class="description">Ours can quickly create schedules, saving a significant amount of time compared to manual scheduling processes.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="200">
              <div class="icon"><i class='bx bxs-chevrons-up'></i></div>
              <b><h4 class="title">Enhanced Productivity</h4></b>
              <p class="description">With an optimized and well-organized schedule, there is a potential increase in overall productivity, as everyone involved can focus on their tasks without disruptions or conflicts.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="300">
              <div class="icon"><i class='bx bx-badge-check'></i></div>
              <b><h4 class="title">Conflict Resolution</h4></b>
              <p class="description">resolve conflicts, such as overlapping schedules or resource constraints, ensuring a smooth and conflict-free timetable</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0">
            <div class="icon-box" data-aos="fade-up" data-aos-delay="400">
              <div class="icon"><i class='bx bx-group'></i></div>
              <h4 class="title">Reduced Human Error</h4>
              <p class="description">Automation minimizes the risk of human errors associated with manual timetable creation, leading to more accurate and reliable schedules.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>

    <footer id="footer">
      <section id="contact" class="contact">
        <div class="container">
          <div class="section-title" data-aos="fade-up">
            <h3>Contact Us</h3>
          </div>
          <div class="row">
            <div class = "col-md-2"></div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
              <div class="contact-about">
                <h3>ATG</h3>
                <p>Please feel free to contact us.</p>
                <div class="social-links">
                  <a href="#" class="twitter"><i class='bx bxl-twitter'></i></a>
                  <a href="#" class="facebook"><i class='bx bxl-facebook-square' ></i></a>
                  <a href="#" class="instagram"><i class='bx bxl-instagram' ></i></a>
                  <a href="#" class="linkedin"><i class='bx bxl-linkedin' ></i></a>
                </div>
              </div>
            </div>
            <div class = "col-md-2"></div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
              <div class="info">
                <div>
                  <i class='bx bxs-map'></i>
                  UIT V44P+84R, ပါရမီလမ်း, Yangon
                </div>
  
                <div>
                  <i class='bx bx-mail-send' ></i>
                  atg@gmail.com
                </div>
  
                <div>
                  <i class='bx bxs-phone'></i>
                  +95954022222
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </footer>