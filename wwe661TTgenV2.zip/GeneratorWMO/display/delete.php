<?php
include('../Database/config.php');
if (isset($_REQUEST['table'])) {
    $id = $_REQUEST['id'];
    $table = $_REQUEST['table'];
    if(empty($table)){
        $connection =connect("localhost","USER","wild","Waing@4421661");
        $stmt = $connection->prepare("SELECT count(*) as Pgcount FROM Programs");
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row && $row['Pgcount'] > 2) {
        $stmt=$connection->prepare("SELECT * FROM Programs WHERE id = ?");
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        if ($row) {
            $databaseToRemove = $row["name"];
        }

        $deleteresult = $connection->prepare("Delete from Programs where id = ?");
        $deleteresult->execute([$id]);
        $connection = new PDO('mysql:host=localhost', 'wild', 'Waing@4421661');
        try {
            // Use the DROP DATABASE SQL command
            $sql = "DROP DATABASE $databaseToRemove";
            $connection->exec($sql);
            echo "Database '$databaseToRemove' deleted successfully.";
        } catch (PDOException $e) {
            echo "Error deleting database: " . $e->getMessage();
        }
        $_SESSION['db_name']='';
    }
    }else{
    // Correct the concatenation
    $id_name = $table . "_id";
    
    // Properly build the query with spaces
    $query = "DELETE FROM " . $table . " WHERE " . $id_name . " = '" . $id."'";
    $result = mysqli_query($con, $query);

    if ($result) {
        echo "Deletion successful";
    } else {
        echo "Deletion failed: " . mysqli_error($con);
    }}

    // Use '.' for concatenation in the URL too
    header('Location: admindashboard.php?info=' . $table);
}
