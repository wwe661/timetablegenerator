
<div id="tsting">
<form action=""method ="post"id="search_bar">
    <div id="search">
    Search  &nbsp;
    <div id="room">
        <select name="rm_code" id="">
            <option value=""selected disabled>By Room</option>
            <?php 
                // Fetch teachers from the database
        $room_query = mysqli_query($con, "SELECT * FROM room order by rm_code ASC");

        if(mysqli_num_rows($room_query) > 0) {
            while ($room = mysqli_fetch_assoc($room_query)) {
                echo '<option value="' . $room['rm_code'] . '">' . $room['rm_code'] . '</option>';
            }
        } else {
            echo '<option disabled>No rooms found</option>'; 
        }
            ?>
        </select>
    </div>
    <div id="period">
    <?php 
        $days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
        $periods = ["8:30am - 9:30am","9:40am - 10:40am","10:50am - 11:50am","12:40pm - 1:40pm","1:50pm - 2:50pm","3:00pm - 4:00pm"];
        echo"<select name='i' id=''>
        <option value=''disabled selected>By Date</option>";
    foreach ($days as $k=>$day) {
        echo"<option value='$k'>$day</option>";
    }echo"</select>";
    echo "<select name='j' id=''>
    <option value=''disabled selected>And Period</option>";
    foreach ($periods as $k=>$period) {
    echo "<option value='$k'>$period</option>";
    }echo"</select>";
    ?>
    </div>
    <div id="teach">
    <select name="teacher" id="teacher" class="form-control">
        <option disabled selected>By Teacher</option>
        <?php
        // Fetch teachers from the database
        $teachers_query = mysqli_query($con, "SELECT * FROM teacher order by name DESC");

        // Check if any teachers are fetched
        if(mysqli_num_rows($teachers_query) > 0) {
            // Loop through each teacher and create an option tag
            while ($teacher = mysqli_fetch_assoc($teachers_query)) {
                echo '<option value="' . $teacher['teacher_id'] . '">' . $teacher['name'] . '</option>';
            }
        } else {
            echo '<option disabled>No teachers found</option>'; // Show a message if no teachers are found
        }
        ?>
    </select>
    </div>&nbsp;
    <button id="swap"onclick="swapdiv(event)"><i class="fa fa-exchange-alt"></i>
    <span id="message">Swap between <i><B>Room , Period , Teacher</B></i> </span>
    </button>
    
        <input type="submit" name ="submit"value="Submit">
        <input type="reset" value="Reset">
    </div>
    <div id="actions">
        <input type="submit"name="available" value="Check available rooms">
    </div>
</form>
<div id="results">
<?php
include '../TTgeneration/view.php'; 

    if($_SERVER["REQUEST_METHOD"] == "POST") {
        if(isset($_POST["submit"])) {
            $rm_code = isset($_POST["rm_code"]) ? $_POST["rm_code"] :null;
            $th_code = isset($_POST["teacher"]) ? $_POST["teacher"] :null;
            $i = isset($_POST["i"]) ? $_POST["i"] :null;
            $j = isset($_POST["j"]) ? $_POST["j"] :null;
            if(!empty($_POST["rm_code"])) {
                echo"Room $rm_code<br>";
                tablefromteach($rm_code,$conn,"rm_code");
                // $sql = "select * from teach where rm_code=?";
                // $stmt=$conn->prepare($sql);
                // $stmt->execute([$rm_code]);
                // $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                // if(empty($result))  echo" The room does not exist in the records";
                // else {
                // echo'<table> <tr> <th>Room</th><th>Period</th><th>Section</th><th>Teacher</th><th>Subject</th><th>Type</th></tr>';
                // foreach($result as $row) {
                //     echo '<tr><td>'.$row['rm_code'].'</td><td>'.$row['day_P'].'</td><td>'. 
                //     $row['section_id'].'</td><td>'. $row['teacher_id'].'</td><td>'. $row['subject_id'].'</td><td>'. $row['alias'].'</td></tr>';
                // }}
            }
            if(!empty($_POST["teacher"])) {
                echo "<p>$tch</p>";
                tablefromteach($th_code,$conn,"teacher_id");
                // echo "Teacher ID : $th_code<br>";
                // $sql = "select * from teach where teacher_id=? order by day_P asc";
                // $stmt=$conn->prepare($sql);
                // $stmt->execute([$th_code]);
                // $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                // if(empty($result))  echo" The teacher does not include in the records";
                // else {
                // echo'<table> <tr> <th>Teacher</th><th>Period</th><th>Section</th><th>Room</th><th>Subject</th><th>Type</th></tr>';
                // foreach($result as $row) {
                //     echo '<tr><td>'.$row['teacher_id'].'</td><td>'.$row['day_P'].'</td><td>'. 
                //     $row['section_id'].'</td><td>'. $row['rm_code'].'</td><td>'. $row['subject_id'].'</td><td>'. $row['alias'].'</td></tr>';
                // }}
            }
            if(isset($_POST["i"])) {
                $day_P = "$i$j";
                $perStr = $days[$i]." ".$periods[$j];
                echo "The Period : $perStr<br>";
                tablefromteach($day_P,$conn,"day_P");
                // $sql = "select * from teach where day_P=? order by rm_code asc";
                // $stmt=$conn->prepare($sql);
                // $stmt->execute([$day_P]);
                // $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                // if(empty($result))  echo" There is no such period";
                // else {
                // echo'<table> <tr> <th>Teacher</th><th>Period</th><th>Section</th><th>Room</th><th>Subject</th><th>Type</th></tr>';
                // foreach($result as $row) {
                //     echo '<tr><td>'.$row['teacher_id'].'</td><td>'.$row['day_P'].'</td><td>'. 
                //     $row['section_id'].'</td><td>'. $row['rm_code'].'</td><td>'. $row['subject_id'].'</td><td>'. $row['alias'].'</td></tr>';
                // }}
            }
        }
        if(isset($_POST["available"])) {
            $available =[];$allrms=[];$temp =[];
            $sql = "Select * from room";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach($result as $row) {
                $allrms[] = $row["rm_code"];
            }
            $sql = "select * from teach order by day_P asc";
            $stmt=$conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if(empty($result)) echo "THE RECORDS ARE EMPTY";
            foreach($result as $row) {
                $temp[$row["day_P"]][] = $row["rm_code"];
            }
            foreach($temp as $key=>$row) {
                $available = array_diff($allrms,$row);
                // var_dump($available);
                if(count($available)>0){
                $keystr = strval($key);
                $perStr = $days[$keystr[0]];
                $perStr .= "<br/>";
                $perStr .=$periods[$keystr[1]];
                $once = true;
                echo"<table><tr><th>Period</th><th>left rooms</th></tr>";
                foreach($available as $key2=>$row2) {
                echo"<tr>";
                if($once){echo" <td rowspan='".count($available)."'>$perStr </td>";$once = false;}
                echo"<td>$row2</td>";
                }
                }else{
                    echo "all rooms are used for period $key";
                }
            }
            echo"<style> 
            #results{flex-direction:row !important;}
            </style>";
        }        
    }
?></div>
</div>
<style>
    #tsting{
        width: 100%;
        position: relative;
    }
    #search_bar{
        height: fit-content;
        border-bottom: 2px solid white;
        border-radius: 10px;
        width: 100%;
        display: flex;
        justify-content: space-around;
        position: sticky;
        top: 0;
        background: var(--bgcolor);
    }
    #search{
        display: flex;
        align-items: center;
        width:80%;
    }
    .addBtn{
        display: none;
    }
    #period,#teach{
        display: none;
    }
    #swap{
        background: var(--bgcolor);
        height: fit-content;
        padding: 1px 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
        position: relative;
    }
    #results{
        overflow-x:scroll;  
        display: flex;
        flex-direction: column;
    }
    table{
        height:fit-content;
    }
    #message{
        display:none;
        position: absolute;
        top: 35px;
        border: 2px solid white;
        border-radius: 10px;
        margin: 5px;
        padding: 5px;
        background: var(--bgcolor);
    }
    #swap:hover #message{
        display:block;
    }
    nav{
        display: none;
    }
    .subject{
        color:green;
    }
    .semsec{
        color:teal;
    }
    .room{
        color:lightslategray;
    }
    .tch{
        color:goldenrod;
    }
</style>
<script type="text/javascript">
    // Define a counter to keep track of the current visible div
    let currentDivIndex = 1;

    // Function to handle div swapping
    function swapdiv(event) {
        event.preventDefault();
        // Array of div IDs to toggle
        const divIds = ["room", "teach", "period"];
        
        // Hide all divs initially
        divIds.forEach((id) => {
            document.getElementById(id).style.display = "none";
        });
        
        // Show the current div based on the index
        console.log(document.getElementById(divIds[currentDivIndex]));
        document.getElementById(divIds[currentDivIndex]).style.display = "block";
        
        // Increment the index, and reset to 0 if it goes beyond the array length
        currentDivIndex = (currentDivIndex + 1) % divIds.length;
    }
    // swapBtn =document.getElementById('swap');
    // swapBtn.addEventListener("mouseover", function() {
    // const span = document.getElementById("message");
    // span.style.display = "block";
    // setTimeout(function() {
    //     span.style.display = "none";
    // }, 1000);
    // });

</script>
