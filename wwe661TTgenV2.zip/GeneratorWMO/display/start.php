<?php 
session_start();
include('../Database/config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Time table Start</title>

    <link rel="stylesheet" href="common.css">
	<link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link href="..\fontawesome-free-6.6.0-web\css\all.min.css" rel="stylesheet" type="text/css">
    
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <script src = "common.js"></script>
</head>

<body>

    <div id="wrapper">

		<div class="header">
            	<div> 
				<!-- <img src="" alt="" width=50 height=50/> -->
				<a href="start.php"><i class="fa fa-graduation-cap"></i><span>Hello 
                    <?php echo $_SESSION['user']; ?>
                </span></a>
				</div>
                <a href = '../logout.php'><i class="fa fa-sign-out-alt"></i>EXIT</a>
                <p class='msg'>Please Select a Program to Start</p>

                <?php 
                if($db_name != 'USER'&&isset($_SESSION['db_name']) && !empty($_SESSION['db_name'])) {
                    // If no database is selected, redirect to the selection page, not config.php
                    $db_name = $_SESSION['db_name'];
                    echo"<a href='admindashboard.php?info=teacher&db_name=$db_name'>Continue Using $db_name</a>";
                    
                    // header("Location: start.php");
                }
                ?>
        </div>
        <div id="page_wrapper">
            <?php 
				include 'selection.php';
            ?>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
</body>
</html>
