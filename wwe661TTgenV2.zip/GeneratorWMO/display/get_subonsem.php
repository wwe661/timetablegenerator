<?php
// Include your config file and establish database connection
include('../Database/config.php');

// Check if semester_id is set in the request
if(isset($_GET['semester_id'])) {
    $temp =[];
    $semester_id = $_GET['semester_id'];

    $sql = "SELECT * FROM semester WHERE semester_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$semester_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    var_dump($result);
    if($result) {
        $temp[] = $result["subject1"];
        $temp[] = $result["subject2"];
        $temp[] = $result["subject3"];
        $temp[] = $result["subject4"];
        $temp[] = $result["subject5"];
        $temp[] = $result["subject6"];
    }
    $options = '<option disabled selected>Select Section</option>';
    $sql = "SELECT subject_name FROM subject where subject_id = ?";
    $stmt = $conn->prepare($sql);
    foreach($temp as $row) {
        echo $row;
        $stmt->execute([$row]);
        $result = $stmt->fetchColumn();
        $options .= '<option value="' . $row . '">' . $result . '</option>';
    }
    echo $options;
} else {
    // Semester ID not provided in the request
    echo '<option disabled>Error: Semester ID not provided</option>';
}
