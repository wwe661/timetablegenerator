<?php
// Include your config file and establish database connection
include('../Database/config.php');

// Check if the teacher ID is set and not empty
if (isset($_GET['id']) && !empty($_GET['id'])) {
    // Sanitize the input to prevent SQL injection
    $teacher_id = mysqli_real_escape_string($con, $_GET['id']);

    // Query to fetch the teacher's name based on the ID
    $query = "SELECT _name FROM teacher WHERE teacher_id = '$teacher_id'";
    $result = mysqli_query($con, $query);

    // Check if the query was successful
    if ($result) {
        // Check if any rows were returned
        if (mysqli_num_rows($result) > 0) {
            // Fetch the teacher's name
            $row = mysqli_fetch_assoc($result);
            $teacher_name = $row['_name'];

            // Output the teacher's name
            echo $teacher_name;
        } else {
            // If no rows were returned, output an error message
            echo "Teacher not found";
        }
    } else {
        // If the query failed, output an error message
        echo "Error: " . mysqli_error($con);
    }
} else {
    // If the teacher ID is not set or empty, output an error message
    echo "Invalid teacher ID";
}
