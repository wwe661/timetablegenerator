<table id='semTable'>
    <tr id ="table-head">
        <th>Semester Name</th>
        <th>Sections
        <a href='admindashboard.php?info=section' class='btn updateBtn'><i class="fas fa-pencil-alt"></i></a>
        </th>
        <th>Subject Code
        <a href='admindashboard.php?info=subject' class='btn updateBtn'><i class="fas fa-pencil-alt"></i></a>
        </th>
        <th>Subject name</th>
    </tr>

<?php
    $q = mysqli_query($con,"SELECT * FROM semester ORDER BY semester_name ASC");
    while ($row = mysqli_fetch_assoc($q)) {
        $semid =$row['semester_id'];
    $s = mysqli_query($con,"select * from section where semester_id=$semid");
    $subs =[];$temp =[];
    for ($i = 1; $i <= 6; $i++) {
        $subjectId = $row["subject$i"];
        if (!empty($subjectId)) {
            $subs[] = $subjectId;
        }
    }
    foreach($subs as $v){
    $sn = mysqli_query($con, "select * from subject where subject_id = '$v'");
    $sn = mysqli_fetch_assoc($sn);
    $temp[$v]=$sn['subject_name'];
    }
    // $c = mysqli_num_rows($s);
    //  rowspan=$c
        echo "<tr><td rowspan=" . count($temp) . ">
        <div id='actions'>
        <a href='javascript:deleteData(\"{$row['semester_id']}\")' class='btn delBtn'><i class='fas fa-trash'></i> </a>
        <a href='admindashboard.php?info=updatesemester&semester_id={$row['semester_id']}' class='btn updateBtn'><i class='fas fa-edit'></i></a>
        </div>
        {$row['semester_name']}</td><td id = 'section'rowspan =" . count($temp) . ">";
        while($sec = mysqli_fetch_assoc($s)) {
            echo "<p>".$sec["section_name"]." (".$sec["section_capacity"].")</p>";
        }
        echo"</td>";
        $first = true;
        foreach ($temp as $k => $v) {
            if (!$first) echo "<tr>";
            echo "<td>" . $k . "</td><td>" . $v . "</td></tr>";
            $first = false;
        }
    }
?>
</table>
<input type="hidden" value ="semester"id ="pgname">
<style>
    td{
        position:relative;
    }
    #actions{
        position: absolute;
        top:20px;
    }
</style>