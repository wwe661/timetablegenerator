<?php
// Database connection
include '../Database/config.php';

if (isset($_POST['semester_id'])) {
    $semester_id = $_POST['semester_id'];
    $reply = [];
    // $semester_id = 1;
    // Query to get the student count
    $query = "SELECT * FROM section WHERE semester_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->execute([$semester_id]);
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($result as $row) {
        $reply[] = $row["section_capacity"];
    }
    echo json_encode($reply);
}