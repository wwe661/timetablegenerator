<?php 
include("../Database/config.php");
$temp =[];
    $semester_id = 1;

    $sql = "SELECT * FROM semester WHERE semester_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$semester_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    var_dump($result);
    if($result) {
        $temp[] = $result["subject1"];
        $temp[] = $result["subject2"];
        $temp[] = $result["subject3"];
        $temp[] = $result["subject4"];
        $temp[] = $result["subject5"];
        $temp[] = $result["subject6"];
    }
    var_dump($temp);
    $sql = "SELECT subject_name FROM subject where subject_id = ?";
    $stmt = $conn->prepare($sql);
    foreach($temp as $row) {
        echo $row;
        $stmt->execute([$row]);
        $result = $stmt->fetchColumn();
        $a[$row]= $result;
    }
    var_dump($a);