<table id='SectionTable'>
    <tr id="table-head">
        <th>Semester</th>
        <th>Section</th>
        <th>Students Count</th>
        <th colspan="2">Action</th>
    </tr>
    <?php
    $semname = [];
    $s = mysqli_query($con, "SELECT * FROM semester");
    while ($semester = mysqli_fetch_assoc($s)) {
        $semname[$semester["semester_id"]] = $semester["semester_name"];
    }

    $q = mysqli_query($con, "SELECT * FROM section ORDER BY semester_id, section_name");

    $currentSemester = null; // To track the current semester for grouping
    $rowCount = [];           // To count the rows for each semester
    $rows = [];              // To store rows for output

    // Loop through the result set to calculate rowspan and store rows
    while ($row = mysqli_fetch_assoc($q)) {
        $rows[] = $row;

        if ($row['semester_id'] !== $currentSemester) {
            $currentSemester = $row['semester_id'];
            $rowCount[$currentSemester] = 1; // Start counting for this semester
        } else {
            $rowCount[$currentSemester]++; // Increment count for the current semester
        }
    }

    // Output the table rows with grouped semesters
    $currentSemester = null;
    foreach ($rows as $row) {
        echo "<tr>";
        if ($row['semester_id'] !== $currentSemester) {
            $currentSemester = $row['semester_id'];
            echo "<td rowspan='{$rowCount[$currentSemester]}'>{$semname[$currentSemester]}</td>";
        }
        echo "<td>{$row['section_name']}</td>";
        echo "<td>{$row['section_capacity']}</td>";
        echo "<td><a href='javascript:deleteData(\"{$row['section_id']}\")' class='btn delBtn'>Delete</a></td>
            <td>
            <a class='updateBtn' role='button' href='admindashboard.php?info=update_section&section_id={$row['section_id']}'>Update</a>
            </td>";
        echo "</tr>";
    }
    ?>
</table>
<input type="hidden" value="section" id="pgname">
