<style>
    #page_wrapper{
        flex-direction: column;
        justify-content: flex-start;
    }
    .msg i{
        border-radius: 5px;
        border:2px solid white;
        padding:5px;
        font-size: large;
    }
    .fa-arrow-right{
        border:none !important;
    }
    #dbtab{
        overflow: auto;
        height: 180px;
        border: 2px solid white;
        padding: 3px;
        display: flex;
        justify-content: center;
        margin: 5px;
        position: relative;
    }
    #dbtab table{
        border:none;
    }
    #dbtab table thead{
        position: sticky;
        top:0;
        background: var(--bgcolor);
    }
</style>
<form id="programForm" method="POST" action="">
    <table>
        <tr>
            <td>
                Choose an existing program  
            </td>
            <td><input type="radio" name="programChoice" value="existing" checked></td>
            <td>
                <!-- <div id="sele">
                <select name="existingProgram">
                    <?php 
                    $temp =[];
                    $connection =connect("localhost","USER","wild","Waing@4421661");
                    $query = "Select * from Programs";
                    $stmt = $connection->prepare($query);
                    $stmt->execute();
                    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    // echo"<option selected disabled>Choose Program</option>";
                    foreach ($result as $row) {
                    // echo "<option value='".$row['name']."'>".$row['name']."</option>";
                    $temp[] = $row["name"];
                    }
                    ?>
                </select>
                </div> -->
                <div id="dbtab">
                    <table>
                        <thead>
                            <tr>
                                <th>Program Name</th>
                                <th>Action</th>  
                            </tr>
                        </thead>
                        
                        <?php 
                        $connection =connect("localhost","USER","wild","Waing@4421661");
                        $query = "Select * from Programs";
                        $stmt = $connection->prepare($query);
                        $stmt->execute();
                        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            // <td class='editable'data-id='".$row['id']."'>".$row['name']."</td>
                        foreach($result as $row){
                        echo "
                        <tr>
                            <td><input type='submit'value='".$row["name"]."'name='existingProgram'>
                            <td><button class='delBtn' onclick=deleteData({$row['id']},event)>Delete</button></td>
                        </tr>";
                        }
                        // <td><button class='updateBtn edit-btn'>Update</button></td>
                        ?>
                    </table>
                </div>
            </td>
        </tr>
        <tr>
            <td>
                Create a new program
            </td>
            <td><input type="radio" name="programChoice" value="new"></td>
            <td>
                <input type="text" name="newProgramName" placeholder="Enter new program name" disabled>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection details
    $host = 'localhost';
    $rootUser = 'wild';
    $rootPass = 'Waing@4421661';

    // Get the form inputs
    $programChoice = $_POST['programChoice'];
    $newProgramName = isset($_POST['newProgramName']) ? $_POST['newProgramName'] : null;
    $existingProgram = isset($_POST['existingProgram']) ? $_POST['existingProgram'] : null;

    // Choose database based on user selection
    $databaseToUse = '';

    if ($programChoice == 'new' && !empty($newProgramName)) {
        if(in_array($newProgramName, $temp)) {
            $databaseToUse = $newProgramName;
            echo"<p class='msg'>";
            echo "Using '$newProgramName'.";
            echo "<a href='admindashboard.php?db_name=$databaseToUse&info=teacher'>Continue</a>";
            echo"</p>";
        }else{
        // Create a new database with the user-provided name
        try {
            $conn = new PDO("mysql:host=$host", $rootUser, $rootPass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // Create the new database
            $sql = "CREATE DATABASE " . $newProgramName;
            $conn->exec($sql);

            // Use the new database
            $databaseToUse = $newProgramName;
            $save = $connection->prepare("INSERT INTO `Programs` (`id`, `name`) VALUES (NULL, ?);");
            $save->execute([$databaseToUse]);
            // Import the shell.sql file
            $sqlFile = file_get_contents('../Database/shell.sql');
            $conn->exec("USE $databaseToUse; " . $sqlFile);
            echo"<p class='msg'>";
            echo "Database '$newProgramName' created successfully!";
            echo "<a href='admindashboard.php?db_name=$databaseToUse&info=teacher'>Continue</a>";
            echo"</p>";
        } catch (PDOException $e) {
            echo $e->getMessage();
            echo"<p class='msg'>";
            echo "<a href='admindashboard.php?db_name=$databaseToUse&info=teacher'>Continue</a>";
            echo"</p>";
        }}
    }
     elseif ($programChoice == 'existing' && !empty($existingProgram)) {
        // Use the selected existing program
        $databaseToUse = $existingProgram;
        echo"<p class='msg'>";
        echo "Using'$existingProgram'.";
        echo "<a href='admindashboard.php?db_name=$databaseToUse&info=teacher'>Continue</a>";
        echo"</p>";
    } 
    else {
        echo"<p class='msg'>";
        echo "No valid choice made.";
        // echo"<style>
        // #toggleme{
        // display:none;}
        // </style>";
        echo"</p>";
    }

    // Connect to the chosen database and proceed with further operations
    // Example: $conn = new PDO("mysql:host=$host;dbname=$databaseToUse", $rootUser, $rootPass);
}
?>
            </td>
            <td><input type="submit"name="chProgram"value="Submit">
            
            </td>
        </tr>
    </table>
        
    </label>
    
</form>
<input type="hidden" value =""id="pgname"name="pgname">
<script>
    // Enable/Disable new program name input based on radio selection
    document.querySelectorAll('input[name="programChoice"]').forEach((radio) => {
        radio.addEventListener('change', function() {
            const newProgramInput = document.querySelector('input[name="newProgramName"]');
            if (this.value === 'new') {
                newProgramInput.disabled = false;
            } else {
                newProgramInput.disabled = true;
                newProgramInput.value = ''; // Clear input if not creating new
            }
        });
    });
document.addEventListener('DOMContentLoaded', function () {
    // Get all the edit buttons
    const editButtons = document.querySelectorAll('.edit-btn');

    editButtons.forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            const row = this.closest('tr');
            const cell = row.querySelector('.editable');

            // Make the cell editable
            const originalText = cell.textContent;
            const input = document.createElement('input');
            input.type = 'text';
            input.value = originalText;
            input.classList.add('edit-input');
            cell.innerHTML = '';
            cell.appendChild(input);
            input.focus();

            // Save changes when losing focus
            input.addEventListener('blur', function () {
                const updatedText = input.value;
                const id = cell.getAttribute('data-id');

                // Replace input field with updated text
                cell.textContent = updatedText;

                // Save the updated data to the database via an AJAX request
                saveToDatabase(id, updatedText);
            });
        });
    });

    // Function to save data to the database
    function saveToDatabase(id, updatedName) {
        // Use fetch API or jQuery AJAX for sending data to the server
        fetch('updateProgram.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id: id, name: updatedName })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Updated successfully');
            } else {
                console.error('Update failed');
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
});
</script>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Guide - Automatic Timetable Generator</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
        }
        .msg {
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .msg h2 {
            text-align: center;
            margin-bottom: 20px;
            /* color: #333; */
        }
        .msg h3 {
            margin-top: 20px;
            /* color: #444; */
        }
        .msg p, .msg ul {
            margin-left: 20px;
        }
        .msg ul {
            list-style: none;
            padding: 0;
        }
        .msg ul li {
            margin: 10px 0;
            position: relative;
            padding-left: 25px;
        }
        .msg ul li:before {
            content: "\f00c";
            font-family: "Font Awesome 5 Free";
            font-weight: 900;
            position: absolute;
            left: 0;
            color: #00aaff;
        }
        .msg .note {
            margin-top: 30px;
            padding: 15px;
            border-left: 5px solid #ffa000;
        }
        .msg .note h4 {
            margin: 0 0 10px;
            font-size: 1.2em;
        }
    </style>
    <div class="msg">
        <h2><i class="fas fa-calendar-alt"></i> User Guide for the Automatic Timetable Generator</h2>
        
        <h3>Step 1: Choose or Create a Program <i class="fas fa-graduation-cap"></i></h3>
        <p>Select an existing program or create a new one. Ensure the program aligns with your institution's structure for accurate scheduling.</p>
        
        <h3>Step 2: Manage Resources <i class="fas fa-chalkboard-teacher"></i> <i class="fas fa-book"></i> <i class="fas fa-door-open"></i></h3>
        <ul>
            <li><strong>Teachers:</strong> Add unique IDs to avoid conflicts.</li>
            <li><strong>Subjects:</strong> Allocate 6 subjects per semester. Assign types like Lecture, Machine Lab, or Specialized Lab.</li>
            <li><strong>Rooms:</strong> Define room types and capacities. Separate Lecture Rooms, Machine Labs, and Specialized Labs.</li>
        </ul>

        <h3>Step 3: Define Semesters and Sections <i class="fas fa-calendar"></i></h3>
        <p>Break your program into semesters and sections (e.g., A, B, C). Assign 6 subjects per semester and specify student counts for sections.</p>
        
        <h3>Step 4: Allot Teachers <i class="fas fa-tasks"></i></h3>
        <p>Match teachers with their respective subjects and sections. Check for accuracy to prevent conflicts.</p>
        
        <h3>Step 5: Generate Timetables <i class="fas fa-clock"></i></h3>
        <p>Review the input data and generate the timetable. If unsatisfied, you can regenerate until the timetable meets your requirements.</p>

        <div class="note">
            <h4>Note:</h4>
            <p>This timetable generator is tailored for academic institutions:</p>
            <ul>
                <li>Monday to Friday schedule.</li>
                <li>2 Lectures and 2 TDAs (Tutorials, Discussions, and Assignments) per week for each subject.</li>
                <li>Automatic conflict resolution and free periods allocation.</li>
            </ul>
        </div>
    </div>
