<?php
include '../TTgeneration/classes.php';
include '../TTgeneration/view.php'; 
include '../TTgeneration/buildstr.php';
include '../TTgeneration/generator.php';
?>
<style>
.addBtn{
    display: none;
}
form{
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
}
#save{
    margin-top:10px;
}
option{
    background: var(--bgcolor);
}
table button{
    background: var(--bgcolor);
}
table{
    border-radius: 10px;
    padding:10px;
}
.footer{
    display : flex;
    background-color: var(--bgcolor);
    padding:0 10px;
    border-radius: 10px;
    border: 1px solid white;
    width: 90%;
}
.list{
    display :inline-block;
}
ul{
    list-style-type: none;
}
#result_table tr:nth-child(1){
    background-color: var(--bgcolor);
}
#changecontentbtn{
    width: 205px;
}
td{
    word-wrap: break-word; 
}
</style>
<script>
    function showSubject(str,name) {
        console.log("name",name);
        if (str == "") {
            document.getElementById("txtHint").innerHTML = "";
            return;
        }
        element =document.getElementById(name);
        console.log(element);
        // Fetch sections based on the selected semester
        fetchSections(str,element);
    }
    function fetchSections(semesterId,element) {
        
        if (semesterId == "") {
            // If no semester is selected, clear the section dropdown
            element.innerHTML = '<option disabled selected>Select Section</option>';
            return;
        }
        // Create an AJAX request to fetch sections
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                // Update the section dropdown with the fetched options
                element.innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET", "get_sections.php?semester_id=" + semesterId, true);
        xmlhttp.send();
    }
    function showSemester(str) {
        if (str == "") {
            document.getElementById("txtHint").innerHTML = "";
            return;
        }

        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("semester").innerHTML = xmlhttp.responseText;

            // Pass the semester name and ID to the server-side script
            // showSubject(str, echo $semester_id; ); // This line is commented out

            // Extract the selected semester ID from the response
            var selectedSemesterId = document.getElementById("semester").value;

            // Call showSubject with the selected semester ID
            showSubject(selectedSemesterId);
            }
        }

        // alert(str);
        // xmlhttp.open("GET", "semester_ajax.php?id=" + str, true);
        // xmlhttp.send();
        }

        function showTeacher(str) {
        if (str == "") {
        document.getElementById("txtHint").innerHTML = "";
        return;
        }

        if (window.XMLHttpRequest) {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
        } else {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }

        xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            document.getElementById("teacher_name").innerHTML = xmlhttp.responseText;
        }
        }

        xmlhttp.open("GET", "get_teacher_name.php?id=" + str, true);
        xmlhttp.send();
    }
</script>

<body>
    <form action=""method="post">
    <table>
        <tr>
        <td scope="row" name="sem_box">Select Semester</td>
        <td colspan="2">
            <?php                
            // Fetch semesters from the database
            $semesters_query = mysqli_query($con, "SELECT * FROM semester");
            
            // Check if any semesters are fetched
            if(mysqli_num_rows($semesters_query) > 0) {
                // Start select dropdown
                echo '<select name="sem_box" onchange="showSubject(this.value,\'section\')" class="form-control">';
                echo '<option disabled selected>Select Semester</option>';
                
                // Loop through each semester and create an option tag
                while ($semester = mysqli_fetch_assoc($semesters_query)) {
                    echo '<option value="' . $semester['semester_id'] . '">' . $semester['semester_name'] . '</option>';
                }
            // End select dropdown
                echo '</select>';
            } else {
                echo 'No semesters found'; // Show a message if no semesters are found
            }
            ?>
        </td>
        </tr>
        <tr>
        <td scope="row">Select Section</td>
        <td colspan="2">
            <?php
                echo '<select  name="sec_box" id="section"  class="form-control">';
                echo '<option disabled selected>Select Section</option>';
                echo '</select>';
            ?>
        </td>
        </tr>      
        <!-- <tr>
            <td scope="row" name="tch_box">Select Teacher</td>
            <td colspan="2">
                <select name="tch_box" id="teacher" class="form-control">
                    <option disabled selected>Select Teacher</option>
                    <?php
                    // Fetch teachers from the database
                    $teachers_query = mysqli_query($con, "SELECT * FROM teacher order by name DESC");

                    // Check if any teachers are fetched
                    if(mysqli_num_rows($teachers_query) > 0) {
                        // Loop through each teacher and create an option tag
                        while ($teacher = mysqli_fetch_assoc($teachers_query)) {
                            echo '<option value="' . $teacher['teacher_id'] . '">' . $teacher['name'] . '</option>';
                        }
                    } else {
                        echo '<option disabled>No teachers found</option>'; // Show a message if no teachers are found
                    }
                    ?>
                </select>
            </td>
        </tr> -->
        <tr>
            <td><input type="submit"value="VIEW TIMETABLE" name ="view"></td>
            <td><input type="submit" value="CHECK" name="check"></td>
            <td id="changecontentbtn"><button type="button" id="myButton"onclick="changeText()">Subject</button></td>
            <input type="hidden" name="type" id="type" value="S"> 
        </tr>
    </table>
    <script>
            function changeText(event) {
                var button = document.getElementById('myButton');
                var type =document.getElementById('type');
                if (button.innerHTML === 'Subject') {
                    button.innerHTML = 'Teacher';
                    type.value = 'T';
                } else {
                    button.innerHTML = 'Subject';
                    type.value = 'S';
                }
            }
    </script>
<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
        //take section and semester from user
    $sec = isset($_POST['sec_box'])?$_POST['sec_box']:null;
    $sem = isset($_POST['sem_box'])?$_POST['sem_box']:null;
    $tch = isset($_POST['tch_box'])?$_POST['tch_box']:null;
    $type = isset($_POST['type'])?$_POST['type']:null;
        //take section and semester from inside the code
    if(!isset($sec)||!isset($sem)){
        $sec=$_POST['section'];
        $sem=$_POST['semester'];
    }
        //if both section boxes not exist show error
    if(!isset($_POST['section'])&&!isset($sec))
    echo "<p class='msg'>Please select the desire section of semester to view the timetable</p>";
        //get variables
    $sub_str=buildsubstr($sub_str,$conn,$sem,$sec);//main core of the abut to run code
    $overlap = getoverlap($sec,$conn);//overlap?

    //declare the name of the section
    $stmt=$conn->prepare("SELECT section_name from section where section_id=?");
    $stmt->execute([$sec]);
    $S_N=$stmt->fetchColumn();
    $sem_name = strval($sem)[0];
    echo "<p class='msg'> Section ".$S_N[3] ." of semester ".$sem_name."</p> ";


    //to view the timetable already generated
    if(isset($_POST['view'])&&(isset($sec)||isset($_POST['section']))){
        //this act like the session
        echo"<input type='hidden' name='section' value='$sec'>";
        echo "<input type='hidden' name='semester'value='$sem'>";
        if(isset($sec)){
            //to notify the user which section he is currently viewing
            $arr=codetotable($sub_str,$conn,$sem,$sec);
            if(!empty($arr)){
                if($type=="T"){
                    $arr=gthtable($arr,$conn,$sub_str);
                    $arr=addthname($arr,$conn,$sub_str);
                }
                // var_dump($arr);
                $ind=getInd($conn,$sem,$sec);
                $rind=getrind($conn,$sec,$sem);
                $ltdas=get_Ltdaed($sec,$conn);
                $arr=add_aliases($arr,$rind,$ltdas);
                $t=[];
                $t=out_layout($t,$conn);
                $t=add_sub($t,$arr);
                disp_table($t);
                echo "<br><br>";
                timetablefooter($sub_str,$conn);
                echo "<br><br>";
                echo"<input type='submit'name='edit'value='EDIT'>";
                restore_error_handler();
            }else echo "<p class='msg'>Please generate the timetable first</p> ";
        }
    }

    if(isset($_POST['edit'])){
        echo"<input type='hidden' name='section' value='$sec'>";
        echo "<input type='hidden' name='semester'value='$sem'>";
        if(isset($sec)){
            //to notify the user which section he is currently viewing
            $allrms = [];
            $sql = "Select * from room";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach($result as $row) {
                $allrms[] = $row["rm_code"];
            }
            $sql = 'select * from teach where day_P = ?';
            $stmt = $conn->prepare($sql);
            echo"<input type='submit'name='editdone'value='DONE'>";
            $arr=codetotable($sub_str,$conn,$sem,$sec);
            if(!empty($arr)){
                $ind=getInd($conn,$sem,$sec);
                $rind=getrind($conn,$sec,$sem);
                $ltdas=get_Ltdaed($sec,$conn);
                for($i=0;$i<5;$i++){
                    for($j=0;$j<6;$j++){
                        $period="$i$j";
                        $rmonpd =[];
                        $stmt->execute([$period]);
                        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        foreach($result as $row) {
                            $rmonpd[] = $row["rm_code"];
                        }
                        $ava = array_diff($allrms,$rmonpd);
                        if(!empty($rind["$period"])){
                            $subj = $arr[$i][$j];
                            $alias = $ltdas[$period];
                            $room = $rind[$period];
                        $temp[$i][$j]="<span>";
                        $temp[$i][$j].="<input type='text'name='sub[]'id='$j'value='$subj'id='swapsub'size=10 readonly>";
                        // $temp[$i][$j].="<select name='sub[]'>";
                        // foreach($sub_str as $v){
                        //     $subname = $v->sub_name;
                        //     $selected = $subj == $subname ? "selected":"";
                        //     $temp[$i][$j].= "<option value='$subname'$selected>$subname</option>";
                        // }
                        // $temp[$i][$j].= "</select>";
                        $temp[$i][$j].="<input type='text'name='ali[]'id='$j'value='$alias'id='swapalias'size=15>";
                        $temp[$i][$j].="<br> Room (";
                        // $temp[$i][$j].="<input type='text'name='rm[]'id='$j'value='$room'id='swaproom'size=3>";
                        $temp[$i][$j].="<select name ='rm[]'class='rm'> 
                        <option value = '$room' selected>$room</option>";
                         
                        foreach($ava as $v){
                        $temp[$i][$j].="<option value = '$v'>$v</option>";
                        }
                        $temp[$i][$j].="</select>";
                        $temp[$i][$j].=")";
                        $temp[$i][$j].="</span>";
                    }else{
                        $temp[$i][$j]="<span style='display:none'>";
                        $temp[$i][$j].="<input type='text'name='sub[]'id='$j'value=' 'id='swapsub'size=10 readonly>";
                        $temp[$i][$j].="<input type='text'name='ali[]'id='$j'value=' 'id='swapalias'size=15>";
                        $temp[$i][$j].="<br> Room (";
                        // $temp[$i][$j].="<input type='text'name='rm[]'id='$j'value=' 'id='swaproom'size=3>";
                        $temp[$i][$j].="<select name ='rm[]'class='rm'> 
                        <option value = ' ' selected> </option>";
                         
                        foreach($ava as $v){
                        $temp[$i][$j].="<option value = '$v'>$v</option>";
                        }
                        $temp[$i][$j].="</select>";
                        $temp[$i][$j].=")";
                        $temp[$i][$j].="</span>";
                        }
                    }
                }
                $arr = $temp;
                $t=[];
                $t=out_layout($t,$conn);
                $t=add_sub($t,$arr);
                disp_table($t);
                restore_error_handler();
            }else echo "<p class='msg'>Please generate the timetable first</p> ";
        }
        include('edittimetable.php');
    }
    if(isset($_POST['editdone'])){
        echo"<pre>";
        echo"<input type='hidden' name='section' value='$sec'>";
        echo "<input type='hidden' name='semester'value='$sem'>";
        $sub = $_POST['sub'];
        $alias = $_POST['ali'];
        $rooms = $_POST['rm'];
        for($i= 0;$i<count($sub);$i++){
            $j = $i%6;$k=intval($i/6);
            $subarr[$k][$j]=$sub[$i];
            $aliarr[$k][$j]=$alias[$i];
            $rmarr[$k][$j] = $rooms[$i];
        }
        // var_dump($subarr,$aliarr,$rmarr);
        $ind = getrandInd($subarr,$sub_str);
        // var_dump($ind);
        // $originSubs = codetotable($sub_str,$conn,$sem,$sec);
        savetimetable($ind,$conn,$sem,$sec);
        // var_dump($originSubs);
        for($i=0;$i<5;$i++){
            for($j= 0;$j<6;$j++){
                // if($originSubs[$i][$j]!= $subarr[$i][$j]){
                    $s = $subarr[$i][$j]==" "?null:$subarr[$i][$j];
                    $t = $sub_str[$ind[$i][$j]]->sub_teacher;
                    $a = $aliarr[$i][$j]==" "?null:$aliarr[$i][$j];
                    $r = $rmarr[$i][$j]==" "?null:$rmarr[$i][$j];
                    $D = "$i$j";
                    $sql = 'update teach set subject_id = ? ,teacher_id=?,alias=?,rm_code=? where 
                    section_id=? and day_P =?';
                    $stmt = $conn->prepare($sql);
                    $stmt->execute([$s,$t,$a,$r,$sec,$D]);  
                    // var_dump($s,$t,$a,$r,$sec,$D);
                // }
            }
        }
        echo "<p class='msg'>Data are Updated</p>";
    }
    if(isset($_POST['check'])&&(isset($sec)||isset($_POST['section']))){
        include"check.php";
    }


    if(isset($_POST['generate'])&&(isset($sec)||isset($_POST['section']))){
        $am =isset($_POST['am'])?$_POST['am']:null;
        $pm =isset($_POST['pm'])?$_POST['pm']:null;
        $fixedfree=isset($_POST['freeday'])?$_POST['freeday']:null;
        if(isset($_POST['fromcheck'])){
            $ovsec=isset($_POST['overlap'])&&isset($_POST['ovsec'])?$_POST['ovsec']:null;
            $ovsub=isset($_POST['overlap'])&&isset($_POST['ovsubs'])?$_POST['ovsubs']:null;
            $consecutive=isset($_POST['consubs'])?$_POST['consubs']:null;
            saveconov($sec,$ovsec,$ovsub,$consecutive,$conn);
        }
        
            //get variables
        $sub_str=buildsubstr($sub_str,$conn,$sem,$sec);//main core of the abut to run code
        $overlap = getoverlap($sec,$conn);//overlap?
        //this act like the session
        echo"<input type='hidden' name='section' value='$sec'>";
        echo "<input type='hidden' name='semester'value='$sem'>";
        echo "<input type='hidden' name='am'value='$am'>";
        echo "<input type='hidden' name='pm'value='$pm'>";
        echo "<input type='hidden' name='freeday'value='$fixedfree'>";

        //check if the timetable is already generated
        $sql = "SELECT timetable_code from section where semester_id=? and section_id=?";
        $stmt=$conn->prepare($sql);
        $stmt->execute([$sem,$sec]);
        $result = $stmt->fetchColumn();

        if(!empty($result)){
            echo '<p class="msg">The timetable is already existed <br> Do you like to regenerate!</p>
            <input type="submit" value="YES"name="yes" class="btn myBtn " style="margin:10px 30px;">
            <input type="submit" value="NO"name="no" class="btn myBtn" style="margin:10px 30px;">';
        }else{
            echo '<input type="submit" value="AGAIN"name="generate" class="btn myBtn"id="save">';
            //variable declaraion
            $table=[];
            $rind =[];
            
            $box=generate_table($conn,$sem,$sub_str,$overlap,$fixedfree);//main

            $stable=$box->table;//get the table
            $ind=getrandInd($stable,$sub_str);//indexes to use further
            checkInd($ind,$sub_str);
            //generate the room array for this section
            $frpdofrm=getfrpdofrm($conn);//get all the rooms former period array
            $rind = getrandrind($ind, $sub_str, $conn,$frpdofrm,$overlap);
            //act like session to save
            $iarr = serialize($ind);
            echo "<input type='hidden' name='ind'value='$iarr'>";
            $arr = serialize($stable);
            echo "<input type='hidden' name='stable'value='$arr'>";
            $rarr=serialize($rind);
            echo "<input type='hidden' name='rind'value='$rarr'>";
            $str=base64_encode(serialize($sub_str));
            echo"<textarea name='substr'style='display:none'>".$str."</textarea>";
            //add to timetable for display
            $ltdas=get_Ltda($stable,$rind,$conn,$am,$pm);
            $temp=add_aliases($stable,$rind,$ltdas);
            $table=out_layout($table,$conn);
            $table=add_sub($table,$temp);
            disp_table($table);
            echo '<input type="submit" value="SAVE"name="confirm" class="btn myBtn"id="save">';
            timetablefooter($sub_str,$conn);
        }
    }
    if(isset($_POST['confirm'])){
        $ind=$_POST['ind']?unserialize($_POST['ind']):null;
        $sub_str = $_POST['substr']?unserialize(base64_decode($_POST['substr'])):null;
        $rind= $_POST['rind']?unserialize($_POST['rind']):null;
        $stable= $_POST['stable']?unserialize($_POST['stable']):null;
        $sec=$_POST['section'];
        $sem=$_POST['semester'];
        $am =isset($_POST['am'])?$_POST['am']:null;
        $pm =isset($_POST['pm'])?$_POST['pm']:null;
        $ltdas=get_Ltda($stable,$rind,$conn,$am,$pm);
        savetimetable($ind,$conn,$sem,$sec);
        savethsub($conn,$sub_str,$rind,$ltdas,$ind,$sec,$sem);
        echo "<p class='msg'>Data are saved</p>";
    }
    if(isset($_POST['tch_box'])){
        view_thtable($tch,$conn);
    }
    if(isset($_POST['yes'])){
        $sec=$_POST['section'];
        $sem=$_POST['semester'];
        echo "<p class='msg'>Please choose again</p>";
        $sql ="UPDATE section set timetable_code='' where semester_id=? and section_id=?";
        $stmt=$conn->prepare($sql);
        $stmt->execute([$sem,$sec]);
        $sql = "DELETE FROM teach where semester_id=? and section_id =?";
        $stmt=$conn->prepare($sql);
        $stmt->execute([$sem,$sec]);
    }
    if(isset($_POST['no'])){
        header("Location: {$_SERVER['PHP_SELF']}");
        exit;
    }
}
    ?>
    <input type="hidden" id="pgname"value="Generator">
    </form>
</body>
</html>
