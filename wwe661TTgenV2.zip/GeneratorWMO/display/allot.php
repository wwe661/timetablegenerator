<table id='allotTable'>
    <!-- <tr class='danger'>
        <th colspan='8'>
            
        </th>
    </tr> -->
    <tr id="table-head">
		<th>Semester 
        <a href='admindashboard.php?info=th_sub&sort=sem' class='btn updateBtn'><i class="fas fa-sort"></i></a>
        </th>
		<th>Section </th>
	    <th>Teacher ID
        <a href='admindashboard.php?info=th_sub&sort=tch' class='btn updateBtn'><i class="fas fa-sort"></i></a>
        </th>
        <th>Teacher Name</th>
        <th>Subject ID
        <a href='admindashboard.php?info=th_sub&sort=sub' class='btn updateBtn'><i class="fas fa-sort"></i></a>
        </th>
        <th>Subject Name</th>
		<th>Action</th>
		<th>Action</th>
    </tr>
    <?php
$q = mysqli_query($con,"SELECT * FROM th_sub order by section_id,subject_id ASC");
$t = mysqli_query($con,"SELECT * FROM th_sub order by teacher_id,section_id ASC");
$sub = mysqli_query($con,"SELECT * FROM th_sub order by semester_id,subject_id,section_id ASC");
if(isset($_REQUEST['sort'])&&$_REQUEST['sort']=="tch") $query = $t;
else if(isset($_REQUEST['sort'])&&$_REQUEST['sort']=="sub") $query = $sub;
else if(isset($_REQUEST['sort'])&&$_REQUEST['sort']=="sem") $query = $q;
else $query = $q;
if ($query===$q) {
    $prevSemesterId = null;
    $prevSectionId = null;
    $semesterRowspanCount = 0;
    $sectionRowspanCount = 0;
    $semesterIdCount = [];
    $sectionIdCount = [];

    // Count occurrences for semesters and sections for rowspan calculation
    while ($row = mysqli_fetch_assoc($query)) {
        $semesterIdCount[$row['semester_id']] = isset($semesterIdCount[$row['semester_id']]) ? $semesterIdCount[$row['semester_id']] + 1 : 1;
        $sectionIdCount[$row['section_id']] = isset($sectionIdCount[$row['section_id']]) ? $sectionIdCount[$row['section_id']] + 1 : 1;
    }

    // Reset the query to iterate again
    mysqli_data_seek($query, 0);
}
    // Iterating again to generate table with rowspan
    while ($row = mysqli_fetch_assoc($query)) {
        echo "<tr>";
        if($query === $q){
            // var_dump($query);
            // Display Semester column with rowspan
        if ($row['semester_id'] !== $prevSemesterId) {
            $semesterRowspanCount = $semesterIdCount[$row['semester_id']];
            $semesterQuery = mysqli_query($con, "SELECT * FROM semester WHERE semester_id='" . $row['semester_id'] . "'");
            $semesterData = mysqli_fetch_assoc($semesterQuery);
            echo "<td rowspan='{$semesterRowspanCount}'>{$semesterData['semester_name']}</td>";
            $prevSemesterId = $row['semester_id'];
        }

        // Display Section column with rowspan
        if ($row['section_id'] !== $prevSectionId) {
            $sectionRowspanCount = $sectionIdCount[$row['section_id']];
            $sectionQuery = mysqli_query($con, "SELECT * FROM section WHERE section_id='" . $row['section_id'] . "'");
            $sectionData = mysqli_fetch_assoc($sectionQuery);
            echo "<td rowspan='{$sectionRowspanCount}'>{$sectionData['section_name']}</td>";
            $prevSectionId = $row['section_id'];
        }
        }else{
            // var_dump($query);
            $p = mysqli_query($con, "SELECT * FROM semester WHERE semester_id='" . $row['semester_id'] . "'");
            while ($a = mysqli_fetch_assoc($p)) {
                ?>
                <td><?php echo $a['semester_name']; ?></td>
            <?php } 
            $r = mysqli_query($con, "SELECT * FROM section WHERE section_id='" . $row['section_id'] . "'");
            while ($b = mysqli_fetch_assoc($r)) {
                ?>
                <td><?php echo $b['section_name']; ?></td>
            <?php }    
        }
                echo"<td>{$row['teacher_id']}</td>";
                $a = mysqli_query($con, "SELECT * FROM teacher WHERE teacher_id='" . $row['teacher_id'] . "'");
                    while ($b = mysqli_fetch_assoc($a)) { ?>
                         
                        <td><?php echo $b['name']; ?></td> <?php } 
                echo "
                <td>{$row['subject_id']}</td>";
                $p = mysqli_query($con, "SELECT * FROM subject WHERE subject_id='" . $row['subject_id'] . "'");
                while ($a = mysqli_fetch_assoc($p)) { ?>
                    
                    <td><?php echo $a['subject_name']; ?></td> <?php } 
                
                echo "
                    <td>
                        <button class='delBtn' onclick=deleteData({$row['th_sub_id']})>Delete</button>
                    </td>
                    <td>
                    <a class='updateBtn' role='button' href='admindashboard.php?info=update_allot&id={$row['th_sub_id']}'>Update</a>
                    </td>
                    </tr>\n";
		}
    ?>
</table>
<input type="hidden" value ="th_sub"id ="pgname">
<style>
    #allotTable #table-head th{
        width: 1px;
    }
</style>