<?php
include("../Database/config.php");

// Get the raw JSON input
$data = json_decode(file_get_contents("php://input"), true);

// Validate the input
if (isset($data['id']) && isset($data['name'])) {
    $id = $data['id'];
    $name = $data['name'];

    $connection =connect("localhost","USER","wild","Waing@4421661");
    // Prepare the SQL statement
    $stmt = $connection->prepare("UPDATE Programs SET name = ? WHERE id = ?");
    // Execute the query
    if ($stmt->execute([$name,$id])) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
}
?>
