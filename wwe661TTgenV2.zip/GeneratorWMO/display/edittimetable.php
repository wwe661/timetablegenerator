
<style>
    td{
        cursor: move;
    }
    #swaproom{
        display: inline;
    }

</style>
<script>
    let  draggedCell = null;

    function handleDragStart(e) {
        draggedCell = this;
        e.dataTransfer.effectAllowed = 'move';
    }

    function handleDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        return false;
    }

    function handleDrop(e) {
        e.stopPropagation();
        if ( draggedCell !== this) {
            // const sourceIndex = Array.from( draggedCell.parentNode.children).indexOf( draggedCell);
            // const targetIndex = Array.from(this.parentNode.children).indexOf(this);

            // const table = document.getElementById('table');
            // const rows = table.rows;

            // // for (let i = 0; i < rows.length; i++) {
            //     const sourceCell = rows[i].cells[sourceIndex];
            //     const targetCell = rows[i].cells[targetIndex];
                // Swap the cell contents
            // if(draggedCell.innerHTML== " "){
            
                const draggedInput = draggedCell.querySelector('input');
                const targetInput = this.querySelector('input');
                // Swap the values of corresponding inputs
                if(draggedInput && targetInput){
                    console.log(draggedInput.id);
                    console.log(targetInput.id);
                    if(draggedInput.id<3&&targetInput.id<3) draggable = true;
                    else if(draggedInput.id>=3&&targetInput.id>=3)draggable =true;
                    else draggable = false;
                // for (let i = 0; i < draggedInputs.length; i++) {
                    // const tempValue = draggedInputs[i].name;
                    // draggedInputs[i].name = targetInputs[i].name;
                    // targetInputs[i].name = tempValue;
                // }
                }
                if(draggable){
                    const tempHtml = draggedCell.innerHTML;
                    draggedCell.innerHTML = this.innerHTML;
                    this.innerHTML = tempHtml;

                    const draggedSelect = draggedCell.querySelector('.rm');
                    const thisSelect = this.querySelector('.rm');
                    console.log(draggedSelect);
                    if (draggedSelect && thisSelect) {
                        // Clone the nodes to avoid issues with references
                        const clonedDraggedSelect = draggedSelect.cloneNode(true);
                        const clonedThisSelect = thisSelect.cloneNode(true);

                        const draggedParent = draggedSelect.parentNode;
                        const thisParent = thisSelect.parentNode;
                        // Swap the elements
                        if (draggedParent && thisParent) {
                            draggedParent.replaceChild(clonedThisSelect, draggedSelect);
                            thisParent.replaceChild(clonedDraggedSelect, thisSelect);
                        }
                    }
                }

            // }
        }
        return false;
    }

    // Attach event listeners to header columns
    const cells = document.querySelectorAll('td');
    cells.forEach(cell => {
        cell.draggable='true';
        cell.addEventListener('dragstart', handleDragStart, false);
        cell.addEventListener('dragover', handleDragOver, false);
        cell.addEventListener('drop', handleDrop, false);
    });
</script>