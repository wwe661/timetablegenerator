<?php 
include("../TTgeneration/view.php");
$t=[];
$t=out_layout($t,$conn); 
// $t = defaultlayout($t);
echo"<pre>";
// var_dump($t);
echo"<form method = 'post'>";
echo '<table id="result_table" style="margin-top:20px;">';
echo '<thead>';
for($i=0;$i<count($t[0]);$i++){
    $read = $i==0?"readonly":"";
    echo "<th> <input type='text'value='".$t[0][$i]."'name='layout[]'size=15$readonly></th>";
}
echo "</thead>";
echo'<tbody id="schedule_body">';
for($i=1;$i<count($t);$i++){
    echo "<tr>";
    for($j=0;$j<count($t[$i]);$j++){
        if($j==0){
        echo "<th><input type='text'value='".$t[$i][$j]."'name='layout[]'size=8 readonly></th>";   
        }else
        echo "<td draggable = true><input type='text'value='".$t[$i][$j]."'name='layout[]'size=5></td>"; 
    }
echo"</tr>";
}
$spanwidth = count($t[0])-2;
echo "</tbody><tfoot><tr><th class = 'inserts'>
    <button onclick='addDay(event)' id='addayBtn'><i class='fa-solid fa-arrow-down'></i></button>
    DAYS
    <button onclick='removeLastDay(event)' id='rmdayBtn'><i class='fa-solid fa-arrow-up'></i></button>
    </th>
    <th colspan =$spanwidth><input type = 'submit'value ='DONE'name='done'></th>
    <th class = 'inserts'>
    <button onclick ='rmPeriod(event)' id='rmper'><i class='fa-solid fa-arrow-left'></i></button>
    PERS
    <button onclick ='addPeriod(event)' id='addper'><i class='fa-solid fa-arrow-right'></i></button>
    </th>
</tr>
</tfoot>";
// <button onclick='removeLastDay(event)' id='addayBtn'><i class='fa-solid fa-arrow-up'></i><br><span class='cir'><i class='fa-solid fa-minus'></i></span></button>

echo"</table></form>";

if(isset($_POST["done"])){
    $layout = $_POST["layout"];
    // var_dump($layout);
    // $temp = [];$once = true;
    // foreach($layout as $k=>$v){
    //     $bool = 
    // }
    $temp = array_filter($layout, function($value) {
        return stripos($value, 'day') !== false; // stripos is case-insensitive
    });
    $row = count($temp);
    $columns = count($layout)/$row;
   
    $temp = [];
    for($i=0;$i<count($layout);$i++){
        $k =floor($i/$columns);
        $j =$i%$columns;
        $temp[$k][$j] = $layout[$i];
    }
    disp_table($temp);

    $select = 'SELECT * FROM layout WHERE id = ?';
    $selstmt = $conn->prepare($select);

    $delete = 'DELETE FROM layout WHERE id = ?';
    $delstmt = $conn->prepare($delete);

    $insert = 'INSERT INTO layout (id) VALUES (?)';
    $instmt = $conn->prepare($insert);

    // Looping through the rows and columns
    for ($i = 0; $i < 8; $i++) {
        // Check if this ID exists  
        $selstmt->execute([$i]);
        $result = $selstmt->fetch();

        if(!isset($temp[$i])) { 
            if($result) $delstmt->execute([$i]);
            continue;
        }elseif($result === false) {
            // If the row doesn't exist, insert it
            $instmt->execute([$i]);
        }
        // Now handle the updates
        for ($j = 0; $j < 10; $j++) {
            // Dynamically build the column name
            $columnName = "`$j`";  // You can also replace `$j` with actual column names if needed
            $update = "UPDATE layout SET $columnName = ? WHERE id = ?";
            
            $upstmt = $conn->prepare($update);
            // var_dump($temp[$i][$j]);
            $data = isset($temp[$i][$j])? $temp[$i][$j] : null;
            $upstmt->execute([$data, $i]);
            // $upstmt->execute([$temp[$i][$j],$i]);
        }
    }

}
?>
<style>
    .addBtn{
        display: none;
    }

    table {
    table-layout: fixed;
    width: 100%; /* Or any fixed width */
    overflow-x: auto;
    }

    th, td {
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
    }
    td{
        cursor: move;
    }
    .inserts{
        white-space: nowrap;
        overflow: visible;
        /* display: flex; */
    }
    #page_wrapper{
        overflow: auto;
    }
    .cir{
        padding: none;
        border:1px solid white;
        border-radius: 50%;
    }


</style>
<script>
    let  draggedCell = null;

    function handleDragStart(e) {
        draggedCell = this;
        e.dataTransfer.effectAllowed = 'move';
    }

    function handleDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        return false;
    }

    function handleDrop(e) {
        e.stopPropagation();
        if ( draggedCell !== this) {
            const tempHtml = draggedCell.innerHTML;
            draggedCell.innerHTML = this.innerHTML;
            this.innerHTML = tempHtml;
        }
        return false;
    }

    // Attach event listeners to header columns
    cells = document.querySelectorAll('td');
    cells.forEach(cell => {
        cell.draggable='true';
        cell.addEventListener('dragstart', handleDragStart, false);
        cell.addEventListener('dragover', handleDragOver, false);
        cell.addEventListener('drop', handleDrop, false);
    });
    const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
let currentDayIndex = 0;
let periodCounter = 8; // Periods start from 8th hour (8:30 am).

// Add a new day to the table
function addDay(event) {

    event.preventDefault();

    if (currentDayIndex == daysOfWeek.length-1) {
        const addDayBtn = document.getElementById("addayBtn");
        addDayBtn.disabled = true;
        return;
    }   

    const tbody = document.getElementById('schedule_body');
    const row = document.createElement('tr');
    currentDayIndex = tbody.rows.length;
    const table = document.getElementById('schedule_body').parentElement; // Reference to the table
    headerRow = table.querySelector('thead tr'); // Header row
    periods = headerRow.querySelectorAll('th'); // All header cells
    console.log(currentDayIndex);
    html = `<th><input type="text" value="${daysOfWeek[currentDayIndex]}" name="layout[]" size="8" readonly></th>`;
    for(i=0;i<periods.length-1;i++){
        if(i==3){
            html +=`<td draggable="true"><input type="text" value="Lunch" name="layout[]" size="5"></td>`;
        }else{
            html +=`<td draggable="true"><input type="text" value=" " name="layout[]" size="5"></td>`;
        }
    }
    row.innerHTML = html;
        
    tbody.appendChild(row);
}
function removeLastDay(event) {
    event.preventDefault();
    const tbody = document.getElementById('schedule_body');
    const rows = tbody.rows;

    if (rows.length > 1) {
        tbody.removeChild(rows[rows.length - 1]);
    }
    const addDayBtn = document.getElementById("addayBtn");
    addDayBtn.disabled = false;
}

// Add a new period to the table
function addPeriod(event) {
    event.preventDefault(); // Prevent default behavior of the button

    const tbody = document.getElementById('schedule_body');
    const headerRow = document.querySelector('thead tr');
    const periods = headerRow.querySelectorAll('th'); // All header cells
    const maxPeriods = 10; // Define maximum periods

    // Check if maximum periods reached
    if (periods.length - 1 >= maxPeriods) {
        addper =document.getElementById('addper');
        addper.disabled = true;
        return;
    }

    // Get the last period's time
    const lastPeriodCell = periods[periods.length -1];
    const lastTimeRange = lastPeriodCell.querySelector('input').value.trim();
    const [endHour, endMinute, endMeridian] = parseTime(lastTimeRange.split('-')[1]);
    // Calculate the new period start and end times
    let newStartHour = endHour;
    let newStartMinute = endMinute;
    let newMeridian = endMeridian;
    // Add an hour
    newStartMinute += 10;
    if (newStartMinute >= 60) {
        newStartHour += 1;
        if(newStartHour >= 12){
            newStartHour -= 12;
            newMeridian = newMeridian === "am" ? "pm" : "am";
        }
        newStartMinute -=60;
    }
    console.log(newMeridian);
    const newEndHour = (newStartHour % 12) + 1;
    const newEndMeridian = newEndHour >= 12 ? (newMeridian === "am" ? "pm" : "am") : newMeridian;

    const newPeriodTime = `${newStartHour}:${formatMinutes(newStartMinute)}${newMeridian} - ${newEndHour}:${formatMinutes(newStartMinute)}${newEndMeridian}`;

    // Create a new period header
    const newPeriodCell = document.createElement('th');
    const newPeriodInput = document.createElement('input');
    newPeriodInput.type = "text";
    newPeriodInput.value = newPeriodTime;
    newPeriodInput.name = "layout[]";
    newPeriodInput.size = "15";

    newPeriodCell.appendChild(newPeriodInput);
    headerRow.appendChild(newPeriodCell);

    // Add empty cells for all days
    for (let i = 0; i < tbody.rows.length; i++) {
        const dayRow = tbody.rows[i];
        const newDayCell = document.createElement('td');
        const newDayInput = document.createElement('input');
        newDayInput.type = "text";
        newDayInput.value = " ";
        newDayInput.name = "layout[]";
        newDayInput.size = "5";
        newDayInput.readOnly = true;

        newDayCell.draggable = true; // Make it draggable
        newDayCell.appendChild(newDayInput);
        dayRow.appendChild(newDayCell);
    }

    // Update colspan of the submit button cell
    const submitCell = document.querySelector('tfoot th[colspan]');
    if (submitCell) {
        const currentColspan = parseInt(submitCell.colSpan, 10);

        submitCell.colSpan = currentColspan + 1;
    }
}

// Helper function to parse time
function parseTime(time) {
    const timeMatch = time.match(/(\d+):(\d+)(am|pm)/i);
    if (!timeMatch) return [0, 0, "am"];
    return [parseInt(timeMatch[1], 10), parseInt(timeMatch[2], 10), timeMatch[3].toLowerCase()];
}

// Helper function to format minutes as two digits
function formatMinutes(minutes) {
    return minutes < 10 ? `0${minutes}` : `${minutes}`;
}
function rmPeriod(event) {
    event.preventDefault(); // Prevent default button behavior

    const table = document.getElementById('schedule_body').parentElement; // Reference to the table
    const headerRow = table.querySelector('thead tr'); // Header row
    const tbody = table.querySelector('tbody'); // Table body
    const periods = headerRow.querySelectorAll('th'); // All header cells
    const submitCell = table.querySelector('tfoot th[colspan]'); // Submit cell

    // Ensure there are periods to remove (minimum 2 for "DAYS/PERIODS" and at least 1 period)
    if (periods.length <= 2) {
        alert("Cannot remove all periods!");
        return;
    }

    // Remove the last period column from the header row
    headerRow.removeChild(headerRow.lastElementChild);

    // Remove the last period column from each row in the body
    Array.from(tbody.rows).forEach(row => {
        row.removeChild(row.lastElementChild);
    });

    // Adjust the colspan of the submit button cell
    if (submitCell) {
        const currentColspan = parseInt(submitCell.colSpan, 10);
        if (currentColspan > 1) {
            submitCell.colSpan = currentColspan - 1;
        }
    }
}


</script>