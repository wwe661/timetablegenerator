function toggleMenu(element) {
    const bar = document.querySelector(".bar");
    const icon = element.querySelector(".fas"); // Select the icon inside the element
    
    if (bar.style.display === "block") {
        icon.classList.remove("fa-times");
        icon.classList.add("fa-bars");
        bar.style.display = "none"; // Use style.display to toggle
    } else {
        icon.classList.remove("fa-bars");
        icon.classList.add("fa-times");
        bar.style.display = "block";
    }
}
function deleteData(id)
{
    if(confirm("You want to delete ?"))
    {
    pgname = document.getElementById('pgname').value;
    console.log("leee pl");
    window.location.href="delete.php?id="+id+"&table="+pgname;
    }
}
function deleteData(id,event)
{
    if(confirm("You want to delete ?"))
    {
    pgname = document.getElementById('pgname').value;
    console.log("leee pl");
    window.location.href="delete.php?id="+id+"&table="+pgname;
    }
    event.preventDefault();
}
function addnew(){
    pgname = document.getElementById('pgname').value;
    addpage = "add"+pgname;
    window.location.href="admindashboard.php?info="+addpage;
}
window.onload= function(){
    pgname = document.getElementById('pgname');
    if(pgname){
        pgname = pgname.value;
        document.getElementById('titlefortable').innerHTML = pgname.toUpperCase();
        
    }else{
        addbtns=document.querySelectorAll(".addBtn");
        addbtns.forEach(element => {
            element.style.display = "none";
        });
    }
    nav = document.querySelector('.bar');
    setTimeout(function(){
        nav.style.display = 'none';
    },1000);
}
