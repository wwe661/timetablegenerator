<?php
/* 
include subjects , double check
2 consecutive sections ,
the footer as in who teach which subject , double check 
if the section overlap with others ,
change or decide between 
morning or evening with lecture or TDA 
and wednesday free or firday free
*/  
//include subjects
//this act like the session
echo"<input type='hidden' name='section' value='$sec'>";
echo "<input type='hidden' name='semester'value='$sem'>";
if($overlap->overlap){
    $temp = "$overlap->section_id[0]";
    if($temp>=5) $temp .= "$overlap->section_id[1]";
    $ovsemjs = $temp;
    $ovsecjs = $overlap->section_id;
    $ovsecnamejs = "sec".strtoupper(chr(substr($ovsecjs, -1) + 64));
    $ovsubjs = $overlap->subjects;
    foreach($ovsubjs as $subject){
        echo"<p style='display:none'class ='ovsubjs'>".$subject."</p>";
    }
}
?>
<style>
    #ovsection{
        display:none;
    }
    #swap{
        border: 1px solid white;
        padding: 3px;
        float: right;
    }
</style>
<p class="msg">Check for Confirmation</p> 
</table>
<h2>If the section share the same period with other section
    <input type="checkbox" name="overlap" id="overlap"onclick="toggleovsection(this)"value="yes"
    <?php echo $overlap->overlap?"checked":"" ?>></h2>
<div id="ovsection">
    <p class="msg">Which Section ?</p>
<?php                
// Fetch semesters from the database
$semesters_query = mysqli_query($con, "SELECT * FROM semester");

// Check if any semesters are fetched
if(mysqli_num_rows($semesters_query) > 0) {
    // Start select dropdown
    echo '<select name="ovsem" onchange="showSubject(this.value,\'checksection\')" class="form-control">';
    echo '<option disabled>Select Semester</option>';
    
    // Loop through each semester and create an option tag
    while ($semester = mysqli_fetch_assoc($semesters_query)) {
    $checked = $semester['semester_id']==$ovsemjs?'selected':'';
    echo '<option value="' . $semester['semester_id']. '"'.$checked.'>'. $semester['semester_name'] .'</option>';
    }                    
var_dump($semester);
// End select dropdown
    echo '</select>';
} else {
    echo 'No semesters found'; // Show a message if no semesters are found
}
echo'<select  name="ovsec" id="checksection"  class="form-control">';
    echo $overlap->overlap?'<option value ="'.$ovsecjs.'"selected>'.$ovsecnamejs.'</option>'
    :'<option disabled selected>Select Section</option>';

echo'</select></div>';
?>
<div id ="decide">
    <p class="msg">Please double check</p>
<table>
    <tr>
        <th>Morning</th>
        <th>Afternoon</th>
    </tr>
    <tr>
        <?php $am = "TDA";$pm="L";if($sem[0]%2==1){$am = "L";$pm="TDA";} ?>
        <td ><span id='morn'><?php echo $am ?></span> <input type="hidden" name="am"id="am"value="<?php echo $am ?>"></td>
        <td><span id ="after"><?php echo $pm ?></span><input type="hidden" name="pm"id="pm"value="<?php echo $pm ?>"><button id ="swap" ><i class="fas fa-exchange-alt"onclick="swap()"></i></button></td>
    </tr>
    <tr>
        <td><h2>2 free last period on</h2></td>
        <?php if($sem[0]<4){$day ="WEDNESDAY";$value ="2";}
        else{$day = "FRIDAY";$value ="4";} ?>
        <td style="width: 120px;"><button onclick="changeday(this)"><?php echo $day ;?></button>
        <input type="hidden" name="freeday"id="freeday"value="<?php echo $value ;?>"></td>
    </tr>
</table>
</div>
<table>
    <p class="msg">Include Subjects</p>
    <tr id="headofchoose">
        <th>Subject Code</th>
        <th>Subject Name</th>
        <th>Consecutive?</th>
    </tr>
    <?php 
    $sql="SELECT subject_name FROM subject where subject_id=?";
    $stmt=$conn->prepare($sql);
    foreach($sub_str as $key=>$value){
    $stmt->execute([$value->sub_name]);
    $name=$stmt->fetchColumn();
    $checked=$value->consecutive?"checked":"";
    echo'<tr class="rowofchoose"><td>'.$value->sub_name.'</td><td>'.$name.'</td>
    <td><input type="checkbox" name="consubs[]" value="'.$key.'"'.$checked.'></td>
    </tr>';
    }
    ?>
</table>
<table>
    <tr id="table-head">
	    <th>Teacher ID</th>
        <th>Teacher Name</th>
        <th>Subject ID</th>
        <th>Subject Name</th>
		<th>Action</th>
    </tr>
    <?php
    $q = mysqli_query($con, "SELECT * FROM th_sub where semester_id = $sem and section_id = $sec");

		while ($row = mysqli_fetch_assoc($q)) {
            // $row['semester_id']=$semester;
			echo "<tr>
                <td>{$row['teacher_id']}</td>";
                $a = mysqli_query($con, "SELECT * FROM teacher WHERE teacher_id='" . $row['teacher_id'] . "'");
                    while ($b = mysqli_fetch_assoc($a)) { ?>
                         
                        <td><?php echo $b['name']; ?></td> <?php } 
                echo "
                <td>{$row['subject_id']}</td>";
                $p = mysqli_query($con, "SELECT * FROM subject WHERE subject_id='" . $row['subject_id'] . "'");
                while ($a = mysqli_fetch_assoc($p)) { ?>
                    
                    <td><?php echo $a['subject_name']; ?></td> <?php }
                
                    echo "
                        <td>
                        <a class='updateBtn' role='button' href='admindashboard.php?info=update_allot&id={$row['id']}'>Update</a>
                        </td>
                        </tr>\n";
		}
    ?>
</table>
 <input type="submit" name="generate"value ="GENERATE">
 <input type="hidden" name="fromcheck"value ="">

<script>
    document.addEventListener("DOMContentLoaded", () => {
        element =document.getElementById("overlap");
        toggleovsection(element);
    });
function toggleovsection(element) {
    ovsubjs = [];
    subs =document.querySelectorAll(".ovsubjs");
    subs.forEach(element => {
        ovsubjs.push(element.innerHTML);
    });
    // Select all necessary elements
    const ovSection = document.getElementById("ovsection");
    const headrow = document.getElementById("headofchoose");
    const datarows = document.querySelectorAll(".rowofchoose");
    subind=0;
    // Create the new header and data cells only once
    const header = document.createElement("th");
    header.id = "addition";
    header.textContent = "Overlap on this subject?";

    // Loop through each section to toggle its display style
    if (element.checked) {
        // Show the "ovsection" element
        ovSection.style.display = "block";

        // Add the new header to the head row
        headrow.append(header);

        // Loop through each data row and add the new data cells
        datarows.forEach(row => {
            const datas = document.createElement("td");
            datas.className = "additions"; 
            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.name = "ovsubs[]";
            checkbox.value = subind;
            // Check if subind is in the ovsubjs array
            if (ovsubjs.includes(subind.toString())) {
                checkbox.checked = true; // Check the checkbox if subind is in the array
            }

            datas.appendChild(checkbox);
            row.append(datas);
            subind++;
        });
    } else {
        // Hide the "ovsection" element
        ovSection.style.display = "none";

        // Remove the added header
        const addedHeader = document.getElementById("addition");
        if (addedHeader) {
            headrow.removeChild(addedHeader);
        }

        // Remove all td elements with class 'additions' in the rows
        const addedCells = document.querySelectorAll(".rowofchoose .additions");
        addedCells.forEach(cell => {
            cell.remove();
        });
    }
}
function swap(){
    event.preventDefault(); 
    morn =document.getElementById('morn');
    after =document.getElementById('after');
    temp =morn.innerHTML;
    morn.innerHTML = after.innerHTML;
    after.innerHTML = temp;
    document.getElementById("am").value = morn.innerHTML;
    document.getElementById("pm").value = after.innerHTML;
}
function changeday(element){
    event.preventDefault();
    if (element.textContent === "WEDNESDAY") {
        element.textContent = "FRIDAY";temp =4;
    } else {
        element.textContent = "WEDNESDAY";temp=2;
    }
    document.getElementById("freeday").value =temp;
}
</script>