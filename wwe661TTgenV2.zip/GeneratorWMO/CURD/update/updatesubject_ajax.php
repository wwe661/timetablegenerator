<option value="" selected="selected" disabled="disabled">Select Subject</option>
<?php 
include('../Database/config.php');
$q=mysqli_query($con,"select * from  subject where subject_id='".$_GET['id']."'");
while($res=mysqli_fetch_assoc($q))
{
echo "<option value='".$res['sem_id']."'>".$res['semester_name']."</option>";
				
}
?>