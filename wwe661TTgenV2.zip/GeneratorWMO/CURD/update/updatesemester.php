<?php 
include('../../Database/config.php');

if(isset($_POST['update'])) {
    $sem_id = $_REQUEST['semester_id'];
    $semester_name = $_POST['s'];
    $subject1 = $_POST['s1'];
    $subject2 = $_POST['s2'];
    $subject3 = $_POST['s3'];
    $subject4 = $_POST['s4'];
    $subject5 = $_POST['s5'];
    $subject6 = $_POST['s6'];

    mysqli_query($con, "UPDATE semester SET semester_name='$semester_name', subject1='$subject1', subject2='$subject2', subject3='$subject3', subject4='$subject4', subject5='$subject5', subject6='$subject6' WHERE semester_id='$sem_id'");
    $err= "Records updated";
    header("Location: admindashboard.php?info=semester");
}

$sem_id = $_REQUEST['semester_id'];
$q=mysqli_query($con, "SELECT * FROM semester WHERE semester_id='$sem_id'");
$res=mysqli_fetch_assoc($q);
?>

<div class="row parent">
    <div class="col-md-5">
        <h2>Update Semester</h2>
        <!-- Display error/success message -->
        <?php if(!empty($err)): ?>
        <div class="alert alert-<?php echo (strpos($err, 'Error') !== false) ? 'danger' : 'success'; ?>">
            <?php echo $err; ?>
        </div>
        <?php endif; ?>
        <form method="POST" enctype="multipart/form-data">
            <table border="0" cellspacing="5" cellpadding="5" class="table">
                <!-- <tr>
                    <th width="237" scope="row">Semester ID </th>
                    <td width="213"><input type="text" name="sem_id" class="form-control" value="<?php echo $res['semester_id'];?>"/></td>
                </tr> -->
                <tr>
                    <th width="237" scope="row">Semester Name </th>
                    <td width="213"><input type="text" name="s" class="form-control" value="<?php echo $res['semester_name'];?>"readonly/></td>
                </tr>
                <?php 
                    for($i = 1; $i < 7; $i++){
                        $temp = "subject$i";
                    echo "
                    <tr>
                        <th width='237' scope='row'>Subject $i </th>
                        <td width=''>
                        <select name='s$i'id='s$i'required>
                        <option value=''selected disabled>Select Subject $i</option>";

                        $result = mysqli_query($con, "SELECT * FROM subject");
                        // Check if the query returns any rows
                    if ($result) {
                        var_dump($result);
                        // Loop through each row in the result set
                        while ($row = mysqli_fetch_assoc($result)) {
                        $selected = ($row["subject_id"] == $res[$temp]) ? "selected" : "";
                            // Access the columns by their names
                            echo "<option value='".$row["subject_id"]."'$selected>".$row["subject_name"]."</option>";
                        }
                    } 
                        echo"</select>
                        </td>
                    </tr>";
                    }
                    ?>
                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" value="Update Records" name="update" class="btn  myBtn"/>
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>