<?php 
include('../../Database/config.php');
$reqsec = $_REQUEST["section_id"];
$result = mysqli_query($con,"select * from section where section_id = $reqsec");
$reqres = mysqli_fetch_assoc($result);
$secname = $reqres["section_name"][3];
extract($_POST);
var_dump($update);
if(isset($update))
{
    mysqli_query($con,"update section set section_capacity = $stucount where section_id = $reqsec");
    $err="<font color='blue'>Congrats Your Data Saved!!!</font>";
    header("Location:admindashboard.php?info=section");
}

?>
<div>
    <legend>Update the section's Student Count</legend>
    <form action=""method="post">
    <table>
        <tr>
            <td>Semester </td>
            <td width="200"><?php echo "sem".$reqres['semester_id'][0];?></td>
        </tr>
        <tr>
            <td>Section name </td>
            <td><?php echo $reqres["section_name"][3] ?></td>
        </tr>
        <tr>
            <td>Number of Students </td>
            <td>
                <input type="number" name="stucount" id=""min="1"max="100"value ="<?php echo $reqres['section_capacity'] ?>">
            </td>
        </tr>
        <tr>
            <td colspan="2"> 
                <input type="submit"name="update" value="Update"/>
                <input type="reset" value="Reset">
            </td>
        </tr>
    </table>
    </form>
</div>