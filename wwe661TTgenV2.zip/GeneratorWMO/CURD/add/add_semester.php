<?php 
include('../../Database/config.php');
$semarr = ["sem1","sem2","sem3","sem4","sem5","sem6","sem7","sem8","sem9"];
extract($_POST);
if(isset($save))
{
  $mj1 = ["CS", "CT"];
  $mj2 = ["SE", "KE", "HPC", "BIS", "CN", "ES", "Cyber Security"];
  $temp = $semester;
  if($temp>4)$temp.=$mjadd;
	$que = mysqli_query($con, "SELECT * FROM semester WHERE semester_id = '$temp'");
	$row=mysqli_num_rows($que);
	if($row)
	{
		$err="<font color='red'>This Semester already exists</font>";
	}
	else
	{
    $semester_name= $semarr[$semester-1];
    if($semester>6)$semester_name.="-".$mj2[$mjadd-1];
    elseif($semester>4)$semester_name.="-".$mj1[$mjadd-1];
    // var_dump($temp);
    // var_dump($semester_name);
		mysqli_query($con,"INSERT INTO semester (semester_id,semester_name,  subject1, subject2, subject3, subject4, subject5, subject6) VALUES ('$temp','$semester_name','$s1', '$s2', '$s3', '$s4', '$s5', '$s6')");
	  $err="<font color='blue'>Congrats Your Data Saved!!!</font>";
    header("Location: admindashboard.php?info=semester");
	}
	
}
?>

<div class="row parent">
<div class="col-md-5">
<h2>Add Semester</h2>
<form method="POST" enctype="multipart/form-data">
  <table border="0" cellspacing="5" cellpadding="5" id="semaddtable"class="table">
  <tr>
  <td colspan="2"><?php echo @$err; ?></td>
  </tr>
   <tr>
    <th width="237" scope="row">Semester Name </th>
    <td width="213">
      <select name="semester" id="semester"onchange="showmj(this.value)" required>
        <option value="" selected disabled>Select semester</option>
        <?php 
        foreach($semarr as $key => $value){
          $temp = $key +1;
          echo "<option value='$temp'>$value</option>";
        }
        ?>
      </select>
    </td>
  </tr>
  <tr>
  <th width="237" scope="row">Major</th>
  <td width="213">
    <select name="mjadd" id="mjadd">
      <option value=""selected disabled>NONE</option>
    </select>
  </td>
  </tr>
  <?php 
  for($i = 1; $i < 7; $i++){
  echo "
  <tr>
    <th width='237' scope='row'>Subject $i </th>
    <td width=''>
    <select name='s$i'id='s$i'required>
      <option value=''selected disabled>Select Subject $i</option>";

    $result = mysqli_query($con, "SELECT * FROM subject");

// Check if the query returns any rows
if ($result) {
    // Loop through each row in the result set
    while ($row = mysqli_fetch_assoc($result)) {
        // Access the columns by their names
        echo "<option value='".$row["subject_id"]."'>".$row["subject_name"]."</option>";
    }
} 
    echo"</select>
     </td>
  </tr>";
}
?>
 <tr>
    <td colspan="2" align="center">
	<input type="submit" value="Add Semester" name="save" class="btn  myBtn" />
	
	<input type="reset" value="Reset" class="btn  myBtn"/>
	
	</td>
  </tr>
  
  </table>
  </form>
</div>
</div>
<script>
function showmj(value) {
    // Define the arrays
    let mj1 = ["CS", "CT"];
    let mj2 = ["SE", "KE", "HPC", "BIS", "CN", "ES", "Cyber Security"];
    element =document.getElementById("mjadd");
    // Choose the array based on the value of the element
    let optionsArray;
    if (value > 6) {
        optionsArray = mj2;
    } else if (value > 4) {
        optionsArray = mj1;
    }else {
        optionsArray = false;

    }

    // Add new options based on the chosen array
    if (optionsArray) {
    // Clear all current options
    element.options.length = 0;
      let newOption = new Option("Choose Major",""); // Set value as the index
      newOption.selected="selected";
      newOption.disabled = "disabled";
      element.add(newOption); // Add the option to the select element
        optionsArray.forEach((optionText, index) => {
            key = index +1;
            let newOption = new Option(optionText, key); // Set value as the index
            element.add(newOption); // Add the option to the select element
        });
    }
}

</script>