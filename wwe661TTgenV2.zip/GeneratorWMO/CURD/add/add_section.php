<?php 
include('../../Database/config.php');
extract($_POST);
if(isset($save))
{
  foreach($sections as $k=>$v){
    $temp[$k]=$stucount[$k];
  }
  $stucount = $temp;
  // var_dump($stucount);
  foreach($stucount as $k=>$v) {
    $c1 = $k+1;
    $temp="$c$c1";
    $que=mysqli_query($con,"select * from section where section_id='$temp'");	
    $row=mysqli_num_rows($que);
    if($row==0)
    {
          $c2= "sec".chr(64 + intval($c1));
          $c1=$temp;
          // var_dump($c2,$c1,$v);
      mysqli_query($con,"insert into section (semester_id,section_id,section_name,section_capacity) 
      values('$c','$c1','$c2','$v')");	

    }
}
$err="<font color='blue'>Congrats Your Data Saved!!!</font>";
header("Location:admindashboard.php?info=section");
}

?>
<div class="row parent">
<div class="col-md-5">
<h2>Add Section</h2>
<form method="POST" enctype="multipart/form-data">
  <table  class="table">
  <tr>
  <th colspan="2"><?php echo @$err; ?></th>
  </tr>
    <tr>
        <th scope="row" name="sem_box">Select Semester</th>
        <th>
            <?php                
            // Fetch semesters from the database
            $semesters_query = mysqli_query($con, "SELECT * FROM semester");
            
            // Check if any semesters are fetched
            if(mysqli_num_rows($semesters_query) > 0) {
                // Start select dropdown
                echo '<select name="c" class="form-control"onchange="changesections(this)">';
                echo '<option disabled selected >Select Semester</option>';
                
                // Loop through each semester and create an option tag
                while ($semester = mysqli_fetch_assoc($semesters_query)) {
                    $temp = mysqli_query($con,"select * from section where semester_id ='". $semester['semester_id']."'");
                    $count = mysqli_num_rows($temp);
                    echo '<option value="' . $semester['semester_id'] .'"data-count="' . $count . '"">' . $semester['semester_name'] . '</option>';
                }
                echo '</select>';
            } else {
                echo 'No semesters found'; // Show a message if no semesters are found
            }
            ?>
        </th>
      </tr>
  <tr>
    <th width="237" scope="row"rowspan="5">Section </th>
    <td width="350">
    A<input type="checkbox" name="sections[]" id=""class="checks"onclick="takenumofstu(this)">
    <div class="stucount">
    Number of students :
    <input type="number" name="stucount[]" id=""min="1"max = "100"value="40"></div>
    </td>
    <tr>
      <td>
        B<input type="checkbox" name="sections[]" id=""class="checks"onclick="takenumofstu(this)">
    <div class="stucount">
    Number of students :
    <input type="number" name="stucount[]" id=""min="1"max = "100"value="40"></div>
      </td>
    </tr>
    <tr>
    <td>
        C<input type="checkbox" name="sections[]" id=""class="checks"onclick="takenumofstu(this)">
    <div class="stucount">
    Number of students :
    <input type="number" name="stucount[]" id=""min="1"max = "100"value="40"></div>
    </td>
    
    </tr>
    <tr>
      <td>
        D<input type="checkbox" name="sections[]" id=""class="checks"onclick="takenumofstu(this)">
    <div class="stucount">
    Number of students :
    <input type="number" name="stucount[]" id=""min="1"max = "100"value="40"></div>
      </td>
    
    </tr>
    <tr>
      <td>
        E<input type="checkbox" name="sections[]" id=""class="checks"onclick="takenumofstu(this)">
    <div class="stucount">
    Number of students :
    <input type="number" name="stucount[]" id=""min="1"max = "100"value="40"></div>
    </td>
    </tr>
  </tr>
  <tr>
    <th colspan="2" align="center">
	<input type="submit" value="Add Section" name="save" class="btn myBtn " />
	
	<input type="reset" value="Reset" class="btn  myBtn"/>
	
	</th>
  </tr>
  
  </table>
</form>
</div>
</div>
<style>
  .stucount{
    display: none;
  }
  td{
    display: flex;
    height: 40px;
    align-items: center;
    justify-content: center;
  }
</style>
<script>
  function takenumofstu(checkbox){
    var showelement =checkbox.nextElementSibling;
    showstucount(checkbox,showelement);
  }
  function showstucount(checkbox,element){
    if (checkbox.checked) {
        element.style.display = "block";
    } else {
        element.style.display = "none";
    }
  }
  function changesections(element) {
    // Get the selected option
    var option = element.options[element.selectedIndex];
    var semesterId = option.value;

    // Make an AJAX request to fetch the student count
    fetch('getcount.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `semester_id=${semesterId}`,
    })
        .then(response => response.json())
        .then(data => {
          if (data.length === 0) {
        console.log("No data available for the selected semester.");
        return;
        }
            console.log("Number of students: ", data);
          studentCount = data.length;
            // Update checkboxes or other UI elements based on the student count
            var checks = document.querySelectorAll(".checks");
            checks.forEach((checkbox, index) => {
                var showElement = checkbox.nextElementSibling;
                input =showElement.querySelector("input");
                input.value = data[index];
                if (index < studentCount) {
                    checkbox.checked = true;
                } else {
                    checkbox.checked = false;
                }
                showstucount(checkbox, showElement);
            });
        })
        .catch(error => console.error("Error fetching student count:", error));
}
</script>