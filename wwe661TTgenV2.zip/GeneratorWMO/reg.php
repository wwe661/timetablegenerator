<div class="container d-flex justify-content-center align-items-center min-vh-100">
        <!----------------------- Login Container -------------------------->
      <div class="typing row border rounded-5 p-3  shadow box-area"  style="background-color: inherit; ">
        
                  <!--------------------------- Left Box ----------------------------->
              <div class="col-md-4  d-flex justify-content-center align-items-center flex-column admin-left-box border-end border-3" >
                  <div class="featured-image mb-3">
                    <img src="homeimg/admin.png" class="img-fluid" style="width: 250px;">
                  </div>
                  <!-- <div class="typing">
                    <h3 class=" fs-2 text-center mb-4" ><b> ညှိယူ</b></h3>
                  <h5 class=" text-wrap text-center" style="width: 17rem;"><b>Timetable generator</b></h5>
                  </div> -->
                  
              </div> 
            <!-------------------- ------ Right Box ---------------------------->
              <div class="col-md-8 p-5 right-box ">
                  <div class="row align-items-center">
                        <div class="header-text mb-4">
                            <p><?php $err=$_REQUEST['err'];echo $err; ?></p>
                            <h2 class="welcome" style="text-align: center;">Welcome</h2>
                            <p style="text-align: center;">REGISTRATION</p>
                        </div>
                        <form action="validate.php" method="POST">
                          <div class="input-group mb-3">
                              <input type="text" name="UN" class="form-control form-control-lg bg-light fs-6" placeholder="Username" required id="adminname">
                          </div>
                          <div class="input-group mb-3">
                              <input type="email" name="EM" class="form-control form-control-lg bg-light fs-6" placeholder="Email" required id="mail">
                          </div>
                          <div class="input-group mb-5">
                              <input type="password" name="PASS" class="form-control form-control-lg bg-light fs-6" placeholder="Password" required id="password">
                          </div>
                          
                          <div class="input-group mb-3" id="btngroup">
                            <input class="btn btn-lg w-100 fs-6 login-btn" name="reg" type="submit" value="Register">
                            <!-- <button class="btn btn-lg btn-primary w-100 fs-6">Login</button> -->
                          </div>
                        </form>
                        
                  </div>
                </div> 
              </div>
        
        
    </div>