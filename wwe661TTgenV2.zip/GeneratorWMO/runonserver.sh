php -S localhost:8000

